from collections import defaultdict
from datetime import datetime, timedelta

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.config import settings
from app.database import get_db
from app.models import (
    Link, Task, Click, User, Withdrawal, WithdrawalStatus, ApiKey,
    Payment, PaymentStatus,
)
from app.schemas import (
    LinkCreate, LinkOut, LinkStats, WithdrawalCreate, WithdrawalOut,
    ApiKeyOut, ApiKeyCreate, LinkWithStats, DashboardSummary, DailyPoint,
    MeResponse,
)
from app.services.settings_service import get_commission_percent
from app.services import supabase_sync

router = APIRouter(prefix="/creator", tags=["creator"])

VALID_TASK_TYPES = {"ad", "channel", "payment", "custom"}


@router.get("/me", response_model=MeResponse)
def me(user: User = Depends(get_current_user)):
    """Joriy login qilgan kreator haqida ma'lumot — dashboard header/avatar uchun."""
    return user


def _validate_tasks(tasks):
    if not tasks:
        raise HTTPException(status_code=400, detail="Kamida bitta vazifa (tugma) qo'shilishi kerak")
    for t in tasks:
        if t.type not in VALID_TASK_TYPES:
            raise HTTPException(status_code=400, detail=f"Noto'g'ri vazifa turi: {t.type}")
        if t.type == "channel" and not t.channel_username:
            raise HTTPException(status_code=400, detail="'channel' turi uchun channel_username majburiy")
        if t.type == "payment" and not t.price_uzs:
            raise HTTPException(status_code=400, detail="'payment' turi uchun price_uzs majburiy")
        if t.type == "custom" and not t.custom_url:
            raise HTTPException(status_code=400, detail="'custom' turi uchun custom_url majburiy")


def _link_earnings(db: Session, link_id: str, commission) -> float:
    matched = (
        db.query(Payment)
        .filter(Payment.link_id == link_id, Payment.status == PaymentStatus.matched)
        .all()
    )
    gross = sum((p.matched_amount_uzs or 0) for p in matched)
    return gross * (100 - commission) / 100 if gross else 0


def _daily_series(db: Session, link_ids: list[str], days: int = 14) -> list[DailyPoint]:
    since = datetime.utcnow() - timedelta(days=days)
    clicks = (
        db.query(Click)
        .filter(Click.link_id.in_(link_ids), Click.created_at >= since)
        .all()
        if link_ids else []
    )
    buckets = defaultdict(lambda: {"clicks": 0, "completed": 0})
    for c in clicks:
        day = c.created_at.strftime("%Y-%m-%d")
        buckets[day]["clicks"] += 1
        if c.completed:
            buckets[day]["completed"] += 1

    points = []
    for i in range(days - 1, -1, -1):
        day = (datetime.utcnow() - timedelta(days=i)).strftime("%Y-%m-%d")
        b = buckets.get(day, {"clicks": 0, "completed": 0})
        points.append(DailyPoint(date=day, clicks=b["clicks"], completed=b["completed"]))
    return points


@router.post("/links", response_model=LinkOut)
def create_link(
    payload: LinkCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _validate_tasks(payload.tasks)

    link = Link(creator_id=user.id, target_url=payload.target_url, title=payload.title)
    db.add(link)
    db.flush()

    for i, t in enumerate(payload.tasks):
        db.add(Task(
            link_id=link.id,
            order=i,
            type=t.type,
            label=t.label,
            channel_username=t.channel_username,
            custom_url=t.custom_url,
            price_uzs=t.price_uzs,
        ))

    db.commit()
    db.refresh(link)

    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "links",
        {
            "id": link.id,
            "creator_id": link.creator_id,
            "slug": link.slug,
            "target_url": link.target_url,
            "title": link.title,
            "is_active": link.is_active,
            "created_at": link.created_at,
        },
    )
    return link


@router.get("/links", response_model=list[LinkWithStats])
def list_links(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    links = db.query(Link).filter(Link.creator_id == user.id).order_by(Link.created_at.desc()).all()
    commission = get_commission_percent(db)
    result = []
    for link in links:
        total = db.query(Click).filter(Click.link_id == link.id).count()
        completed = db.query(Click).filter(Click.link_id == link.id, Click.completed == True).count()  # noqa: E712
        earnings = _link_earnings(db, link.id, commission)

        result.append(
            LinkWithStats(
                **LinkOut.model_validate(link).model_dump(),
                total_clicks=total,
                completed_clicks=completed,
                conversion_rate=round((completed / total * 100) if total else 0.0, 2),
                earnings_uzs=earnings,
            )
        )
    return result


@router.get("/summary", response_model=DashboardSummary)
def dashboard_summary(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    links = db.query(Link).filter(Link.creator_id == user.id).all()
    link_ids = [l.id for l in links]

    total_clicks = db.query(Click).filter(Click.link_id.in_(link_ids)).count() if link_ids else 0
    completed_clicks = (
        db.query(Click).filter(Click.link_id.in_(link_ids), Click.completed == True).count()  # noqa: E712
        if link_ids else 0
    )

    commission = get_commission_percent(db)
    matched = (
        db.query(Payment).filter(Payment.link_id.in_(link_ids), Payment.status == PaymentStatus.matched).all()
        if link_ids else []
    )
    gross = sum((p.matched_amount_uzs or 0) for p in matched)
    total_earnings = gross * (100 - commission) / 100 if gross else 0

    return DashboardSummary(
        balance_uzs=user.balance_uzs,
        total_links=len(links),
        active_links=sum(1 for l in links if l.is_active),
        total_clicks=total_clicks,
        completed_clicks=completed_clicks,
        total_earnings_uzs=total_earnings,
        daily=_daily_series(db, link_ids),
    )


@router.get("/links/{link_id}/stats", response_model=LinkStats)
def link_stats(link_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    link = db.query(Link).filter(Link.id == link_id, Link.creator_id == user.id).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")

    total = db.query(Click).filter(Click.link_id == link.id).count()
    completed = db.query(Click).filter(Click.link_id == link.id, Click.completed == True).count()  # noqa: E712
    rate = (completed / total * 100) if total else 0.0
    commission = get_commission_percent(db)
    earnings = _link_earnings(db, link.id, commission)

    return LinkStats(
        link=link,
        total_clicks=total,
        completed_clicks=completed,
        conversion_rate=round(rate, 2),
        earnings_uzs=earnings,
        daily=_daily_series(db, [link.id]),
    )


@router.patch("/links/{link_id}/toggle", response_model=LinkOut)
def toggle_link(link_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    link = db.query(Link).filter(Link.id == link_id, Link.creator_id == user.id).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")
    link.is_active = not link.is_active
    db.commit()
    db.refresh(link)
    return link


@router.delete("/links/{link_id}")
def delete_link(link_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    link = db.query(Link).filter(Link.id == link_id, Link.creator_id == user.id).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")
    db.delete(link)
    db.commit()
    return {"ok": True}


@router.post("/withdrawals", response_model=WithdrawalOut)
def request_withdrawal(
    payload: WithdrawalCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if payload.amount_uzs < settings.min_withdrawal_uzs:
        raise HTTPException(
            status_code=400,
            detail=f"Minimal yechib olish summasi {settings.min_withdrawal_uzs} so'm",
        )
    if payload.amount_uzs > user.balance_uzs:
        raise HTTPException(status_code=400, detail="Balansda yetarli mablag' yo'q")

    withdrawal = Withdrawal(
        creator_id=user.id,
        amount_uzs=payload.amount_uzs,
        card_number=payload.card_number,
        status=WithdrawalStatus.pending,
    )
    user.balance_uzs -= payload.amount_uzs

    db.add(withdrawal)
    db.commit()
    db.refresh(withdrawal)

    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "withdrawals",
        {
            "id": withdrawal.id,
            "creator_id": withdrawal.creator_id,
            "amount_uzs": withdrawal.amount_uzs,
            "card_number": withdrawal.card_number,
            "status": withdrawal.status,
            "created_at": withdrawal.created_at,
        },
    )
    # Balans o'zgardi — foydalanuvchi qatorini ham yangilaymiz
    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "users",
        {"id": user.id, "balance_uzs": user.balance_uzs},
    )
    return withdrawal


@router.get("/withdrawals", response_model=list[WithdrawalOut])
def my_withdrawals(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return (
        db.query(Withdrawal)
        .filter(Withdrawal.creator_id == user.id)
        .order_by(Withdrawal.created_at.desc())
        .all()
    )


# ---------------- API kalitlari (dasturchilar uchun) ----------------
@router.get("/api-keys", response_model=list[ApiKeyOut])
def list_api_keys(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(ApiKey).filter(ApiKey.creator_id == user.id).order_by(ApiKey.created_at.desc()).all()


@router.post("/api-keys", response_model=ApiKeyOut)
def create_api_key(payload: ApiKeyCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    key = ApiKey(creator_id=user.id, label=payload.label)
    db.add(key)
    db.commit()
    db.refresh(key)
    return key


@router.patch("/api-keys/{key_id}/toggle", response_model=ApiKeyOut)
def toggle_api_key(key_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    key = db.query(ApiKey).filter(ApiKey.id == key_id, ApiKey.creator_id == user.id).first()
    if not key:
        raise HTTPException(status_code=404, detail="API kalit topilmadi")
    key.is_active = not key.is_active
    db.commit()
    db.refresh(key)
    return key


@router.delete("/api-keys/{key_id}")
def delete_api_key(key_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    key = db.query(ApiKey).filter(ApiKey.id == key_id, ApiKey.creator_id == user.id).first()
    if not key:
        raise HTTPException(status_code=404, detail="API kalit topilmadi")
    db.delete(key)
    db.commit()
    return {"ok": True}
