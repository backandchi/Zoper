from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import require_admin
from app.database import get_db
from app.models import (
    User, Withdrawal, WithdrawalStatus, AdNetwork, SystemSetting, TelethonSession,
)
from app.schemas import (
    MeResponse, WithdrawalOut, WithdrawalDecision, AdNetworkCreate, AdNetworkOut,
    SettingUpdate, TelethonStep1, TelethonStep2, TelethonStep3,
)
from app.services.telethon_service import (
    start_login, submit_code, submit_password,
)
from app.services import supabase_sync

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_admin)])


# ---------------- Foydalanuvchilar ----------------
@router.get("/users", response_model=list[MeResponse])
def list_users(db: Session = Depends(get_db)):
    return db.query(User).order_by(User.created_at.desc()).all()


@router.patch("/users/{user_id}/block")
def toggle_block(user_id: str, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Foydalanuvchi topilmadi")
    user.is_blocked = not user.is_blocked
    db.commit()
    background_tasks.add_task(
        supabase_sync.upsert_sync, "users", {"id": user.id, "is_blocked": user.is_blocked}
    )
    return {"is_blocked": user.is_blocked}


# ---------------- Pul yechish so'rovlari ----------------
@router.get("/withdrawals", response_model=list[WithdrawalOut])
def list_withdrawals(db: Session = Depends(get_db)):
    return (
        db.query(Withdrawal)
        .filter(Withdrawal.status == WithdrawalStatus.pending)
        .order_by(Withdrawal.created_at.asc())
        .all()
    )


@router.post("/withdrawals/{withdrawal_id}/decide", response_model=WithdrawalOut)
def decide_withdrawal(
    withdrawal_id: str,
    payload: WithdrawalDecision,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    withdrawal = db.query(Withdrawal).filter(Withdrawal.id == withdrawal_id).first()
    if not withdrawal:
        raise HTTPException(status_code=404, detail="So'rov topilmadi")

    creator = None
    if payload.approve:
        withdrawal.status = WithdrawalStatus.approved
    else:
        withdrawal.status = WithdrawalStatus.rejected
        # rad etilsa — ushlab qolingan summa creator balansiga qaytariladi
        creator = db.query(User).filter(User.id == withdrawal.creator_id).first()
        if creator:
            creator.balance_uzs += withdrawal.amount_uzs

    withdrawal.admin_note = payload.admin_note
    db.commit()
    db.refresh(withdrawal)

    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "withdrawals",
        {
            "id": withdrawal.id,
            "status": withdrawal.status,
            "admin_note": withdrawal.admin_note,
        },
    )
    if creator:
        background_tasks.add_task(
            supabase_sync.upsert_sync,
            "users",
            {"id": creator.id, "balance_uzs": creator.balance_uzs},
        )
    return withdrawal


# ---------------- Reklama tarmoqlari ----------------
@router.get("/ad-networks", response_model=list[AdNetworkOut])
def list_ad_networks(db: Session = Depends(get_db)):
    return db.query(AdNetwork).all()


@router.post("/ad-networks", response_model=AdNetworkOut)
def add_ad_network(payload: AdNetworkCreate, db: Session = Depends(get_db)):
    network = AdNetwork(**payload.model_dump())
    db.add(network)
    db.commit()
    db.refresh(network)
    return network


@router.patch("/ad-networks/{network_id}/toggle", response_model=AdNetworkOut)
def toggle_ad_network(network_id: str, db: Session = Depends(get_db)):
    network = db.query(AdNetwork).filter(AdNetwork.id == network_id).first()
    if not network:
        raise HTTPException(status_code=404, detail="Tarmoq topilmadi")
    network.is_active = not network.is_active
    db.commit()
    db.refresh(network)
    return network


@router.delete("/ad-networks/{network_id}")
def delete_ad_network(network_id: str, db: Session = Depends(get_db)):
    network = db.query(AdNetwork).filter(AdNetwork.id == network_id).first()
    if not network:
        raise HTTPException(status_code=404, detail="Tarmoq topilmadi")
    db.delete(network)
    db.commit()
    return {"ok": True}


# ---------------- Tizim sozlamalari (masalan komissiya foizi) ----------------
@router.get("/settings")
def get_settings(db: Session = Depends(get_db)):
    rows = db.query(SystemSetting).all()
    return {r.key: r.value for r in rows}


@router.put("/settings")
def update_setting(payload: SettingUpdate, db: Session = Depends(get_db)):
    row = db.query(SystemSetting).filter(SystemSetting.key == payload.key).first()
    if row:
        row.value = payload.value
    else:
        row = SystemSetting(key=payload.key, value=payload.value)
        db.add(row)
    db.commit()
    return {"key": payload.key, "value": payload.value}


# ---------------- Userbot (Telethon) — HUMO SMS parser sozlash ----------------
# 3 bosqichli login: API ID/Hash + telefon -> kod -> (ixtiyoriy) 2FA parol
@router.post("/telethon/step1")
async def telethon_step1(payload: TelethonStep1, db: Session = Depends(get_db)):
    return await start_login(db, payload.api_id, payload.api_hash, payload.phone)


@router.post("/telethon/step2")
async def telethon_step2(payload: TelethonStep2, db: Session = Depends(get_db)):
    return await submit_code(db, payload.code)


@router.post("/telethon/step3")
async def telethon_step3(payload: TelethonStep3, db: Session = Depends(get_db)):
    return await submit_password(db, payload.password)


@router.get("/telethon/status")
def telethon_status(db: Session = Depends(get_db)):
    session = db.query(TelethonSession).order_by(TelethonSession.created_at.desc()).first()
    if not session:
        return {"connected": False}
    return {"connected": session.is_connected, "phone": session.phone}
