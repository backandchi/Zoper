import random
from datetime import datetime, timedelta

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Link, Task, Click, ClickTaskDone, Payment, PaymentStatus
from app.services.ad_mediation import pick_best_ad_network
from app.services import supabase_sync

router = APIRouter(prefix="/l", tags=["public"])


@router.get("/{slug}")
def open_link(slug: str, request: Request, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    """
    Foydalanuvchi qisqa linkka kirganda chaqiriladi. Linkka biriktirilgan
    barcha vazifalarni (tugmalarni) qaytaradi — kreator qancha qo'shgan
    bo'lsa, shuncha.
    """
    link = db.query(Link).filter(Link.slug == slug, Link.is_active == True).first()  # noqa: E712
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi yoki faol emas")

    click = Click(
        link_id=link.id,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    db.add(click)
    db.commit()
    db.refresh(click)

    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "clicks",
        {
            "id": click.id,
            "link_id": click.link_id,
            "ip_address": click.ip_address,
            "user_agent": click.user_agent,
            "completed": click.completed,
            "created_at": click.created_at,
        },
    )

    tasks_out = []
    for task in sorted(link.tasks, key=lambda t: t.order):
        item = {
            "task_id": task.id,
            "order": task.order,
            "type": task.type,
            "label": task.label,
        }
        if task.type == "ad":
            item["ad"] = pick_best_ad_network(db)
        elif task.type == "channel":
            item["channel_username"] = task.channel_username
        elif task.type == "custom":
            item["custom_url"] = task.custom_url
        elif task.type == "payment":
            unique_extra = random.randint(1, 50)
            amount = (task.price_uzs or 0) + unique_extra
            payment = Payment(
                link_id=link.id,
                task_id=task.id,
                click_id=click.id,
                expected_amount_uzs=amount,
                expires_at=datetime.utcnow() + timedelta(minutes=15),
            )
            db.add(payment)
            db.commit()
            item["payment"] = {
                "payment_id": payment.id,
                "amount_uzs": str(amount),
                "expires_at": payment.expires_at.isoformat(),
            }
        tasks_out.append(item)

    return {
        "click_id": click.id,
        "title": link.title,
        "tasks": tasks_out,
    }


class TaskCompleteBody(BaseModel):
    click_id: str


@router.post("/{slug}/tasks/{task_id}/complete")
def complete_task(slug: str, task_id: str, body: TaskCompleteBody, db: Session = Depends(get_db)):
    """
    Bitta vazifani "bajarildi" deb belgilaydi. "payment" turi uchun bu
    endpoint chaqirilmaydi — to'lov holati /status orqali pollanadi,
    HUMO parser moslashtirgach avtomatik "bajarildi" hisoblanadi.
    """
    link = db.query(Link).filter(Link.slug == slug).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")

    task = db.query(Task).filter(Task.id == task_id, Task.link_id == link.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Vazifa topilmadi")

    click = db.query(Click).filter(Click.id == body.click_id, Click.link_id == link.id).first()
    if not click:
        raise HTTPException(status_code=404, detail="Click topilmadi")

    if task.type == "payment":
        raise HTTPException(status_code=400, detail="To'lov turidagi vazifa avtomatik tekshiriladi")

    existing = (
        db.query(ClickTaskDone)
        .filter(ClickTaskDone.click_id == click.id, ClickTaskDone.task_id == task.id)
        .first()
    )
    if not existing:
        db.add(ClickTaskDone(click_id=click.id, task_id=task.id))
        db.commit()

    return {"ok": True}


@router.get("/{slug}/status")
def task_status(slug: str, click_id: str, db: Session = Depends(get_db)):
    """Qaysi vazifalar bajarilganini qaytaradi — frontend shu bilan pollaydi."""
    link = db.query(Link).filter(Link.slug == slug).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")

    click = db.query(Click).filter(Click.id == click_id, Click.link_id == link.id).first()
    if not click:
        raise HTTPException(status_code=404, detail="Click topilmadi")

    done_ids = {
        d.task_id
        for d in db.query(ClickTaskDone).filter(ClickTaskDone.click_id == click.id).all()
    }

    for task in link.tasks:
        if task.type == "payment" and task.id not in done_ids:
            matched = (
                db.query(Payment)
                .filter(Payment.click_id == click.id, Payment.task_id == task.id, Payment.status == PaymentStatus.matched)
                .first()
            )
            if matched:
                done_ids.add(task.id)
                db.add(ClickTaskDone(click_id=click.id, task_id=task.id))
                db.commit()

    return {"completed_task_ids": list(done_ids)}


@router.get("/{slug}/complete")
def complete_and_redirect(
    slug: str,
    click_id: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    """Barcha vazifalar bajarilgan bo'lsa, asl havolani qaytaradi."""
    link = db.query(Link).filter(Link.slug == slug).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")

    click = db.query(Click).filter(Click.id == click_id, Click.link_id == link.id).first()
    if not click:
        raise HTTPException(status_code=404, detail="Click topilmadi")

    done_ids = {
        d.task_id
        for d in db.query(ClickTaskDone).filter(ClickTaskDone.click_id == click.id).all()
    }
    all_task_ids = {t.id for t in link.tasks}

    if not all_task_ids.issubset(done_ids):
        raise HTTPException(status_code=402, detail="Hali barcha vazifalar bajarilmagan")

    click.completed = True
    db.commit()

    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "clicks",
        {"id": click.id, "completed": True},
    )

    return {"target_url": link.target_url}
