from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import verify_telegram_login, create_access_token
from app.config import settings
from app.database import get_db
from app.models import User
from app.schemas import TelegramLoginPayload, TokenResponse
from app.services import supabase_sync

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/telegram", response_model=TokenResponse)
def telegram_login(
    payload: TelegramLoginPayload,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    data = payload.model_dump()

    if not verify_telegram_login(data):
        raise HTTPException(status_code=401, detail="Telegram tekshiruvi muvaffaqiyatsiz")

    user = db.query(User).filter(User.telegram_id == payload.id).first()

    if user is None:
        is_admin = str(payload.id) == str(settings.seed_admin_telegram_id)
        user = User(
            telegram_id=payload.id,
            username=payload.username,
            first_name=payload.first_name,
            photo_url=payload.photo_url,
            is_admin=is_admin,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    else:
        # profil ma'lumotlarini yangilash + admin ro'yxati bilan qayta tekshirish
        user.username = payload.username
        user.first_name = payload.first_name
        user.photo_url = payload.photo_url
        if str(payload.id) == str(settings.seed_admin_telegram_id):
            user.is_admin = True
        db.commit()

    # Foydalanuvchi ma'lumotini Supabase'ga ham (fon jarayonida) yozib qo'yamiz —
    # asosiy javobni sekinlashtirmaydi, ishlamasa ham login buzilmaydi.
    background_tasks.add_task(
        supabase_sync.upsert_sync,
        "users",
        {
            "id": user.id,
            "telegram_id": user.telegram_id,
            "username": user.username,
            "first_name": user.first_name,
            "photo_url": user.photo_url,
            "is_admin": user.is_admin,
            "is_blocked": user.is_blocked,
            "balance_uzs": user.balance_uzs,
            "created_at": user.created_at,
        },
    )

    token = create_access_token(user_id=user.id, is_admin=user.is_admin)
    return TokenResponse(access_token=token, is_admin=user.is_admin)
