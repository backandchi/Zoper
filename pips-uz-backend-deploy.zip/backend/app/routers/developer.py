"""
Dasturchilar uchun ochiq API — API kalit (X-API-Key sarlavhasi) orqali
har qanday tashqi ilova/bot/skript avtomatik link yaratishi mumkin,
istalgan sondagi vazifa (tugma) bilan — kanalga a'zolik, reklama,
to'lov, ixtiyoriy havola — erkin aralashtirib.

Misol (cURL):

    curl -X POST https://pips.uz/api/v1/links \\
      -H "X-API-Key: pips_xxxxxxxxxxxxxxxxxxxx" \\
      -H "Content-Type: application/json" \\
      -d '{
            "target_url": "https://example.com/fayl.zip",
            "title": "Fayl yuklab olish",
            "tasks": [
              {"type": "channel", "channel_username": "mychannel", "label": "Kanalga a'\\''zo bo'\\''ling"},
              {"type": "payment", "price_uzs": 5000, "label": "5000 so'\\''m to'\\''lang"}
            ]
          }'
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_api_creator
from app.config import settings
from app.database import get_db
from app.models import Link, Task, User
from app.routers.creator import _validate_tasks
from app.schemas import ApiLinkCreate, ApiLinkOut, TaskOut

router = APIRouter(prefix="/v1", tags=["developer-api"])


def _to_api_out(link: Link) -> ApiLinkOut:
    return ApiLinkOut(
        slug=link.slug,
        short_url=f"{settings.public_base_url}/l/{link.slug}",
        target_url=link.target_url,
        tasks=[TaskOut.model_validate(t) for t in sorted(link.tasks, key=lambda t: t.order)],
        created_at=link.created_at,
    )


@router.post("/links", response_model=ApiLinkOut)
def api_create_link(
    payload: ApiLinkCreate,
    db: Session = Depends(get_db),
    creator: User = Depends(get_api_creator),
):
    _validate_tasks(payload.tasks)

    link = Link(creator_id=creator.id, target_url=payload.target_url, title=payload.title)
    db.add(link)
    db.flush()

    for i, t in enumerate(payload.tasks):
        db.add(Task(
            link_id=link.id,
            order=i,
            type=t.type,
            label=t.label,
            channel_username=t.channel_username,
            custom_url=t.custom_url,
            price_uzs=t.price_uzs,
        ))

    db.commit()
    db.refresh(link)
    return _to_api_out(link)


@router.get("/links", response_model=list[ApiLinkOut])
def api_list_links(
    db: Session = Depends(get_db),
    creator: User = Depends(get_api_creator),
):
    links = db.query(Link).filter(Link.creator_id == creator.id).order_by(Link.created_at.desc()).all()
    return [_to_api_out(l) for l in links]


@router.delete("/links/{slug}")
def api_delete_link(
    slug: str,
    db: Session = Depends(get_db),
    creator: User = Depends(get_api_creator),
):
    link = db.query(Link).filter(Link.slug == slug, Link.creator_id == creator.id).first()
    if not link:
        raise HTTPException(status_code=404, detail="Havola topilmadi")
    db.delete(link)
    db.commit()
    return {"ok": True}
