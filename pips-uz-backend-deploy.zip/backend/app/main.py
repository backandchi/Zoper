from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app.config import settings
from app.models import User
from app.routers import auth, public, creator, admin, developer
from app.services.scheduler import start_scheduler


def seed_admin():
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.telegram_id == int(settings.seed_admin_telegram_id)).first()
        if not existing:
            # Foydalanuvchi birinchi marta Telegram orqali login qilganda
            # yaratiladi — bu yerda faqat ID admin ekanini eslab qolamiz,
            # auth.py shu ID kelganda is_admin=True qilib yozadi.
            pass
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    seed_admin()
    scheduler = start_scheduler()
    yield
    scheduler.shutdown()


app = FastAPI(title="pips.uz API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    # Autentifikatsiya Bearer token orqali (cookie emas), shuning uchun
    # credentials shart emas — bu allow_origins=["*"] bilan xavfsiz mos keladi.
    # (allow_origins=["*"] + allow_credentials=True kombinatsiyasi noto'g'ri edi:
    # brauzerlar buni CORS spec'iga zid deb rad etadi.) Production'da bu
    # ro'yxatni o'z domeningiz bilan cheklang.
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(public.router, prefix="/api")
app.include_router(creator.router, prefix="/api")
app.include_router(admin.router, prefix="/api")
app.include_router(developer.router, prefix="/api")


@app.get("/api/health")
def health():
    return {"status": "ok"}
