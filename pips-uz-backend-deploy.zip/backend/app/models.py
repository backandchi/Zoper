import enum
import uuid
import secrets

from sqlalchemy import (
    Column, String, Integer, BigInteger, Boolean, DateTime, ForeignKey,
    Numeric, Text, Enum
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.database import Base


def gen_uuid():
    return str(uuid.uuid4())


def gen_slug():
    return secrets.token_urlsafe(5)


class WithdrawalStatus(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"
    paid = "paid"


class PaymentStatus(str, enum.Enum):
    pending = "pending"
    matched = "matched"
    expired = "expired"


# ---------------------------------------------------------------------------
# Foydalanuvchilar (kreatorlar). Oddiy link-ochuvchilar bazada saqlanmaydi —
# ular anonim, faqat Click jadvalida iz qoldiradi.
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    telegram_id = Column(BigInteger, unique=True, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    first_name = Column(String(255), nullable=True)
    photo_url = Column(Text, nullable=True)

    is_admin = Column(Boolean, default=False, nullable=False)
    is_blocked = Column(Boolean, default=False, nullable=False)

    balance_uzs = Column(Numeric(14, 2), default=0, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    links = relationship("Link", back_populates="creator")
    withdrawals = relationship("Withdrawal", back_populates="creator")


class TaskType(str, enum.Enum):
    ad = "ad"            # reklama ko'rish
    channel = "channel"   # kanalga a'zo bo'lish
    payment = "payment"   # to'lov qilish
    custom = "custom"      # ixtiyoriy: havolani ochib "bajardim" bosish


class Link(Base):
    __tablename__ = "links"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    creator_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)

    slug = Column(String(32), unique=True, nullable=False, default=gen_slug, index=True)
    target_url = Column(Text, nullable=False)
    title = Column(String(255), nullable=True)

    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    creator = relationship("User", back_populates="links")
    clicks = relationship("Click", back_populates="link")
    tasks = relationship("Task", back_populates="link", order_by="Task.order", cascade="all, delete-orphan")


class Task(Base):
    """
    Bitta link ostida bir nechta vazifa (tugma) — LootLabs uslubida.
    Kreator xohlagancha vazifa qo'shishi mumkin: bir nechtasi kanalga
    a'zolik, bittasi reklama, bittasi to'lov va h.k. — erkin aralashtirib.
    """
    __tablename__ = "tasks"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    link_id = Column(UUID(as_uuid=False), ForeignKey("links.id"), nullable=False)

    order = Column(Integer, default=0, nullable=False)
    type = Column(Enum(TaskType), nullable=False)
    label = Column(String(255), nullable=True)  # tugmada ko'rinadigan matn

    channel_username = Column(String(255), nullable=True)   # type=channel
    custom_url = Column(Text, nullable=True)                  # type=custom
    price_uzs = Column(Numeric(14, 2), nullable=True)         # type=payment

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    link = relationship("Link", back_populates="tasks")


class ClickTaskDone(Base):
    """Bitta tashrif (Click) doirasida qaysi vazifalar bajarilganini belgilaydi."""
    __tablename__ = "click_task_done"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    click_id = Column(UUID(as_uuid=False), ForeignKey("clicks.id"), nullable=False)
    task_id = Column(UUID(as_uuid=False), ForeignKey("tasks.id"), nullable=False)
    completed_at = Column(DateTime(timezone=True), server_default=func.now())


class Click(Base):
    __tablename__ = "clicks"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    link_id = Column(UUID(as_uuid=False), ForeignKey("links.id"), nullable=False)

    ip_address = Column(String(64), nullable=True)
    user_agent = Column(Text, nullable=True)
    fingerprint = Column(String(128), nullable=True, index=True)

    step_completed = Column(String(32), nullable=True)  # ad_viewed / task_done / paid
    completed = Column(Boolean, default=False, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    link = relationship("Link", back_populates="clicks")


# ---------------------------------------------------------------------------
# HUMO karta orqali kelgan to'lovlar (userbot tomonidan parse qilinadi)
# ---------------------------------------------------------------------------
class Payment(Base):
    __tablename__ = "payments"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    link_id = Column(UUID(as_uuid=False), ForeignKey("links.id"), nullable=True)
    task_id = Column(UUID(as_uuid=False), ForeignKey("tasks.id"), nullable=True)
    click_id = Column(UUID(as_uuid=False), ForeignKey("clicks.id"), nullable=True)

    # Noyob summa: asosiy narx + tasodifiy 1-50 so'm qo'shimcha,
    # shu orqali HUMO bildirishnomasidagi summa bilan aniq moslashtiriladi.
    expected_amount_uzs = Column(Numeric(14, 2), nullable=False)
    matched_amount_uzs = Column(Numeric(14, 2), nullable=True)

    status = Column(Enum(PaymentStatus), default=PaymentStatus.pending, nullable=False)

    humo_raw_message = Column(Text, nullable=True)
    matched_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Withdrawal(Base):
    __tablename__ = "withdrawals"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    creator_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)

    amount_uzs = Column(Numeric(14, 2), nullable=False)
    card_number = Column(String(32), nullable=False)  # faqat oxirgi 4 raqam saqlash tavsiya etiladi

    status = Column(Enum(WithdrawalStatus), default=WithdrawalStatus.pending, nullable=False)
    admin_note = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    processed_at = Column(DateTime(timezone=True), nullable=True)

    creator = relationship("User", back_populates="withdrawals")


# ---------------------------------------------------------------------------
# Reklama tarmoqlari (Monetag, PopAds, PropellerAds, ...) — admin panel
# orqali qo'shiladi, ad mediation shundan eng yaxshisini tanlaydi.
# ---------------------------------------------------------------------------
class AdNetwork(Base):
    __tablename__ = "ad_networks"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    name = Column(String(64), nullable=False)  # "monetag" | "popads" | "propellerads" | ...
    api_key = Column(Text, nullable=True)
    zone_id = Column(String(128), nullable=True)
    script_snippet = Column(Text, nullable=True)  # to'g'ridan-to'g'ri joylanadigan JS kod

    is_active = Column(Boolean, default=True, nullable=False)

    # Fon vazifasi (cron) tomonidan yangilanadigan statistikalar
    avg_cpm_usd = Column(Numeric(10, 4), default=0, nullable=False)
    last_synced_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


# ---------------------------------------------------------------------------
# Umumiy tizim sozlamalari — key/value, admin panel orqali o'zgartiriladi
# ---------------------------------------------------------------------------
class SystemSetting(Base):
    __tablename__ = "system_settings"

    key = Column(String(64), primary_key=True)
    value = Column(Text, nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())


# ---------------------------------------------------------------------------
# Userbot (Telethon) sessiyasi — HUMO SMS parser uchun.
# Session string SHIFRLANGAN holda saqlanishi kerak (bu yerda placeholder).
# ---------------------------------------------------------------------------
def gen_api_key():
    return "pips_" + secrets.token_urlsafe(32)


# ---------------------------------------------------------------------------
# Dasturchilar uchun API kalitlari — kreator dashboardidan generatsiya
# qilinadi, keyin tashqi ilova/skript shu kalit orqali link yaratadi.
# ---------------------------------------------------------------------------
class ApiKey(Base):
    __tablename__ = "api_keys"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    creator_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)

    key = Column(String(64), unique=True, nullable=False, default=gen_api_key, index=True)
    label = Column(String(255), nullable=True)  # masalan "Mening botim"

    is_active = Column(Boolean, default=True, nullable=False)
    last_used_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class TelethonSession(Base):
    __tablename__ = "telethon_sessions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    api_id = Column(String(32), nullable=False)
    api_hash = Column(String(64), nullable=False)
    phone = Column(String(32), nullable=False)

    session_string_encrypted = Column(Text, nullable=True)
    is_connected = Column(Boolean, default=False, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())
