from decimal import Decimal

from sqlalchemy.orm import Session

from app.config import settings
from app.models import SystemSetting


def get_commission_percent(db: Session) -> Decimal:
    row = db.query(SystemSetting).filter(SystemSetting.key == "commission_percent").first()
    if row:
        return Decimal(row.value)
    return Decimal(settings.default_commission_percent)
