"""
Admin panel orqali userbot (Telethon) sessiyasini yaratish uchun 3 bosqichli
login oqimi:

  1-qadam: API ID + API Hash + telefon raqam -> Telegram kod yuboradi
  2-qadam: SMS/ilovadan kelgan kodni tasdiqlash
  3-qadam: agar 2FA (bulutli parol) yoqilgan bo'lsa, parolni so'raydi

Muvaffaqiyatli bo'lgach, session string SHIFRLANGAN holda bazaga saqlanadi
va HUMO parser userboti shu sessiyadan foydalanib background rejimda ishga
tushiriladi (bootstrap.py / worker.py da).

Eslatma: bitta jarayon xotirasida bitta login sessiyasi kutib turadi —
production'da buni Redis yoki DB'ga yozib, ko'p-worker holatini qo'llab-
quvvatlash kerak bo'lishi mumkin. MVP uchun bu yetarli.
"""
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError
from sqlalchemy.orm import Session

from app.models import TelethonSession
from app.services.crypto import encrypt

_pending_client: TelegramClient | None = None
_pending_phone: str | None = None
_pending_api_id: str | None = None
_pending_api_hash: str | None = None


async def start_login(db: Session, api_id: str, api_hash: str, phone: str) -> dict:
    global _pending_client, _pending_phone, _pending_api_id, _pending_api_hash

    client = TelegramClient(f"admin_session_{phone}", int(api_id), api_hash)
    await client.connect()
    await client.send_code_request(phone)

    _pending_client = client
    _pending_phone = phone
    _pending_api_id = api_id
    _pending_api_hash = api_hash

    return {"status": "code_sent", "message": "Telegram orqali tasdiqlash kodi yuborildi"}


async def submit_code(db: Session, code: str) -> dict:
    global _pending_client

    if _pending_client is None:
        return {"status": "error", "message": "Avval 1-qadamni bajaring"}

    try:
        await _pending_client.sign_in(_pending_phone, code)
    except SessionPasswordNeededError:
        return {"status": "password_needed", "message": "2 bosqichli parol talab qilinadi"}

    return await _finalize(db)


async def submit_password(db: Session, password: str | None) -> dict:
    global _pending_client

    if _pending_client is None:
        return {"status": "error", "message": "Avval 1-qadamni bajaring"}

    if password:
        await _pending_client.sign_in(password=password)

    return await _finalize(db)


async def _finalize(db: Session) -> dict:
    global _pending_client, _pending_phone, _pending_api_id, _pending_api_hash

    session_string = _pending_client.session.save()

    record = TelethonSession(
        api_id=_pending_api_id,
        api_hash=_pending_api_hash,
        phone=_pending_phone,
        session_string_encrypted=encrypt(session_string),
        is_connected=True,
    )
    db.add(record)
    db.commit()

    await _pending_client.disconnect()
    _pending_client = None
    _pending_phone = None
    _pending_api_id = None
    _pending_api_hash = None

    return {"status": "connected", "message": "Userbot muvaffaqiyatli ulandi"}
