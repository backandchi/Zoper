"""
Supabase dual-write qatlami.

Asosiy ma'lumotlar bazasi hamon PostgreSQL (SQLAlchemy, app/database.py) —
bu servis faqat SHU BILAN BIRGA Supabase'ga ham nusxa yuboradi (masalan
tashqi analitika, admin uchun Supabase Studio orqali ko'rish, yoki kelajakda
Supabase Auth/Storage bilan integratsiya uchun).

Muhim tamoyil: bu servis HECH QACHON asosiy so'rovni to'xtatmasligi kerak.
Supabase vaqtincha ishlamay qolsa yoki sozlanmagan bo'lsa, chaqiruvchi kod
buni sezmaydi — xato faqat log'ga yoziladi. `upsert()` PostgREST'ning
"Prefer: resolution=merge-duplicates" imkoniyatidan foydalanadi, shuning
uchun bir xil `id` bilan qayta yozish yangilashga aylanadi.

Ishlashi uchun backend `.env` faylida:
    SUPABASE_URL=https://xxxx.supabase.co
    SUPABASE_SERVICE_KEY=eyJ...   (service_role kaliti — RLS'ni chetlab o'tadi)

Kerakli jadvallar Supabase'da quyidagi struktura bilan mavjud bo'lishi kerak
(qarang: supabase_schema.sql):
    users, links, tasks, clicks, withdrawals, payments
"""
import logging
from typing import Any

import httpx

from app.config import settings

logger = logging.getLogger("supabase_sync")


def _enabled() -> bool:
    return bool(
        settings.supabase_sync_enabled
        and settings.supabase_url
        and settings.supabase_service_key
    )


def _headers() -> dict:
    return {
        "apikey": settings.supabase_service_key,
        "Authorization": f"Bearer {settings.supabase_service_key}",
        "Content-Type": "application/json",
        # id bo'yicha to'qnashuv bo'lsa — UPDATE sifatida bajarilsin
        "Prefer": "resolution=merge-duplicates,return=minimal",
    }


def _serialize(value: Any) -> Any:
    """Decimal/UUID/datetime kabi turlarni JSON-safe qilib beradi."""
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    # Decimal va boshqa raqamli turlar
    try:
        from decimal import Decimal

        if isinstance(value, Decimal):
            return float(value)
    except ImportError:
        pass
    if hasattr(value, "value"):  # Enum
        return value.value
    return value


async def upsert(table: str, row: dict) -> None:
    """Bitta qatorni Supabase jadvaliga yozadi (mavjud bo'lsa — yangilaydi)."""
    if not _enabled():
        return

    payload = {k: _serialize(v) for k, v in row.items()}

    url = f"{settings.supabase_url.rstrip('/')}/rest/v1/{table}"
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(url, json=payload, headers=_headers())
            if resp.status_code >= 300:
                logger.warning(
                    "Supabase sync (%s) muvaffaqiyatsiz: %s — %s",
                    table, resp.status_code, resp.text[:300],
                )
    except Exception as exc:  # noqa: BLE001 — dual-write hech qachon asosiy oqimni buzmasligi kerak
        logger.warning("Supabase sync (%s) xato: %s", table, exc)


def upsert_sync(table: str, row: dict) -> None:
    """
    Sync (blokловчи bo'lmagan) kontekstlarda ishlatish uchun — FastAPI'ning
    oddiy (non-async) endpoint funksiyalari ichida chaqiriladi. Ichkarida
    qisqa muddatli sync HTTP so'rov yuboradi, xato bo'lsa yutib qo'yadi.
    """
    if not _enabled():
        return

    payload = {k: _serialize(v) for k, v in row.items()}
    url = f"{settings.supabase_url.rstrip('/')}/rest/v1/{table}"
    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.post(url, json=payload, headers=_headers())
            if resp.status_code >= 300:
                logger.warning(
                    "Supabase sync (%s) muvaffaqiyatsiz: %s — %s",
                    table, resp.status_code, resp.text[:300],
                )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Supabase sync (%s) xato: %s", table, exc)
