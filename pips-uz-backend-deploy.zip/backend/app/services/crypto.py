"""
Telethon session string kabi juda maxfiy ma'lumotlarni bazada shifrlab
saqlash uchun. JWT_SECRET asosida Fernet kaliti hosil qilinadi — production'da
buni alohida, faqat serverda mavjud bo'lgan maxfiy kalitga almashtiring.
"""
import base64
import hashlib

from cryptography.fernet import Fernet

from app.config import settings


def _get_fernet() -> Fernet:
    key_bytes = hashlib.sha256(settings.jwt_secret.encode()).digest()
    key = base64.urlsafe_b64encode(key_bytes)
    return Fernet(key)


def encrypt(value: str) -> str:
    return _get_fernet().encrypt(value.encode()).decode()


def decrypt(value: str) -> str:
    return _get_fernet().decrypt(value.encode()).decode()
