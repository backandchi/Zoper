"""
Har bir faol reklama tarmog'ining statistika API'sini davriy so'rab,
avg_cpm_usd qiymatini yangilaydi. Ad mediation (ad_mediation.py) shu
qiymatga qarab eng yaxshi tarmoqni tanlaydi.

Har bir tarmoqning statistika API'si har xil (Monetag, PopAds, PropellerAds),
shuning uchun har biriga alohida fetch funksiyasi yozilishi kerak — quyida
placeholder ko'rsatilgan, haqiqiy API hujjatiga qarab to'ldiriladi.
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy.sql import func

from app.database import SessionLocal
from app.models import AdNetwork


async def fetch_cpm_for_network(network: AdNetwork) -> float | None:
    # TODO: har bir tarmoqning haqiqiy statistika API chaqiruvini shu yerga yozing.
    # Masalan Monetag uchun: GET https://api.monetag.com/... (API Key bilan)
    return None


async def sync_all_networks():
    db = SessionLocal()
    try:
        networks = db.query(AdNetwork).filter(AdNetwork.is_active == True).all()  # noqa: E712
        for network in networks:
            cpm = await fetch_cpm_for_network(network)
            if cpm is not None:
                network.avg_cpm_usd = cpm
                network.last_synced_at = func.now()
        db.commit()
    finally:
        db.close()


def start_scheduler():
    scheduler = AsyncIOScheduler()
    scheduler.add_job(sync_all_networks, "interval", hours=1)
    scheduler.start()
    return scheduler
