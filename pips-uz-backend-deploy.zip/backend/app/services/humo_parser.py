"""
HUMO to'lov parser — @HUMOcardbot'dan kelgan karta bildirishnomalarini
o'qib, kutilayotgan Payment yozuvlari bilan solishtiradi.

Ishga tushirish: alohida jarayon sifatida (masalan systemd yoki Docker
konteyner ichida `python -m app.services.humo_parser`).

Xabar formati (namuna):
    🎉 To'ldirish
    ➕ 26.388,00 UZS
    📍 PAYME P2P UZCARD NA
    💳 HUMOCARD *6205
    🕓 17:33 05.07.2026
    💰 56.413,45 UZS
"""
import asyncio
import re
from decimal import Decimal

from telethon import TelegramClient, events
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import TelethonSession, Payment, PaymentStatus, User, Link, ClickTaskDone
from app.services.crypto import decrypt

AMOUNT_RE = re.compile(r"➕\s*([\d.,]+)\s*UZS", re.IGNORECASE)
HUMO_BOT_USERNAME = "HUMOcardbot"


def parse_amount(text: str) -> Decimal | None:
    match = AMOUNT_RE.search(text)
    if not match:
        return None
    raw = match.group(1).replace(".", "").replace(",", ".")
    # Yuqoridagi namunada "." ming ajratkich, "," esa kasr qismi —
    # O'zbek/rus formatida SMS kelishiga qarab buni sozlash kerak bo'lishi mumkin.
    try:
        return Decimal(raw)
    except Exception:
        return None


def match_payment(db: Session, amount: Decimal, raw_message: str) -> bool:
    payment = (
        db.query(Payment)
        .filter(Payment.status == PaymentStatus.pending, Payment.expected_amount_uzs == amount)
        .order_by(Payment.created_at.asc())
        .first()
    )
    if not payment:
        return False

    payment.status = PaymentStatus.matched
    payment.matched_amount_uzs = amount
    payment.humo_raw_message = raw_message
    from sqlalchemy.sql import func
    payment.matched_at = func.now()

    # Shu vazifani "bajarildi" deb belgilash — foydalanuvchi keyingi
    # /status so'rovida darhol ko'radi
    if payment.task_id and payment.click_id:
        already = (
            db.query(ClickTaskDone)
            .filter(ClickTaskDone.click_id == payment.click_id, ClickTaskDone.task_id == payment.task_id)
            .first()
        )
        if not already:
            db.add(ClickTaskDone(click_id=payment.click_id, task_id=payment.task_id))

    # Kreator balansini oshirish (komissiyani ayirib)
    if payment.link_id:
        link = db.query(Link).filter(Link.id == payment.link_id).first()
        if link:
            creator = db.query(User).filter(User.id == link.creator_id).first()
            if creator:
                from app.services.settings_service import get_commission_percent
                commission = get_commission_percent(db)
                net = amount * (Decimal(100) - commission) / Decimal(100)
                creator.balance_uzs += net

    db.commit()
    return True


async def run():
    db = SessionLocal()
    session_row = (
        db.query(TelethonSession)
        .filter(TelethonSession.is_connected == True)  # noqa: E712
        .order_by(TelethonSession.created_at.desc())
        .first()
    )
    if not session_row:
        print("Ulangan Telethon sessiyasi topilmadi. Avval admin paneldan ulang.")
        return

    session_string = decrypt(session_row.session_string_encrypted)
    client = TelegramClient(
        session=session_string,
        api_id=int(session_row.api_id),
        api_hash=session_row.api_hash,
    )

    @client.on(events.NewMessage(from_users=HUMO_BOT_USERNAME))
    async def handler(event):
        text = event.raw_text
        amount = parse_amount(text)
        if amount is None:
            return
        session = SessionLocal()
        try:
            matched = match_payment(session, amount, text)
            print(f"[HUMO] {amount} UZS -> {'moslashtirildi' if matched else 'mos to‘lov topilmadi'}")
        finally:
            session.close()

    await client.start()
    print("HUMO parser ishga tushdi, xabarlar tinglanmoqda...")
    await client.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(run())
