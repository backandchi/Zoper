"""
Ad Mediation — bir nechta reklama tarmog'i (Monetag, PopAds, PropellerAds, ...)
orasidan eng yaxshi ishlayotganini tanlaydi.

MVP mantiq: bazadagi eng yuqori avg_cpm_usd'ga ega FAOL tarmoq tanlanadi.
avg_cpm_usd qiymati fon vazifasi (scheduler.py) tomonidan har bir tarmoqning
statistika API'sidan davriy ravishda yangilanadi.

Statistika hali yig'ilmagan (barcha tarmoqlarda avg_cpm_usd = 0) bo'lsa,
round-robin (tasodifiy tanlov) qo'llaniladi — shu orqali barcha tarmoqlar
teng sinaladi va statistika tez to'planadi.
"""
import random

from sqlalchemy.orm import Session

from app.models import AdNetwork


def pick_best_ad_network(db: Session) -> dict | None:
    networks = db.query(AdNetwork).filter(AdNetwork.is_active == True).all()  # noqa: E712
    if not networks:
        return None

    has_stats = any(n.avg_cpm_usd and n.avg_cpm_usd > 0 for n in networks)

    if has_stats:
        best = max(networks, key=lambda n: n.avg_cpm_usd or 0)
    else:
        best = random.choice(networks)

    return {
        "network": best.name,
        "zone_id": best.zone_id,
        "script": best.script_snippet,
    }
