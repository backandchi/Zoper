from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql://lootuz:lootuz@localhost:5432/lootuz"

    jwt_secret: str = "change_this_to_a_long_random_string"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60 * 24 * 30

    telegram_bot_token: str = ""
    telegram_bot_username: str = ""

    seed_admin_telegram_id: str = "7965397133"

    tg_api_id: str = ""
    tg_api_hash: str = ""
    tg_phone: str = ""

    min_withdrawal_uzs: int = 20000
    default_commission_percent: int = 15

    public_base_url: str = "https://pips.uz"

    # Supabase — asosiy PostgreSQL bilan BIRGA ishlaydigan ikkinchi saqlash joyi.
    # Backend har bir muhim yozuvdan so'ng (foydalanuvchi, link, click, pul yechish)
    # shu yerga ham nusxa yuboradi (best-effort — Supabase ishlamasa ham asosiy
    # baza va API javobi buzilmaydi).
    supabase_url: str = ""
    supabase_service_key: str = ""
    supabase_sync_enabled: bool = True

    class Config:
        env_file = ".env"


settings = Settings()
