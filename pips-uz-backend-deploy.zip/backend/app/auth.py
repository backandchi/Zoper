import hashlib
import hmac
import time
from datetime import datetime, timedelta

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from sqlalchemy.orm import Session

from fastapi import Header
from sqlalchemy.sql import func

from app.config import settings
from app.database import get_db
from app.models import User, ApiKey

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/telegram", auto_error=False)


def get_api_creator(
    x_api_key: str = Header(None, alias="X-API-Key"),
    db: Session = Depends(get_db),
) -> User:
    """
    Developer API uchun autentifikatsiya — JWT emas, doimiy API kalit
    (header: X-API-Key). Har bir muvaffaqiyatli chaqiruvda last_used_at
    yangilanadi, shunda kreator dashboardida kalit qachon oxirgi marta
    ishlatilganini ko'rish mumkin.
    """
    if not x_api_key:
        raise HTTPException(status_code=401, detail="X-API-Key sarlavhasi talab qilinadi")

    key_row = db.query(ApiKey).filter(ApiKey.key == x_api_key, ApiKey.is_active == True).first()  # noqa: E712
    if not key_row:
        raise HTTPException(status_code=401, detail="API kalit noto'g'ri yoki faol emas")

    creator = db.query(User).filter(User.id == key_row.creator_id).first()
    if not creator or creator.is_blocked:
        raise HTTPException(status_code=401, detail="Hisob faol emas")

    key_row.last_used_at = func.now()
    db.commit()

    return creator


def verify_telegram_login(data: dict) -> bool:
    """
    Telegram Login Widget hash tekshiruvi.
    https://core.telegram.org/widgets/login#checking-authorization
    Bu qadam MAJBURIY — aks holda istalgan kishi soxta telegram_id bilan
    kirib olishi mumkin.
    """
    received_hash = data.get("hash")
    if not received_hash:
        return False

    check_data = {k: v for k, v in data.items() if k != "hash"}
    data_check_string = "\n".join(
        f"{k}={check_data[k]}" for k in sorted(check_data.keys())
    )

    secret_key = hashlib.sha256(settings.telegram_bot_token.encode()).digest()
    computed_hash = hmac.new(
        secret_key, data_check_string.encode(), hashlib.sha256
    ).hexdigest()

    if computed_hash != received_hash:
        return False

    # auth_date 24 soatdan eski bo'lmasligi kerak (replay hujumidan himoya)
    auth_date = int(data.get("auth_date", 0))
    if time.time() - auth_date > 86400:
        return False

    return True


def create_access_token(user_id: str, is_admin: bool) -> str:
    expire = datetime.utcnow() + timedelta(minutes=settings.jwt_expire_minutes)
    payload = {"sub": user_id, "is_admin": is_admin, "exp": expire}
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def get_current_user(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Tizimga kirish talab qilinadi",
    )
    if not token:
        raise credentials_exception
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = db.query(User).filter(User.id == user_id).first()
    if user is None or user.is_blocked:
        raise credentials_exception
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Faqat admin uchun ruxsat berilgan")
    return user
