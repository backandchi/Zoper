from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel


# ---------- Auth ----------
class TelegramLoginPayload(BaseModel):
    id: int
    first_name: Optional[str] = None
    username: Optional[str] = None
    photo_url: Optional[str] = None
    auth_date: int
    hash: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    is_admin: bool


# ---------- User ----------
class MeResponse(BaseModel):
    id: str
    telegram_id: int
    username: Optional[str]
    first_name: Optional[str]
    is_admin: bool
    balance_uzs: Decimal

    class Config:
        from_attributes = True


# ---------- Tasks (link ostidagi tugmalar) ----------
class TaskCreate(BaseModel):
    type: str  # ad | channel | payment | custom
    label: Optional[str] = None
    channel_username: Optional[str] = None
    custom_url: Optional[str] = None
    price_uzs: Optional[Decimal] = None


class TaskOut(BaseModel):
    id: str
    order: int
    type: str
    label: Optional[str]
    channel_username: Optional[str]
    custom_url: Optional[str]
    price_uzs: Optional[Decimal]

    class Config:
        from_attributes = True


# ---------- Links ----------
class LinkCreate(BaseModel):
    target_url: str
    title: Optional[str] = None
    tasks: list[TaskCreate] = []


class LinkOut(BaseModel):
    id: str
    slug: str
    target_url: str
    title: Optional[str]
    is_active: bool
    created_at: datetime
    tasks: list[TaskOut] = []

    class Config:
        from_attributes = True


class LinkWithStats(LinkOut):
    total_clicks: int
    completed_clicks: int
    conversion_rate: float
    earnings_uzs: Decimal


class DailyPoint(BaseModel):
    date: str
    clicks: int
    completed: int


class LinkStats(BaseModel):
    link: LinkOut
    total_clicks: int
    completed_clicks: int
    conversion_rate: float
    earnings_uzs: Decimal
    daily: list[DailyPoint] = []


class DashboardSummary(BaseModel):
    balance_uzs: Decimal
    total_links: int
    active_links: int
    total_clicks: int
    completed_clicks: int
    total_earnings_uzs: Decimal
    daily: list[DailyPoint] = []


# ---------- Withdrawals ----------
class WithdrawalCreate(BaseModel):
    amount_uzs: Decimal
    card_number: str


class WithdrawalOut(BaseModel):
    id: str
    amount_uzs: Decimal
    card_number: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class WithdrawalDecision(BaseModel):
    approve: bool
    admin_note: Optional[str] = None


# ---------- Ad networks ----------
class AdNetworkCreate(BaseModel):
    name: str
    api_key: Optional[str] = None
    zone_id: Optional[str] = None
    script_snippet: Optional[str] = None


class AdNetworkOut(BaseModel):
    id: str
    name: str
    zone_id: Optional[str]
    is_active: bool
    avg_cpm_usd: Decimal
    last_synced_at: Optional[datetime]

    class Config:
        from_attributes = True


# ---------- Settings ----------
class SettingUpdate(BaseModel):
    key: str
    value: str


# ---------- Developer API ----------
class ApiKeyOut(BaseModel):
    id: str
    key: str
    label: Optional[str]
    is_active: bool
    last_used_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class ApiKeyCreate(BaseModel):
    label: Optional[str] = None


class ApiLinkCreate(BaseModel):
    """
    Dasturchilar uchun link yaratish so'rovi. `tasks` — istalgan sondagi
    vazifa (tugma), erkin aralashtirilishi mumkin: bir nechtasi kanal,
    bittasi reklama, bittasi to'lov va h.k.
    """
    target_url: str
    title: Optional[str] = None
    tasks: list[TaskCreate] = []


class ApiLinkOut(BaseModel):
    slug: str
    short_url: str
    target_url: str
    tasks: list[TaskOut] = []
    created_at: datetime


# ---------- Telethon / userbot ----------
class TelethonStep1(BaseModel):
    api_id: str
    api_hash: str
    phone: str


class TelethonStep2(BaseModel):
    code: str


class TelethonStep3(BaseModel):
    password: Optional[str] = None  # faqat 2FA yoqilgan bo'lsa kerak
