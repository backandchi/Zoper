# pips.uz backend — VPS'ga joylashtirish (Ubuntu/Debian)

DNS: `api.pips.uz` uchun A-yozuv shu VPS'ning IP manziliga yo'naltirilgan bo'lishi kerak
(asosiy `pips.uz` esa Vercel'dagi frontend uchun qoladi — pastda 6-bandga qarang).

## 1. Kodni serverga yuklash

Lokal kompyuteringizdan (yoki shu chatdan yuklab olingan zip'ni ochib):

```bash
scp -r backend root@SIZNING_IP:/opt/pips-uz-backend
ssh root@SIZNING_IP
cd /opt/pips-uz-backend
```

## 2. Docker o'rnatish

```bash
curl -fsSL https://get.docker.com | sh
apt-get install -y docker-compose-plugin
```

## 3. .env faylini sozlash

```bash
cp .env.example .env
nano .env
```

Albatta to'ldiring:
- `JWT_SECRET` — uzun tasodifiy satr (masalan: `openssl rand -hex 32`)
- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_BOT_USERNAME` — @BotFather'dan
- `SEED_ADMIN_TELEGRAM_ID` — o'zingizning Telegram ID'ingiz
- `SUPABASE_SERVICE_KEY` — Supabase dashboard → Project Settings → API →
  **service_role** kaliti (project: `kyxectvqxmuhozvlzvns`, URL allaqachon to'ldirilgan)
- `POSTGRES_PASSWORD` — yangi tasodifiy parol

## 4. Ishga tushirish

```bash
docker compose up -d --build
docker compose logs -f api   # xatolik yo'qligini tekshiring, Ctrl+C bilan chiqing
curl http://127.0.0.1:8000/api/health   # {"status":"ok"} qaytishi kerak
```

## 5. Nginx + SSL

```bash
apt-get install -y nginx certbot python3-certbot-nginx
cp deploy/api-pips-uz.conf /etc/nginx/sites-available/api-pips-uz.conf
ln -s /etc/nginx/sites-available/api-pips-uz.conf /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
certbot --nginx -d api.pips.uz
```

Tekshirish: `https://api.pips.uz/api/health` brauzerda `{"status":"ok"}` ko'rsatishi kerak.

## 6. Domen taqsimoti (DNS)

- `pips.uz` (root domen) → Vercel loyihasiga custom domain sifatida qo'shiladi
  (Vercel dashboard → pips-uz loyihasi → Settings → Domains → `pips.uz` qo'shing,
  Vercel ko'rsatgan A/CNAME yozuvini domen provayderingizda sozlang).
- `api.pips.uz` → shu VPS'ning IP manziliga A-yozuv (yuqoridagi kabi).

## 7. Yangilash (kod o'zgarganda)

```bash
cd /opt/pips-uz-backend
git pull   # yoki qayta scp qiling
docker compose up -d --build
```

## 8. Zaxira

Postgres ma'lumotlari `pips_pgdata` Docker volume'da saqlanadi. Zaxira nusxa:

```bash
docker compose exec db pg_dump -U lootuz lootuz > backup_$(date +%F).sql
```

(Eslatma: barcha muhim yozuvlar Supabase'ga ham parallel saqlanadi — bu qo'shimcha xavfsizlik qatlami.)
