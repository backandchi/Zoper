-- pips.uz — Supabase "ikkinchi nusxa" sxemasi
--
-- Bu jadvallar asosiy PostgreSQL (SQLAlchemy/FastAPI) bazasidagi struktura
-- bilan bir xil ID'larni ishlatadi (backend UUID'larni o'zi yaratadi va
-- ikkala bazaga ham bir xil ID bilan yozadi), shuning uchun kelajakda
-- solishtirish/migratsiya oson bo'ladi.
--
-- Ishlatish: Supabase loyihangizda SQL Editor'ni oching va shu faylni
-- to'liq ishga tushiring (yoki Claude orqali "Supabase" connectori
-- tasdiqlangach avtomatik qo'llanadi).

create table if not exists users (
  id uuid primary key,
  telegram_id bigint unique not null,
  username text,
  first_name text,
  photo_url text,
  is_admin boolean not null default false,
  is_blocked boolean not null default false,
  balance_uzs numeric(14,2) not null default 0,
  created_at timestamptz default now()
);

create table if not exists links (
  id uuid primary key,
  creator_id uuid references users(id) on delete cascade,
  slug text unique not null,
  target_url text not null,
  title text,
  is_active boolean not null default true,
  created_at timestamptz default now()
);

create table if not exists tasks (
  id uuid primary key,
  link_id uuid references links(id) on delete cascade,
  "order" integer not null default 0,
  type text not null,
  label text,
  channel_username text,
  custom_url text,
  price_uzs numeric(14,2),
  created_at timestamptz default now()
);

create table if not exists clicks (
  id uuid primary key,
  link_id uuid references links(id) on delete cascade,
  ip_address text,
  user_agent text,
  fingerprint text,
  step_completed text,
  completed boolean not null default false,
  created_at timestamptz default now()
);

create table if not exists withdrawals (
  id uuid primary key,
  creator_id uuid references users(id) on delete cascade,
  amount_uzs numeric(14,2) not null,
  card_number text not null,
  status text not null default 'pending',
  admin_note text,
  created_at timestamptz default now()
);

create table if not exists payments (
  id uuid primary key,
  link_id uuid references links(id) on delete set null,
  task_id uuid references tasks(id) on delete set null,
  click_id uuid references clicks(id) on delete set null,
  expected_amount_uzs numeric(14,2) not null,
  matched_amount_uzs numeric(14,2),
  status text not null default 'pending',
  created_at timestamptz default now()
);

-- Backend service_role kaliti bilan yozadi (RLS'ni chetlab o'tadi), shuning
-- uchun bu yerda RLS yoqilmagan qoldirildi. Agar kelajakda frontend to'g'ridan-
-- to'g'ri (anon key bilan) Supabase'ga so'rov yubormoqchi bo'lsa, albatta:
--   alter table users enable row level security;
-- kabi siyosatlar qo'shilishi kerak.

create index if not exists idx_links_creator on links(creator_id);
create index if not exists idx_clicks_link on clicks(link_id);
create index if not exists idx_withdrawals_creator on withdrawals(creator_id);
create index if not exists idx_tasks_link on tasks(link_id);
