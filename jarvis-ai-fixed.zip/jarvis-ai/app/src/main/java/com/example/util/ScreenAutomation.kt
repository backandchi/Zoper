package com.example.util

import android.content.Context
import com.example.service.AikoAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Chains [DeviceController] (app launching / deep links) together with
 * [AikoAccessibilityService] (screen reading + tapping) so voice commands actually
 * FINISH — e.g. not just opening Telegram with a message pre-typed, but pressing
 * Send too, like a person would.
 *
 * Requires the person to have turned on "AIKO — Ekran Boshqaruvi" once under
 * Settings > Accessibility (Android requires this manual opt-in; AIKO cannot enable
 * it for itself). If it isn't on yet, these functions still do the app-opening /
 * deep-link part and clearly say what's missing instead of silently failing.
 */
object ScreenAutomation {

    val isAvailable: Boolean
        get() = AikoAccessibilityService.isConnected.value

    private val sendLabels = listOf("Send", "Yuborish", "Jo'natish", "Jonatish", "Gönder")

    /** Opens the Telegram chat with [target] with [message] pre-typed, then presses Send. */
    suspend fun sendTelegramMessage(
        context: Context,
        deviceController: DeviceController,
        target: String,
        message: String
    ): String = withContext(Dispatchers.Main) {
        val opened = deviceController.sendTelegramMessage(target, message)
        if (!opened) return@withContext "Telegram'ni ochib bo'lmadi — o'rnatilganiga ishonch hosil qiling."

        val service = AikoAccessibilityService.getInstance()
            ?: return@withContext "Telegram ochildi, xabar tayyor turibdi. To'liq avtomatik yuborish uchun Sozlamalarda \"AIKO — Ekran Boshqaruvi\"ni yoqing."

        service.waitForScreen(1600)
        val tapped = sendLabels.any { service.tapByText(it) } || tapSendByPosition(context, service)
        return@withContext if (tapped) {
            "✅ Telegram orqali \"$target\" ga xabar yuborildi: \"$message\""
        } else {
            "Telegram ochildi va xabar tayyorlandi, lekin Yuborish tugmasini avtomatik bosib bo'lolmadim — birmarta qo'lda bosib yuboring."
        }
    }

    /** Opens the WhatsApp chat with [phoneNumber] with [message] pre-typed, then presses Send. */
    suspend fun sendWhatsAppMessage(
        context: Context,
        deviceController: DeviceController,
        phoneNumber: String,
        message: String
    ): String = withContext(Dispatchers.Main) {
        val opened = deviceController.sendWhatsAppMessage(phoneNumber, message)
        if (!opened) return@withContext "WhatsApp'ni ochib bo'lmadi — o'rnatilganiga ishonch hosil qiling."

        val service = AikoAccessibilityService.getInstance()
            ?: return@withContext "WhatsApp ochildi, xabar tayyor turibdi. To'liq avtomatik yuborish uchun Sozlamalarda \"AIKO — Ekran Boshqaruvi\"ni yoqing."

        service.waitForScreen(1600)
        val tapped = sendLabels.any { service.tapByText(it) } || tapSendByPosition(context, service)
        return@withContext if (tapped) {
            "✅ WhatsApp orqali xabar yuborildi: \"$message\""
        } else {
            "WhatsApp ochildi va xabar tayyorlandi, lekin Yuborish tugmasini avtomatik bosib bo'lolmadim — birmarta qo'lda bosib yuboring."
        }
    }

    /** Reads back a short summary of what's currently visible on screen. */
    fun describeCurrentScreen(): String {
        val service = AikoAccessibilityService.getInstance()
            ?: return "Ekranni o'qish uchun Sozlamalarda \"AIKO — Ekran Boshqaruvi\"ni yoqing."
        return service.describeScreen()
    }

    /** Last-resort tap at the bottom-right corner, where chat apps consistently place Send. */
    private fun tapSendByPosition(context: Context, service: AikoAccessibilityService): Boolean {
        val metrics = context.resources.displayMetrics
        val x = metrics.widthPixels * 0.93f
        val y = metrics.heightPixels * 0.93f
        return service.tapAt(x, y)
    }
}
