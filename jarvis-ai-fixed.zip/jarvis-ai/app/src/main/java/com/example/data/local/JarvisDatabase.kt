package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        MemoryEntity::class,
        TaskEntity::class,
        ProtocolEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class JarvisDatabase : RoomDatabase() {

    abstract fun jarvisDao(): JarvisDao

    companion object {
        @Volatile
        private var INSTANCE: JarvisDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): JarvisDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JarvisDatabase::class.java,
                    "jarvis_database"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.jarvisDao())
                    }
                }
            }

            suspend fun populateInitialData(dao: JarvisDao) {
                // Initial Default Memories
                dao.insertMemory(
                    MemoryEntity(
                        category = "System",
                        title = "Asosiy parametr",
                        content = "Foydalanuvchi menga buyruqlarni o'zbek yoki ingliz tilida berishi mumkin. Men uning shaxsiy sun'iy intellekt yordamchisi JARVIS'man.",
                        isPinned = true
                    )
                )

                // Initial Tasks
                dao.insertTask(
                    TaskEntity(
                        title = "JARVIS ovozli boshqaruvini sinab ko'rish",
                        details = "Mikrofon tugmasini bosing yoki 'Salom Jarvis' deb buyruq bering",
                        priority = "High",
                        isCompleted = false
                    )
                )

                // Initial Pre-configured Voice Protocols
                val defaultProtocols = listOf(
                    ProtocolEntity(
                        name = "Protokol Tungi / Night Mode",
                        triggerPhrase = "tungi rejim",
                        actionType = "NIGHT_PROTOCOL",
                        actionData = "Chiroqni o'chirish va tinch rejim",
                        description = "Chiroqni o'chiradi, ovozni pasaytiradi va tungi xulosa beradi."
                    ),
                    ProtocolEntity(
                        name = "Protokol Chiroq / Torch",
                        triggerPhrase = "chiroqni yoq",
                        actionType = "FLASHLIGHT_ON",
                        actionData = "true",
                        description = "Kamera chirog'ini darhol yoqadi."
                    ),
                    ProtocolEntity(
                        name = "Protokol Batareya / Battery Check",
                        triggerPhrase = "quvvat qancha",
                        actionType = "BATTERY_CHECK",
                        actionData = "status",
                        description = "Qurilmaning batareya holati va haroratini aytib beradi."
                    ),
                    ProtocolEntity(
                        name = "Protokol Vazifalar / Read Tasks",
                        triggerPhrase = "rejam nima",
                        actionType = "READ_TASKS",
                        actionData = "tasks",
                        description = "Bajarilmagan barcha vazifalarni ovozli o'qib beradi."
                    )
                )
                dao.insertProtocols(defaultProtocols)

                // Initial Welcome Chat Message
                dao.insertMessage(
                    ChatMessageEntity(
                        role = "jarvis",
                        message = "Salom, Janob! Men sizning shaxsiy sun'iy intellektingiz JARVIS'man. Barcha tizimlar ishga tushdi va buyruqlaringizni qabul qilishga tayyorman. Menga ovozli yoki yozma buyruq berishingiz mumkin.",
                        modelName = "gemini-3.5-flash",
                        isVoice = false
                    )
                )
            }
        }
    }
}
