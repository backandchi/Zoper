package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.MemoryEntity
import com.example.data.local.ProtocolEntity
import com.example.data.local.TaskEntity
import com.example.ui.JarvisViewModel
import com.example.ui.components.HolographicCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MemoryScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val protocols by viewModel.protocols.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var showAddMemoryDialog by remember { mutableStateOf(false) }
    var showAddTaskDialog by remember { mutableStateOf(false) }

    val tabTitles = listOf("Xotira Banki", "Vazifalar", "Protokollar")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ProfessionalDarkBg,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTabIndex == 0) showAddMemoryDialog = true
                    else if (selectedTabIndex == 1) showAddTaskDialog = true
                },
                containerColor = ProfessionalBluePrimary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 72.dp)
                    .testTag("fab_add_item")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Qo'shish")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "A.R.K.A.S KNOWLEDGE MATRIX",
                        color = ProfessionalBlueLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Memory & Tasks",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Light
                    )
                }

                StatusBadge(
                    text = "${memories.size + tasks.size} Elements",
                    color = ProfessionalBlueLight
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tab Selector
            Surface(
                color = ProfessionalSurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = Color.Transparent,
                    contentColor = ProfessionalBlueLight,
                    divider = {},
                    indicator = {}
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        val isSelected = selectedTabIndex == index
                        Tab(
                            selected = isSelected,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = title,
                                    color = if (isSelected) ProfessionalBlueLight else ProfessionalTextMuted,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier
                                .padding(4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) ProfessionalCardBg else Color.Transparent)
                                .testTag("tab_$index")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (selectedTabIndex) {
                0 -> MemoriesTab(
                    memories = memories,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { searchQuery = it },
                    onDeleteMemory = { viewModel.deleteMemory(it) },
                    onAskJarvis = { memory ->
                        viewModel.processCommand("Eslab qolgan xotirang haqida aytib ber: ${memory.title}")
                    }
                )
                1 -> TasksTab(
                    tasks = tasks,
                    onToggleComplete = { viewModel.toggleTaskCompletion(it) },
                    onDeleteTask = { viewModel.deleteTask(it) }
                )
                2 -> ProtocolsTab(
                    protocols = protocols,
                    onExecute = { viewModel.executeProtocol(it) }
                )
            }
        }
    }

    // Add Memory Dialog
    if (showAddMemoryDialog) {
        AddMemoryDialog(
            onDismiss = { showAddMemoryDialog = false },
            onConfirm = { category, title, content ->
                viewModel.addCustomMemory(category, title, content)
                showAddMemoryDialog = false
            }
        )
    }

    // Add Task Dialog
    if (showAddTaskDialog) {
        AddTaskDialog(
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, priority ->
                viewModel.addNewTask(title, priority)
                showAddTaskDialog = false
            }
        )
    }
}

@Composable
fun MemoriesTab(
    memories: List<MemoryEntity>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit,
    onAskJarvis: (MemoryEntity) -> Unit
) {
    val filteredMemories = remember(memories, searchQuery) {
        if (searchQuery.isBlank()) memories
        else memories.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.content.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search TextField
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("memory_search_input"),
            placeholder = { Text("Xotiradan qidirish...", color = ProfessionalTextMuted, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ProfessionalBlueLight) },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Tozalash", tint = ProfessionalTextSecondary)
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ProfessionalBlueLight,
                unfocusedBorderColor = ProfessionalCardBorder,
                focusedContainerColor = ProfessionalCardBg,
                unfocusedContainerColor = ProfessionalCardBg,
                focusedTextColor = ProfessionalTextPrimary,
                unfocusedTextColor = ProfessionalTextPrimary
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredMemories.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = ProfessionalTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (searchQuery.isBlank()) "Hozircha hech qanday xotira saqlanmagan.\n'Eslab qol: ...' deb buyruq bering!" else "Qidiruv bo'yicha ma'lumot topilmadi.",
                        color = ProfessionalTextSecondary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredMemories, key = { it.id }) { memory ->
                    MemoryItemCard(
                        memory = memory,
                        onDelete = { onDeleteMemory(memory) },
                        onAskJarvis = { onAskJarvis(memory) }
                    )
                }
            }
        }
    }
}

@Composable
fun MemoryItemCard(
    memory: MemoryEntity,
    onDelete: () -> Unit,
    onAskJarvis: () -> Unit
) {
    val categoryColor = when (memory.category) {
        "Keys & Passwords" -> ProfessionalCrimson
        "Preference" -> ProfessionalGold
        "Location" -> ProfessionalEmerald
        else -> ProfessionalBlueLight
    }

    val dateStr = remember(memory.timestamp) {
        SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(memory.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("memory_card_${memory.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(text = memory.category, color = categoryColor)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = dateStr, color = ProfessionalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                Row {
                    IconButton(onClick = onAskJarvis, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "O'qish", tint = ProfessionalBlueLight, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "O'chirish", tint = ProfessionalTextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = memory.title,
                color = ProfessionalTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (memory.content.isNotBlank() && memory.content != memory.title) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = memory.content,
                    color = ProfessionalTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun TasksTab(
    tasks: List<TaskEntity>,
    onToggleComplete: (TaskEntity) -> Unit,
    onDeleteTask: (TaskEntity) -> Unit
) {
    if (tasks.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.TaskAlt, contentDescription = null, tint = ProfessionalTextMuted, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Vazifalar ro'yxati bo'sh.\n'Vazifa qo'sh: ...' deb buyruq bering!",
                    color = ProfessionalTextSecondary,
                    fontSize = 13.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(tasks, key = { it.id }) { task ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_card_${task.id}"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (task.isCompleted) ProfessionalCardBorder else ProfessionalEmerald.copy(alpha = 0.35f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = task.isCompleted,
                            onCheckedChange = { onToggleComplete(task) },
                            colors = CheckboxDefaults.colors(
                                checkedColor = ProfessionalEmerald,
                                uncheckedColor = ProfessionalTextSecondary,
                                checkmarkColor = Color.White
                            ),
                            modifier = Modifier.testTag("task_checkbox_${task.id}")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                color = if (task.isCompleted) ProfessionalTextMuted else ProfessionalTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                style = if (task.isCompleted) androidx.compose.ui.text.TextStyle(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough) else androidx.compose.ui.text.TextStyle()
                            )
                            if (task.priority == "High") {
                                StatusBadge(text = "YUQORI PRIORITET", color = ProfessionalCrimson)
                            }
                        }

                        IconButton(onClick = { onDeleteTask(task) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "O'chirish", tint = ProfessionalTextMuted, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProtocolsTab(
    protocols: List<ProtocolEntity>,
    onExecute: (ProtocolEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "AUTOMATED VOICE PROTOCOLS",
                color = ProfessionalTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(protocols, key = { it.id }) { protocol ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("protocol_card_${protocol.id}"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = protocol.name,
                            color = ProfessionalBlueLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Ovozli buyruq: \"${protocol.triggerPhrase}\"",
                            color = ProfessionalGold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        if (protocol.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = protocol.description,
                                color = ProfessionalTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Button(
                        onClick = { onExecute(protocol) },
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalBlueLight.copy(alpha = 0.15f), contentColor = ProfessionalBlueLight),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalBlueLight.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("protocol_run_btn_${protocol.id}")
                    ) {
                        Text("Ishga tushur", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddMemoryDialog(
    onDismiss: () -> Unit,
    onConfirm: (category: String, title: String, content: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }

    val categories = listOf("General", "Keys & Passwords", "Preference", "Location", "Routine")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ProfessionalCardBg,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(text = "Yangi Xotira Saqlash", color = ProfessionalBlueLight, fontWeight = FontWeight.SemiBold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Sarlavha (masalan: Garaj kodi)") },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ProfessionalTextPrimary,
                        unfocusedTextColor = ProfessionalTextPrimary,
                        focusedBorderColor = ProfessionalBlueLight,
                        unfocusedBorderColor = ProfessionalCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Tafsilot (masalan: 9876)") },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ProfessionalTextPrimary,
                        unfocusedTextColor = ProfessionalTextPrimary,
                        focusedBorderColor = ProfessionalBlueLight,
                        unfocusedBorderColor = ProfessionalCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(category, title, content)
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ProfessionalBluePrimary, contentColor = Color.White)
            ) {
                Text("Saqlash")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Bekor qilish", color = ProfessionalTextSecondary)
            }
        }
    )
}

@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, priority: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Normal") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ProfessionalCardBg,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(text = "Yangi Vazifa Kiritish", color = ProfessionalEmerald, fontWeight = FontWeight.SemiBold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Vazifa nomi") },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ProfessionalTextPrimary,
                        unfocusedTextColor = ProfessionalTextPrimary,
                        focusedBorderColor = ProfessionalEmerald,
                        unfocusedBorderColor = ProfessionalCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, priority)
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ProfessionalEmerald, contentColor = Color.White)
            ) {
                Text("Qo'shish")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Bekor qilish", color = ProfessionalTextSecondary)
            }
        }
    )
}
