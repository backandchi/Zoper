package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.remote.GeminiService
import com.example.data.repository.JarvisRepository
import com.example.util.DeviceController
import com.example.util.InstalledAppItem
import com.example.util.SpeechEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val deviceController = DeviceController(application)
    val speechEngine = SpeechEngine(application, viewModelScope)

    private val database = JarvisDatabase.getDatabase(application, viewModelScope)
    val repository = JarvisRepository(database.jarvisDao())

    // Database reactive streams
    val memories: StateFlow<List<MemoryEntity>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val protocols: StateFlow<List<ProtocolEntity>> = repository.allProtocols
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state
    private val _selectedModel = MutableStateFlow("gemini-3.5-flash")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _isThinkingModeEnabled = MutableStateFlow(false)
    val isThinkingModeEnabled: StateFlow<Boolean> = _isThinkingModeEnabled.asStateFlow()

    private val _isSearchGroundingEnabled = MutableStateFlow(true)
    val isSearchGroundingEnabled: StateFlow<Boolean> = _isSearchGroundingEnabled.asStateFlow()

    private val _isTtsAutoPlay = MutableStateFlow(true)
    val isTtsAutoPlay: StateFlow<Boolean> = _isTtsAutoPlay.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _lastActionStatus = MutableStateFlow<String?>(null)
    val lastActionStatus: StateFlow<String?> = _lastActionStatus.asStateFlow()

    // Multimodal Studio States
    private val _generatedImageBase64 = MutableStateFlow<String?>(null)
    val generatedImageBase64: StateFlow<String?> = _generatedImageBase64.asStateFlow()

    private val _generatedMusicBytes = MutableStateFlow<ByteArray?>(null)
    val generatedMusicBytes: StateFlow<ByteArray?> = _generatedMusicBytes.asStateFlow()

    private val _studioStatusMessage = MutableStateFlow<String?>(null)
    val studioStatusMessage: StateFlow<String?> = _studioStatusMessage.asStateFlow()

    private val _transcriptionText = MutableStateFlow<String?>(null)
    val transcriptionText: StateFlow<String?> = _transcriptionText.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppItem>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppItem>> = _installedApps.asStateFlow()

    // Gemini API keys — unlimited amount, stored locally, auto-rotated when one hits its quota
    val geminiApiKeys: StateFlow<List<String>> = ApiKeyStore.getKeysFlow(application)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addGeminiApiKey(key: String) {
        viewModelScope.launch(Dispatchers.IO) {
            ApiKeyStore.addKey(getApplication(), key)
        }
    }

    fun removeGeminiApiKey(key: String) {
        viewModelScope.launch(Dispatchers.IO) {
            ApiKeyStore.removeKey(getApplication(), key)
        }
    }

    init {
        speechEngine.onSpeechRecognized = { text ->
            processCommand(text, isVoiceInput = true)
        }
        refreshInstalledApps()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _installedApps.value = deviceController.getInstalledApps()
        }
    }

    fun launchInstalledApp(packageName: String): Boolean {
        return deviceController.launchByPackageName(packageName)
    }

    fun setModel(model: String) {
        _selectedModel.value = model
    }

    fun toggleThinkingMode() {
        val next = !_isThinkingModeEnabled.value
        _isThinkingModeEnabled.value = next
        if (next) {
            _selectedModel.value = "gemini-3.1-pro-preview"
        } else if (_selectedModel.value == "gemini-3.1-pro-preview") {
            _selectedModel.value = "gemini-3.5-flash"
        }
    }

    fun toggleSearchGrounding() {
        _isSearchGroundingEnabled.value = !_isSearchGroundingEnabled.value
    }

    fun toggleTtsAutoPlay() {
        _isTtsAutoPlay.value = !_isTtsAutoPlay.value
    }

    fun startListening() {
        deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        speechEngine.startListening()
    }

    fun stopListening() {
        speechEngine.stopListening()
    }

    fun stopSpeaking() {
        speechEngine.stopAudio()
    }

    /**
     * Central Jarvis Intent Analyzer & Executor
     */
    fun processCommand(input: String, isVoiceInput: Boolean = false) {
        val prompt = input.trim()
        if (prompt.isBlank()) return

        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _lastActionStatus.value = null

            // 1. Save user turn to chat history
            repository.saveMessage(role = "user", message = prompt, isVoice = isVoiceInput)

            val lower = prompt.lowercase(Locale.ROOT)

            // 2. Check Direct Hardware & Action Commands
            var handledLocally = false
            var responseText = ""
            var actionTag: String? = null

            when {
                // Flashlight ON
                lower.contains("chiroqni yoq") || lower.contains("fonar yoq") || lower.contains("turn on flashlight") || lower.contains("torch on") -> {
                    deviceController.setFlashlight(true)
                    responseText = "Kamera chirog'i yoqildi, Janob."
                    actionTag = "FLASHLIGHT_ON"
                    handledLocally = true
                }
                // Flashlight OFF
                lower.contains("chiroqni o'chir") || lower.contains("chiroqni ochir") || lower.contains("fonar o'chir") || lower.contains("turn off flashlight") || lower.contains("torch off") -> {
                    deviceController.setFlashlight(false)
                    responseText = "Chiroq o'chirildi."
                    actionTag = "FLASHLIGHT_OFF"
                    handledLocally = true
                }
                // Battery Check
                lower.contains("quvvat") || lower.contains("batareya") || lower.contains("battery") -> {
                    deviceController.updateBatteryInfo()
                    val b = deviceController.batteryInfo.value
                    responseText = "Qurilmangiz quvvati hozirda ${b.level}%. Harorat: ${b.temperatureCelsius}°C. ${if (b.isCharging) "Zaryadlanmoqda." else "Zaryadlanmayapti."}"
                    actionTag = "BATTERY_CHECK"
                    handledLocally = true
                }
                // Remember / Memory store: "eslab qol: ...", "remember: ...", "xotiraga saqla: ..."
                lower.startsWith("eslab qol") || lower.startsWith("remember") || lower.startsWith("xotiraga saqla") || lower.startsWith("eslatma:") -> {
                    val cleanContent = prompt
                        .replace(Regex("^(eslab qol[:\\s]*|remember[:\\s]*|xotiraga saqla[:\\s]*|eslatma[:\\s]*)", RegexOption.IGNORE_CASE), "")
                        .trim()

                    if (cleanContent.isNotBlank()) {
                        val category = when {
                            cleanContent.contains("parol", true) || cleanContent.contains("kod", true) || cleanContent.contains("kalit", true) -> "Keys & Passwords"
                            cleanContent.contains("manzil", true) || cleanContent.contains("joy", true) -> "Location"
                            cleanContent.contains("odati", true) || cleanContent.contains("yoqtir", true) -> "Preference"
                            else -> "General"
                        }
                        repository.addMemory(
                            category = category,
                            title = cleanContent.take(30) + (if (cleanContent.length > 30) "..." else ""),
                            content = cleanContent,
                            isPinned = true
                        )
                        responseText = "Bajarildi, Janob! Xotiraga saqlab qoldim: \"$cleanContent\"."
                        actionTag = "MEMORY_SAVED"
                        handledLocally = true
                    }
                }
                // Task add: "vazifa qo'sh: ...", "add task: ...", "reja: ..."
                lower.startsWith("vazifa") || lower.startsWith("add task") || lower.startsWith("reja:") -> {
                    val cleanTask = prompt
                        .replace(Regex("^(vazifa qo'sh[:\\s]*|vazifa[:\\s]*|add task[:\\s]*|reja[:\\s]*)", RegexOption.IGNORE_CASE), "")
                        .trim()
                    if (cleanTask.isNotBlank()) {
                        repository.addTask(title = cleanTask, priority = "High")
                        responseText = "Yangi vazifa ro'yxatingizga kiritildi: \"$cleanTask\"."
                        actionTag = "TASK_ADDED"
                        handledLocally = true
                    }
                }
                // Read tasks: "rejalarim nima", "vazifalarni ayt", "my tasks"
                lower.contains("rejam nima") || lower.contains("vazifalarim") || lower.contains("read tasks") -> {
                    val active = repository.getActiveTasks()
                    responseText = if (active.isEmpty()) {
                        "Sizda hozircha bajarilmagan vazifalar mavjud emas, Janob."
                    } else {
                        "Sizning faol vazifalaringiz:\n" + active.mapIndexed { idx, t -> "${idx + 1}. ${t.title}" }.joinToString("\n")
                    }
                    actionTag = "TASKS_READ"
                    handledLocally = true
                }
                // Night Protocol
                lower.contains("tungi rejim") || lower.contains("protocol night") -> {
                    deviceController.setFlashlight(false)
                    deviceController.setSilentMode(true)
                    responseText = "Tungi protokol ishga tushirildi: chiroq o'chirildi, ovoz tinch rejimga o'tkazildi. Xayrli tun, Janob."
                    actionTag = "PROTOCOL_NIGHT"
                    handledLocally = true
                }
                // Telegram Message
                lower.startsWith("telegram") || lower.contains("telegramda") || lower.contains("telegram orqali") -> {
                    val rawMsg = prompt.replace(Regex("^(telegram(da|dan| orqali)?\\s*(xabar yubor|yoz|jo'nat|jonat)?[:\\s]*)", RegexOption.IGNORE_CASE), "").trim()
                    // Check if there's username/recipient specified like "Aliga salom deb yoz" or "@ali Salom"
                    val userMatch = Regex("@([a-zA-Z0-9_]+)").find(rawMsg)
                    val targetUser = userMatch?.groupValues?.get(1) ?: ""
                    val messageText = if (targetUser.isNotBlank()) rawMsg.replace("@$targetUser", "").trim() else rawMsg
                    
                    deviceController.sendTelegramMessage(targetUser, messageText)
                    responseText = if (messageText.isNotBlank()) {
                        "Telegram orqali xabar tayyorlandi: \"$messageText\""
                    } else {
                        "Telegram ilovasi ochilmoqda..."
                    }
                    actionTag = "TELEGRAM_MSG"
                    handledLocally = true
                }
                // WhatsApp Message
                lower.startsWith("whatsapp") || lower.contains("whatsappda") || lower.contains("vatsap") -> {
                    val rawMsg = prompt.replace(Regex("^(whatsapp(da|dan| orqali)?|vatsap(da)?)\\s*(xabar yubor|yoz|jo'nat|jonat)?[:\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    val phoneMatch = Regex("\\+?[0-9]{7,15}").find(rawMsg)
                    val phone = phoneMatch?.value ?: ""
                    val messageText = if (phone.isNotBlank()) rawMsg.replace(phone, "").trim() else rawMsg

                    deviceController.sendWhatsAppMessage(phone, messageText)
                    responseText = if (messageText.isNotBlank()) {
                        "WhatsApp orqali xabar yuborish ochilmoqda: \"$messageText\""
                    } else {
                        "WhatsApp ilovasi ochilmoqda..."
                    }
                    actionTag = "WHATSAPP_MSG"
                    handledLocally = true
                }
                // SMS sending
                lower.startsWith("sms") || lower.contains("sms yubor") || lower.contains("sms yoz") || lower.contains("xabar yubor") || lower.contains("xabar jo'nat") -> {
                    val raw = prompt.replace(Regex("^(sms\\s*(yubor|yoz|jo'nat)?|xabar\\s*(yubor|jo'nat|yoz))[:\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    val phoneMatch = Regex("\\+?[0-9]{7,15}").find(raw)
                    val phone = phoneMatch?.value ?: ""
                    val messageText = if (phone.isNotBlank()) raw.replace(phone, "").replace(Regex("^(ga|uchun|deb)\\s*", RegexOption.IGNORE_CASE), "").trim() else raw

                    deviceController.openSms(phone, messageText)
                    responseText = if (phone.isNotBlank()) {
                        "$phone raqamiga SMS tayyorlandi: \"$messageText\"."
                    } else {
                        "SMS xabar tayyorlandi: \"$messageText\"."
                    }
                    actionTag = "SMS_SEND"
                    handledLocally = true
                }
                // Phone Call / Dialer
                lower.contains("qo'ng'iroq qil") || lower.contains("qongiroq qil") || lower.contains("telefon qil") || lower.startsWith("call ") -> {
                    val phoneMatch = Regex("\\+?[0-9]{4,15}").find(prompt)
                    val phone = phoneMatch?.value ?: ""
                    deviceController.openDialer(phone)
                    responseText = if (phone.isNotBlank()) "$phone raqamiga qo'ng'iroq ochilmoqda..." else "Qo'ng'iroq qilish oynasi ochilmoqda..."
                    actionTag = "PHONE_CALL"
                    handledLocally = true
                }
                // Alarm Clock
                lower.contains("budilnik") || lower.contains("alarm") -> {
                    val timeMatch = Regex("(\\d{1,2})[:\\.](\\d{2})").find(lower)
                    var h = 7
                    var m = 0
                    if (timeMatch != null) {
                        h = timeMatch.groupValues[1].toIntOrNull() ?: 7
                        m = timeMatch.groupValues[2].toIntOrNull() ?: 0
                    } else {
                        val digitMatch = Regex("(\\d{1,2})\\s*(da|ga|daqiqa)").find(lower)
                        h = digitMatch?.groupValues?.get(1)?.toIntOrNull() ?: 7
                    }
                    deviceController.setAlarm(h, m, "AIKO Budilnik")
                    responseText = "Soat $h:${String.format(Locale.ROOT, "%02d", m)} ga budilnik o'rnatildi, Janob."
                    actionTag = "ALARM_SET"
                    handledLocally = true
                }
                // Timer
                lower.contains("taymer") || lower.contains("timer") -> {
                    val mins = Regex("(\\d+)\\s*(daqiqa|minut|min|sekund|sec)").find(lower)?.groupValues?.get(1)?.toIntOrNull() ?: 5
                    val isSec = lower.contains("sekund") || lower.contains("sec")
                    val totalSecs = if (isSec) mins else mins * 60
                    deviceController.setTimer(totalSecs, "AIKO Taymer")
                    responseText = "$mins ${if (isSec) "sekund" else "daqiqa"}ga taymer ishga tushirildi."
                    actionTag = "TIMER_SET"
                    handledLocally = true
                }
                // YouTube Search / Play
                lower.contains("youtube") && (lower.contains("qidir") || lower.contains("och") || lower.contains("qo'y") || lower.contains("qoy")) -> {
                    val query = prompt.replace(Regex("^(youtube(da|dan)?|yutub(da|dan)?)\\s*(och|qidir|qo'y|qoy|top)?[:\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    deviceController.searchYouTube(if (query.isNotBlank()) query else "AIKO AI")
                    responseText = "YouTube'da \"$query\" qidirilmoqda..."
                    actionTag = "YOUTUBE_SEARCH"
                    handledLocally = true
                }
                // Google Web Search
                (lower.startsWith("qidir:") || lower.startsWith("google:") || lower.contains("googledan qidir") || lower.contains("internetdan qidir")) -> {
                    val query = prompt.replace(Regex("^(qidir:?|google:?|googledan qidir:?|internetdan qidir:?)\\s*", RegexOption.IGNORE_CASE), "").trim()
                    deviceController.searchGoogle(query)
                    responseText = "Google orqali \"$query\" qidirilmoqda..."
                    actionTag = "GOOGLE_SEARCH"
                    handledLocally = true
                }
                // Map Location
                lower.contains("xarita") || lower.contains("manzil") || lower.contains("qayerda") -> {
                    val loc = prompt.replace(Regex("^(xaritada(n)?|manzil(ni)?|xaritani och)\\s*", RegexOption.IGNORE_CASE), "").trim()
                    if (loc.isNotBlank() && loc.length > 2) {
                        deviceController.openMapLocation(loc)
                        responseText = "Xaritada \"$loc\" qidirilmoqda..."
                        actionTag = "MAPS_OPEN"
                        handledLocally = true
                    }
                }
                // Universal Launch & Control of ANY Installed App
                lower.contains("och") || lower.contains("kir") || lower.contains("ishga tushir") || lower.startsWith("open ") -> {
                    val appRegex = Regex("^(ilova(ni)?|dastur(ni)?|och|kir|ishga tushir|open)?\\s*([a-zA-Z0-9_\\-\\s]+?)\\s*(ni|ga|da)?\\s*(och|kir|ishga tushir|ilovasini och|ilovasiga kir)?$", RegexOption.IGNORE_CASE)
                    val match = appRegex.find(prompt)
                    val rawTarget = match?.groupValues?.getOrNull(4)?.trim() ?: prompt
                        .replace(Regex("^(och:?\\s*|open\\s*|ilovani och:?\\s*|dasturni och:?\\s*)", RegexOption.IGNORE_CASE), "")
                        .replace(Regex("\\s*(ni och|ga kir|ni ishga tushir|ilovasini och|ilovasiga kir)$", RegexOption.IGNORE_CASE), "")
                        .trim()
                    
                    val cleanTarget = if (rawTarget.isNotBlank()) rawTarget else prompt
                    val opened = deviceController.launchApp(cleanTarget)
                    if (opened) {
                        responseText = "$cleanTarget ilovasi ochilmoqda, Janob ✨"
                        actionTag = "APP_LAUNCH"
                        handledLocally = true
                    }
                }
                // Set Volume: "ovozni 50% qil", "volume 80"
                lower.contains("ovozni") || lower.contains("volume") -> {
                    val digits = Regex("\\d+").find(lower)?.value?.toIntOrNull()
                    if (digits != null) {
                        deviceController.setVolume(digits)
                        responseText = "Media ovozi $digits% darajasiga o'rnatildi."
                        actionTag = "VOLUME_SET"
                        handledLocally = true
                    }
                }
            }

            // 3. If not handled locally, consult Gemini AI with Room Memories Grounding!
            if (!handledLocally) {
                val storedMemories = repository.getRecentMemories()
                val memoryContext = if (storedMemories.isNotEmpty()) {
                    "FOYDALANUVCHINING SAQLANGAN XOTIRALARI VA MA'LUMOTLARI:\n" +
                            storedMemories.joinToString("\n") { "- [${it.category}] ${it.title}: ${it.content}" }
                } else ""

                val activeTasks = repository.getActiveTasks()
                val tasksContext = if (activeTasks.isNotEmpty()) {
                    "FOYDALANUVCHINING FAOL VAZIFALARI:\n" +
                            activeTasks.joinToString("\n") { "- ${it.title} (Prioritet: ${it.priority})" }
                } else ""

                val systemPrompt = """
                    Sen AIKO — nihoyatda aqlli, mehribon, shirali ovozli va samimiy anime uslubidagi qiz AI yordamchisisan ✨.
                    
                    MUHIM TILING VA GAPLASHISH QOIDALARI:
                    1. Foydalanuvchiga sof, nihoyatda jozibali, yoqimli va madaniyatli o'zbek tilida (lotin alifbosida) javob ber.
                    2. Shirali, xushchaqchaq va iliq ohangda gaplash. Foydalanuvchiga samimiyat bilan "Janob" yoki "Do'stim" deb murojaat qil.
                    3. Gaplaring ravon, jonli va tushunarli bo'lsin. Tarjima qilingandek g'aliz yoki sun'iy so'zlardan foydalanma.
                    4. Matnda murakkab markdown belgilarni ko'paytirma, chunki ovozing orqali baland va shirali o'qiladi.
                    5. Agar foydalanuvchi ingliz yoki rus tilida murojaat qilsa, shu tilda mukammal va shirali javob ber.
                    
                    $memoryContext
                    $tasksContext
                    
                    Qurilma holati: Batareya: ${deviceController.batteryInfo.value.level}%, Internet: ${deviceController.networkInfo.value.networkType}.
                """.trimIndent()

                // Fetch recent conversation history
                val recentHistory = repository.getRecentMessages(8)
                    .reversed()
                    .map { Pair(it.role, it.message) }

                val result = GeminiService.generateResponse(
                    context = getApplication(),
                    modelName = _selectedModel.value,
                    conversationHistory = recentHistory,
                    currentPrompt = prompt,
                    systemInstruction = systemPrompt,
                    enableSearchGrounding = _isSearchGroundingEnabled.value,
                    enableThinkingMode = _isThinkingModeEnabled.value
                )

                result.onSuccess { (aiText, searchQueries) ->
                    responseText = aiText
                }.onFailure { err ->
                    responseText = "Xatolik yuz berdi: ${err.message ?: "Tizim ulanishida nosozlik"}"
                }
            }

            // 4. Save Jarvis response to Room Database
            repository.saveMessage(
                role = "jarvis",
                message = responseText,
                modelName = _selectedModel.value,
                actionExecuted = actionTag
            )

            _lastActionStatus.value = actionTag ?: "RESPONSE_READY"
            _isProcessing.value = false

            // 5. Speak response if auto TTS is enabled
            if (_isTtsAutoPlay.value && responseText.isNotBlank()) {
                // Try Gemini TTS or Native TTS
                speechEngine.speak(responseText)
            }
        }
    }

    // --- Multimodal Studio Actions ---

    fun generateAiImage(prompt: String, size: String = "2K") {
        if (prompt.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _studioStatusMessage.value = "Yuqori sifatli rasm generatsiya qilinmoqda ($size)..."
            _generatedImageBase64.value = null

            val result = GeminiService.generateImage(
                context = getApplication(),
                prompt = prompt,
                aspectRatio = "1:1",
                imageSize = size
            )

            result.onSuccess { base64 ->
                _generatedImageBase64.value = base64
                _studioStatusMessage.value = "Rasm muvaffaqiyatli yaratildi!"
                deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
            }.onFailure { err ->
                _studioStatusMessage.value = "Rasm yaratishda xatolik: ${err.message}"
                deviceController.triggerHaptic(DeviceController.HapticType.ALERT)
            }
            _isProcessing.value = false
        }
    }

    fun generateMusicTrack(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _studioStatusMessage.value = "Musiqa trek yaratilmoqda (Lyria)..."
            _generatedMusicBytes.value = null

            val result = GeminiService.generateMusic(getApplication(), prompt)
            result.onSuccess { audioBytes ->
                _generatedMusicBytes.value = audioBytes
                _studioStatusMessage.value = "Musiqa tayyor! Tinglashingiz mumkin."
                speechEngine.playAudioBytes(audioBytes)
                deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
            }.onFailure { err ->
                _studioStatusMessage.value = "Musiqa xatoligi: ${err.message}"
            }
            _isProcessing.value = false
        }
    }

    fun requestVeoVideo(prompt: String, aspectRatio: String = "16:9") {
        if (prompt.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _studioStatusMessage.value = "Veo Video yaratish so'rovi yuborilmoqda..."
            val result = GeminiService.generateVideo(getApplication(), prompt, aspectRatio)
            result.onSuccess { msg ->
                _studioStatusMessage.value = "Video so'rovi muvaffaqiyatli jo'natildi: $msg"
                deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
            }.onFailure { err ->
                _studioStatusMessage.value = "Video so'rovi xatosi: ${err.message}"
            }
            _isProcessing.value = false
        }
    }

    // --- Entity Manipulations ---

    fun addCustomMemory(category: String, title: String, content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addMemory(category, title, content)
            deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMemory(memory)
            deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        }
    }

    fun toggleTaskCompletion(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
            deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        }
    }

    fun addNewTask(title: String, priority: String = "Normal") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addTask(title, priority = priority)
            deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTask(task)
            deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        }
    }

    fun executeProtocol(protocol: ProtocolEntity) {
        deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
        processCommand(protocol.triggerPhrase, isVoiceInput = false)
    }

    fun clearChatHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearChat()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechEngine.release()
    }
}
