package com.example.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JarvisViewModel
import com.example.ui.components.HolographicCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun StudioScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val generatedImageBase64 by viewModel.generatedImageBase64.collectAsStateWithLifecycle()
    val generatedMusicBytes by viewModel.generatedMusicBytes.collectAsStateWithLifecycle()
    val statusMessage by viewModel.studioStatusMessage.collectAsStateWithLifecycle()

    var imagePrompt by remember { mutableStateOf("") }
    var selectedImageSize by remember { mutableStateOf("2K") } // "1K", "2K", "4K"

    var musicPrompt by remember { mutableStateOf("") }
    var videoPrompt by remember { mutableStateOf("") }
    var videoAspectRatio by remember { mutableStateOf("16:9") }

    val decodedBitmap = remember(generatedImageBase64) {
        generatedImageBase64?.let { b64 ->
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) {
                null
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ProfessionalDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "A.R.K.A.S MULTIMODAL LAB",
                        color = ProfessionalBlueLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "AI Studio Engine",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Light
                    )
                }

                StatusBadge(text = "MODELS ACTIVE", color = ProfessionalEmerald)
            }
        }

        // Status Toast Card
        if (statusMessage != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalBlueLight.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ProfessionalBlueLight, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Info, contentDescription = null, tint = ProfessionalBlueLight, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = statusMessage ?: "", color = ProfessionalTextPrimary, fontSize = 13.sp)
                    }
                }
            }
        }

        // 1. High-Quality Image Generator (gemini-2.5-flash-image)
        item {
            HolographicCard(
                title = "AI Image Generation",
                subtitle = "Model: gemini-2.5-flash-image (Tezkor & Cheksiz)",
                icon = Icons.Default.Image,
                accentColor = ProfessionalBlueLight
            ) {
                OutlinedTextField(
                    value = imagePrompt,
                    onValueChange = { imagePrompt = it },
                    label = { Text("Rasm tavsifi (prompt)") },
                    placeholder = { Text("Masalan: Futuristic sleek cyber interface glowing holograms", color = ProfessionalTextMuted) },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ProfessionalTextPrimary,
                        unfocusedTextColor = ProfessionalTextPrimary,
                        focusedBorderColor = ProfessionalBlueLight,
                        unfocusedBorderColor = ProfessionalCardBorder,
                        focusedContainerColor = ProfessionalSurfaceDark,
                        unfocusedContainerColor = ProfessionalSurfaceDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Resolution picker (1K, 2K, 4K)
                Text(
                    text = "O'LCHAM (RESOLUTION):",
                    color = ProfessionalTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("1K", "2K", "4K").forEach { size ->
                        val isSelected = selectedImageSize == size
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) ProfessionalBlueLight.copy(alpha = 0.2f) else ProfessionalSurfaceDark)
                                .border(1.dp, if (isSelected) ProfessionalBlueLight else ProfessionalCardBorder, RoundedCornerShape(10.dp))
                                .clickable { selectedImageSize = size }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = size,
                                color = if (isSelected) ProfessionalBlueLight else ProfessionalTextSecondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.generateAiImage(imagePrompt, selectedImageSize) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_image_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalBluePrimary, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    enabled = imagePrompt.isNotBlank() && !isProcessing
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Rasm Yaratish ($selectedImageSize)", fontWeight = FontWeight.SemiBold)
                }

                // Rendered Image Display
                if (decodedBitmap != null) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Image(
                        bitmap = decodedBitmap.asImageBitmap(),
                        contentDescription = "Generatsiya qilingan rasm",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, ProfessionalBlueLight.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    )
                }
            }
        }

        // 2. Music Generator (lyria-3-clip-preview)
        item {
            HolographicCard(
                title = "AI Music Composition",
                subtitle = "Model: lyria-3-clip-preview",
                icon = Icons.Default.MusicNote,
                accentColor = ProfessionalGold
            ) {
                OutlinedTextField(
                    value = musicPrompt,
                    onValueChange = { musicPrompt = it },
                    label = { Text("Musiqa uslubi va tavsifi") },
                    placeholder = { Text("Masalan: Cinematic orchestral sci-fi superhero theme", color = ProfessionalTextMuted) },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ProfessionalTextPrimary,
                        unfocusedTextColor = ProfessionalTextPrimary,
                        focusedBorderColor = ProfessionalGold,
                        unfocusedBorderColor = ProfessionalCardBorder,
                        focusedContainerColor = ProfessionalSurfaceDark,
                        unfocusedContainerColor = ProfessionalSurfaceDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.generateMusicTrack(musicPrompt) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_music_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    enabled = musicPrompt.isNotBlank() && !isProcessing
                ) {
                    Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Musiqa Yaratish", fontWeight = FontWeight.SemiBold)
                }

                if (generatedMusicBytes != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ProfessionalSurfaceDark)
                            .border(1.dp, ProfessionalCardBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Musiqa trek tayyor", color = ProfessionalGold, fontSize = 13.sp)
                        IconButton(onClick = { viewModel.speechEngine.playAudioBytes(generatedMusicBytes!!) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Ijro etish", tint = ProfessionalGold)
                        }
                    }
                }
            }
        }

        // 3. Veo Video Generator (veo-3.1-fast-generate-preview)
        item {
            HolographicCard(
                title = "Veo Video Generation",
                subtitle = "Model: veo-3.1-fast-generate-preview",
                icon = Icons.Default.Movie,
                accentColor = ProfessionalPurple
            ) {
                OutlinedTextField(
                    value = videoPrompt,
                    onValueChange = { videoPrompt = it },
                    label = { Text("Video prompt") },
                    placeholder = { Text("Masalan: Holographic Iron Man armor assembling in high definition", color = ProfessionalTextMuted) },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ProfessionalTextPrimary,
                        unfocusedTextColor = ProfessionalTextPrimary,
                        focusedBorderColor = ProfessionalPurple,
                        unfocusedBorderColor = ProfessionalCardBorder,
                        focusedContainerColor = ProfessionalSurfaceDark,
                        unfocusedContainerColor = ProfessionalSurfaceDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("16:9", "9:16").forEach { ratio ->
                        val isSelected = videoAspectRatio == ratio
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) ProfessionalPurple.copy(alpha = 0.2f) else ProfessionalSurfaceDark)
                                .border(1.dp, if (isSelected) ProfessionalPurple else ProfessionalCardBorder, RoundedCornerShape(10.dp))
                                .clickable { videoAspectRatio = ratio }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Nisbat: $ratio",
                                color = if (isSelected) ProfessionalPurple else ProfessionalTextSecondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.requestVeoVideo(videoPrompt, videoAspectRatio) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_video_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalPurple, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    enabled = videoPrompt.isNotBlank() && !isProcessing
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Veo Video Generatsiya Qilish", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
