package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JarvisViewModel
import com.example.ui.components.HolographicCard
import com.example.util.InstalledAppItem
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun SystemScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isLiveActive by com.example.service.JarvisLiveService.isLiveActive.collectAsStateWithLifecycle()
    val batteryInfo by viewModel.deviceController.batteryInfo.collectAsStateWithLifecycle()
    val networkInfo by viewModel.deviceController.networkInfo.collectAsStateWithLifecycle()
    val isFlashlightOn by viewModel.deviceController.isFlashlightOn.collectAsStateWithLifecycle()

    var volumeSliderValue by remember { mutableFloatStateOf(70f) }
    var timerMinutes by remember { mutableIntStateOf(5) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ProfessionalDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "A.R.K.A.S SYSTEM DIAGNOSTICS",
                        color = ProfessionalBlueLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Phone Command Center",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Light
                    )
                }

                StatusBadge(
                    text = if (isLiveActive) "LIVE ACTIVE" else "ONLINE",
                    color = if (isLiveActive) ProfessionalEmerald else ProfessionalBlueLight
                )
            }
        }

        // 1. AIKO LIVE (Background Service & Floating HUD)
        item {
            HolographicCard(
                title = "AIKO Live & Floating HUD",
                subtitle = if (isLiveActive) "Fon xizmati ishlamoqda (Ilovadan tashqarida ham faol)" else "Ilovadan chiqqan holda ovozli boshqaruv",
                icon = Icons.Default.Sensors,
                accentColor = if (isLiveActive) ProfessionalEmerald else ProfessionalBlueLight
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isLiveActive) "LIVE FOYDALANUVCHI REJIMI FAOL" else "FON REJIMINI YOQISH",
                            color = if (isLiveActive) ProfessionalEmerald else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Boshqa ilovalarda bo'lsangiz ham ekranda suzuvchi Arc Reactor orqali gaplasha olasiz.",
                            color = ProfessionalTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Switch(
                        checked = isLiveActive,
                        onCheckedChange = { enable ->
                            if (enable) {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(context)) {
                                    val intent = android.content.Intent(
                                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        android.net.Uri.parse("package:${context.packageName}")
                                    ).apply {
                                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                }
                                com.example.service.JarvisLiveService.start(context)
                            } else {
                                com.example.service.JarvisLiveService.stop(context)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ProfessionalEmerald,
                            uncheckedThumbColor = ProfessionalTextSecondary,
                            uncheckedTrackColor = ProfessionalSurfaceDark
                        )
                    )
                }

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(context)) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:${context.packageName}")
                            ).apply {
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalBlueLight.copy(alpha = 0.2f), contentColor = ProfessionalBlueLight),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Ekranda ko'rinish ruxsatini berish (Floating HUD)", fontSize = 12.sp)
                    }
                }
            }
        }

        // 1.5 Gemini API Keys — unlimited keys, auto-rotated when one hits its quota
        item {
            val apiKeys by viewModel.geminiApiKeys.collectAsStateWithLifecycle()
            var newKeyText by remember { mutableStateOf("") }
            var isKeyVisible by remember { mutableStateOf(false) }

            HolographicCard(
                title = "Gemini API Kalitlari",
                subtitle = if (apiKeys.isEmpty()) "Hali kalit qo'shilmagan (build-vaqtidagi standart kalit ishlatiladi)" else "${apiKeys.size} ta kalit qo'shilgan — limit tugasa avtomatik keyingisiga o'tadi",
                icon = Icons.Default.VpnKey,
                accentColor = ProfessionalGold
            ) {
                Text(
                    text = "Xohlagancha (cheksiz) Gemini API kalit qo'shishingiz mumkin. Bittasining so'rov limiti (429) tugasa, AIKO avtomatik ravishda navbatdagi kalitga o'tib ishlashda davom etadi.",
                    color = ProfessionalTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newKeyText,
                        onValueChange = { newKeyText = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("api_key_input"),
                        placeholder = { Text("AIzaSy... kalitni shu yerga joylang", fontSize = 11.sp, color = ProfessionalTextMuted) },
                        singleLine = true,
                        visualTransformation = if (isKeyVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                Icon(
                                    if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Ko'rsatish",
                                    tint = ProfessionalTextMuted
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ProfessionalGold,
                            unfocusedBorderColor = ProfessionalCardBorder,
                            focusedContainerColor = ProfessionalSurfaceDark,
                            unfocusedContainerColor = ProfessionalSurfaceDark
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            if (newKeyText.isNotBlank()) {
                                viewModel.addGeminiApiKey(newKeyText)
                                newKeyText = ""
                            }
                        },
                        modifier = Modifier.testTag("api_key_add_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Qo'shish")
                    }
                }

                if (apiKeys.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "QO'SHILGAN KALITLAR",
                        color = ProfessionalBlueLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        apiKeys.forEachIndexed { index, key ->
                            val masked = if (key.length > 10) {
                                "${key.take(6)}••••••${key.takeLast(4)}"
                            } else "••••••••"
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = ProfessionalSurfaceDark,
                                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Kalit #${index + 1}", color = ProfessionalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text(text = masked, color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    IconButton(onClick = { viewModel.removeGeminiApiKey(key) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "O'chirish", tint = ProfessionalCrimson)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Hardware Flashlight Control
        item {
            HolographicCard(
                title = "Hardware Flashlight",
                subtitle = if (isFlashlightOn) "Torch active" else "Torch standby",
                icon = Icons.Default.FlashlightOn,
                accentColor = if (isFlashlightOn) ProfessionalGold else ProfessionalBlueLight
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isFlashlightOn) "FAOL (ON)" else "O'CHIQLIGIDA (OFF)",
                        color = if (isFlashlightOn) ProfessionalGold else ProfessionalTextSecondary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )

                    Switch(
                        checked = isFlashlightOn,
                        onCheckedChange = { viewModel.deviceController.setFlashlight(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ProfessionalGold,
                            uncheckedThumbColor = ProfessionalTextSecondary,
                            uncheckedTrackColor = ProfessionalSurfaceDark
                        ),
                        modifier = Modifier.testTag("flashlight_switch")
                    )
                }
            }
        }

        // 3. Battery & Power Diagnostics
        item {
            HolographicCard(
                title = "Power & Telemetry",
                subtitle = if (batteryInfo.isCharging) "Zaryadlanmoqda" else "Batareyadan ishlamoqda",
                icon = Icons.Default.BatteryChargingFull,
                accentColor = ProfessionalEmerald
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "QUVVAT DARAJASI", color = ProfessionalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "${batteryInfo.level}%", color = ProfessionalTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(text = "HARORAT", color = ProfessionalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "${batteryInfo.temperatureCelsius}°C", color = ProfessionalTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(text = "TEXNOLOGIYA", color = ProfessionalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = batteryInfo.technology, color = ProfessionalTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { batteryInfo.level / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (batteryInfo.level < 20) ProfessionalCrimson else ProfessionalEmerald,
                    trackColor = ProfessionalSurfaceDark
                )
            }
        }

        // 4. Audio & Volume Control
        item {
            HolographicCard(
                title = "Media Audio Matrix",
                subtitle = "Ovoz balandligi: ${volumeSliderValue.toInt()}%",
                icon = Icons.Default.VolumeUp,
                accentColor = ProfessionalBlueLight
            ) {
                Slider(
                    value = volumeSliderValue,
                    onValueChange = {
                        volumeSliderValue = it
                        viewModel.deviceController.setVolume(it.toInt())
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = ProfessionalBlueLight,
                        activeTrackColor = ProfessionalBlueLight,
                        inactiveTrackColor = ProfessionalSurfaceDark
                    ),
                    modifier = Modifier.testTag("volume_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            volumeSliderValue = 0f
                            viewModel.deviceController.setSilentMode(true)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalSurfaceDark, contentColor = ProfessionalTextPrimary),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
                    ) {
                        Text("Tinch Rejim", fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            volumeSliderValue = 100f
                            viewModel.deviceController.setVolume(100)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalSurfaceDark, contentColor = ProfessionalTextPrimary),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
                    ) {
                        Text("100% Balandlik", fontSize = 11.sp)
                    }
                }
            }
        }

        // 5. Quick Timers & Alerts
        item {
            HolographicCard(
                title = "Quick Timers & Alerts",
                subtitle = "Tezkor taymer o'rnatish",
                icon = Icons.Default.Alarm,
                accentColor = ProfessionalGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 5, 15, 30).forEach { mins ->
                        val isSelected = timerMinutes == mins
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) ProfessionalGold.copy(alpha = 0.2f) else ProfessionalSurfaceDark)
                                .border(1.dp, if (isSelected) ProfessionalGold else ProfessionalCardBorder, RoundedCornerShape(10.dp))
                                .clickable { timerMinutes = mins }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$mins daq",
                                color = if (isSelected) ProfessionalGold else ProfessionalTextSecondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.deviceController.createTimer(timerMinutes * 60, "AIKO $timerMinutes daqiqa") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("$timerMinutes daqiqalik Taymerni Ishga Tushurish", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // 6. Complete Phone Tools & App Hub
        item {
            val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
            var appSearchQuery by remember { mutableStateOf("") }
            val filteredApps = remember(installedApps, appSearchQuery) {
                if (appSearchQuery.isBlank()) installedApps.take(12)
                else installedApps.filter { it.name.contains(appSearchQuery, ignoreCase = true) || it.packageName.contains(appSearchQuery, ignoreCase = true) }
            }

            HolographicCard(
                title = "Universal App Hub & System Tools",
                subtitle = "Telefondagi barcha o'rnatilgan ilovalarni ochish va boshqarish",
                icon = Icons.Default.Apps,
                accentColor = ProfessionalBlueLight
            ) {
                // Quick Launch Row 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Telegram", icon = Icons.AutoMirrored.Filled.Send, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("telegram")
                    }
                    AppLaunchButton(name = "WhatsApp", icon = Icons.AutoMirrored.Filled.Chat, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("whatsapp")
                    }
                    AppLaunchButton(name = "YouTube", icon = Icons.Default.PlayCircle, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("youtube")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Launch Row 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Kamera", icon = Icons.Default.CameraAlt, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("camera")
                    }
                    AppLaunchButton(name = "Galereya", icon = Icons.Default.PhotoLibrary, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("galereya")
                    }
                    AppLaunchButton(name = "Kalkulyator", icon = Icons.Default.Calculate, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("kalkulyator")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Launch Row 3
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Telefon", icon = Icons.Default.Call, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.openDialer()
                    }
                    AppLaunchButton(name = "Wi-Fi", icon = Icons.Default.Wifi, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.openWifiSettings()
                    }
                    AppLaunchButton(name = "Bluetooth", icon = Icons.Default.Bluetooth, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.openBluetoothSettings()
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search ANY Installed App
                Text(
                    text = "TELEFONDAGI BARCHA ILOVALAR (${installedApps.size} ta)",
                    color = ProfessionalBlueLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = appSearchQuery,
                    onValueChange = { appSearchQuery = it },
                    placeholder = { Text("Ilova nomini yozing (masalan: Pubg, Instagram, Zoom...)", fontSize = 11.sp, color = ProfessionalTextMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = ProfessionalBlueLight,
                        unfocusedBorderColor = ProfessionalCardBorder,
                        focusedContainerColor = ProfessionalSurfaceDark,
                        unfocusedContainerColor = ProfessionalSurfaceDark
                    ),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = {
                        IconButton(onClick = { viewModel.refreshInstalledApps() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Yangilash", tint = ProfessionalBlueLight)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (filteredApps.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        filteredApps.forEach { appItem ->
                            Surface(
                                onClick = { viewModel.launchInstalledApp(appItem.packageName) },
                                shape = RoundedCornerShape(10.dp),
                                color = ProfessionalSurfaceDark,
                                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = appItem.name, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                        Text(text = appItem.packageName, color = ProfessionalTextMuted, fontSize = 10.sp, maxLines = 1)
                                    }
                                    Icon(Icons.Default.OpenInNew, contentDescription = "Ochish", tint = ProfessionalBlueLight, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 7. Anime Voice Engine Tester
        item {
            HolographicCard(
                title = "Shirali Anime Ovoz Sozlamasi",
                subtitle = "Jozibali va samimiy o'zbek tilidagi AI ovoz ohangi",
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                accentColor = ProfessionalGold
            ) {
                Text(
                    text = "AIKO ovozi hozirda maxsus shirali qiz ohangiga va o'zbek talaffuziga sozlangan. Sinab ko'rish uchun quyidagi tugmani bosing:",
                    color = ProfessionalTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        viewModel.speechEngine.speak("Assalomu alaykum, Janob! Men sizning shaxsiy anime yordamchingiz AIKO-man. Sizga qanday yordam bera olaman?")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Anime Ovozini Eshitib Ko'rish ✨", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AppLaunchButton(
    name: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ProfessionalSurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = ProfessionalBlueLight, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = name, color = ProfessionalTextPrimary, fontSize = 11.sp, maxLines = 1)
        }
    }
}
