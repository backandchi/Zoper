package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String = "General", // "General", "Keys & Passwords", "Preference", "Person", "Location", "Routine"
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val details: String = "",
    val priority: String = "Normal", // "High", "Normal", "Low"
    val isCompleted: Boolean = false,
    val dueTime: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "protocols")
data class ProtocolEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val triggerPhrase: String,
    val actionType: String, // "FLASHLIGHT_ON", "FLASHLIGHT_OFF", "SILENT_MODE", "READ_TASKS", "BATTERY_CHECK", "CUSTOM"
    val actionData: String = "",
    val description: String = "",
    val isEnabled: Boolean = true
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user", "jarvis"
    val message: String,
    val modelName: String = "gemini-3.5-flash",
    val timestamp: Long = System.currentTimeMillis(),
    val isVoice: Boolean = false,
    val actionExecuted: String? = null
)
