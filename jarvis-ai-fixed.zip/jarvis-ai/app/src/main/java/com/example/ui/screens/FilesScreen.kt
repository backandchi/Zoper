package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JarvisViewModel
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*
import com.example.util.WorkspaceFile
import kotlinx.coroutines.launch

@Composable
fun FilesScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fileManager = viewModel.fileManager
    val workspaceUri by fileManager.workspaceTreeUri.collectAsStateWithLifecycle()

    var files by remember { mutableStateOf<List<WorkspaceFile>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newFileName by remember { mutableStateOf("") }
    var editingFile by remember { mutableStateOf<WorkspaceFile?>(null) }
    var editingContent by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<WorkspaceFile?>(null) }
    var renameText by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch {
            isLoading = true
            files = fileManager.listFiles()
            isLoading = false
        }
    }

    LaunchedEffect(workspaceUri) { refresh() }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            fileManager.setWorkspaceTree(uri)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        item {
            Text(
                text = "Fayllar Muhiti",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Yaratish, o'qish, tahrirlash va boshqa ilovalarga yuborish",
                color = ProfessionalTextSecondary,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        item {
            HolographicCard(
                title = "Ish Papkasi",
                subtitle = if (workspaceUri != null) "Tanlangan papka ulangan" else "AIKO_Workspace (ilova ichki papkasi) ishlatilmoqda",
                icon = Icons.Default.Folder,
                accentColor = ProfessionalBlueLight
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { folderPicker.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalBlueLight, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.DriveFileMove, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Papka Tanlash", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (workspaceUri != null) {
                        OutlinedButton(
                            onClick = { fileManager.clearWorkspaceTree() },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Ichki Papkaga Qaytish", fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FAYLLAR (${files.size})",
                    color = ProfessionalTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Button(
                    onClick = { newFileName = ""; showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Yangi Fayl", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = ProfessionalGold)
                }
            }
        } else if (files.isEmpty()) {
            item {
                Text(
                    text = "Bu papkada hali fayl yo'q. \"Yangi Fayl\" tugmasi bilan boshlang.",
                    color = ProfessionalTextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            items(files, key = { it.uri.toString() }) { file ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = !file.isDirectory) {
                            scope.launch {
                                editingContent = fileManager.readFile(file.uri)
                                editingFile = file
                            }
                        },
                    color = ProfessionalSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (file.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                            contentDescription = null,
                            tint = if (file.isDirectory) ProfessionalGold else ProfessionalBlueLight,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = file.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            if (!file.isDirectory) {
                                Text(text = "${file.sizeBytes} B", color = ProfessionalTextMuted, fontSize = 10.sp)
                            }
                        }
                        IconButton(onClick = {
                            val intent = fileManager.buildShareIntent(file.uri)
                            context.startActivity(android.content.Intent.createChooser(intent, "Ulashish"))
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Ulashish", tint = ProfessionalTextMuted, modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = { renameText = file.name; renameTarget = file }) {
                            Icon(Icons.Default.Edit, contentDescription = "Nomini o'zgartirish", tint = ProfessionalTextMuted, modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = {
                            scope.launch {
                                fileManager.deleteFile(file.uri)
                                refresh()
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "O'chirish", tint = ProfessionalCrimson, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    // ---------- Create file dialog ----------
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Yangi Fayl") },
            text = {
                OutlinedTextField(
                    value = newFileName,
                    onValueChange = { newFileName = it },
                    placeholder = { Text("masalan: eslatma.txt") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newFileName.isNotBlank()) {
                        scope.launch {
                            fileManager.createFile(newFileName.trim())
                            showCreateDialog = false
                            refresh()
                        }
                    }
                }) { Text("Yaratish") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Bekor qilish") }
            }
        )
    }

    // ---------- Rename dialog ----------
    val currentRenameTarget = renameTarget
    if (currentRenameTarget != null) {
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Nomini O'zgartirish") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        fileManager.renameFile(currentRenameTarget.uri, renameText.trim())
                        renameTarget = null
                        refresh()
                    }
                }) { Text("Saqlash") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Bekor qilish") }
            }
        )
    }

    // ---------- Editor ----------
    val currentEditingFile = editingFile
    if (currentEditingFile != null) {
        AlertDialog(
            onDismissRequest = { editingFile = null },
            title = { Text(currentEditingFile.name) },
            text = {
                OutlinedTextField(
                    value = editingContent,
                    onValueChange = { editingContent = it },
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        fileManager.writeFile(currentEditingFile.uri, editingContent)
                        editingFile = null
                        refresh()
                    }
                }) { Text("Saqlash") }
            },
            dismissButton = {
                TextButton(onClick = { editingFile = null }) { Text("Yopish") }
            }
        )
    }
}
