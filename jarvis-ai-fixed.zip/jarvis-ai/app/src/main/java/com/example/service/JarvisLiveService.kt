package com.example.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.local.JarvisDatabase
import com.example.data.remote.GeminiService
import com.example.data.repository.JarvisRepository
import com.example.util.DeviceController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class JarvisLiveService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var deviceController: DeviceController
    private lateinit var repository: JarvisRepository

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    companion object {
        const val CHANNEL_ID = "jarvis_live_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "ACTION_START_JARVIS_LIVE"
        const val ACTION_STOP = "ACTION_STOP_JARVIS_LIVE"
        const val ACTION_LISTEN = "ACTION_LISTEN_LIVE"
        const val ACTION_TOGGLE_TORCH = "ACTION_TOGGLE_TORCH_LIVE"

        private val _isLiveActive = MutableStateFlow(false)
        val isLiveActive: StateFlow<Boolean> = _isLiveActive.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, JarvisLiveService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, JarvisLiveService::class.java).apply {
                action = ACTION_STOP
            }
            context.stopService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        _isLiveActive.value = true
        deviceController = DeviceController(this)
        val database = JarvisDatabase.getDatabase(this, serviceScope)
        repository = JarvisRepository(database.jarvisDao())

        createNotificationChannel()
        initTts()
        initSpeechRecognizer()
        
        showFloatingOverlayIfPermitted()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> {
                startListening()
            }
            ACTION_TOGGLE_TORCH -> {
                val isOn = deviceController.toggleFlashlight()
                speakText(if (isOn) "Chiroq yoqildi, Janob." else "Chiroq o'chirildi.")
            }
            else -> {
                startForegroundNotification()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Live Fon Rejimi",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "JARVIS fon rejimida ovozli buyruqlarni qabul qilish xizmati"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundNotification() {
        val appIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingAppIntent = PendingIntent.getActivity(
            this, 0, appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Listen
        val listenIntent = Intent(this, JarvisLiveService::class.java).apply { action = ACTION_LISTEN }
        val pendingListen = PendingIntent.getService(
            this, 1, listenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Flashlight
        val torchIntent = Intent(this, JarvisLiveService::class.java).apply { action = ACTION_TOGGLE_TORCH }
        val pendingTorch = PendingIntent.getService(
            this, 2, torchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Stop
        val stopIntent = Intent(this, JarvisLiveService::class.java).apply { action = ACTION_STOP }
        val pendingStop = PendingIntent.getService(
            this, 3, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ JARVIS Live — Fon Rejimi Faol")
            .setContentText("Ovozli buyruqlar va telefon boshqaruvi shay holatda.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingAppIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_btn_speak_now, "🎙️ Tinglash", pendingListen)
            .addAction(android.R.drawable.ic_menu_camera, "💡 Chiroq", pendingTorch)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "❌ To'xtatish", pendingStop)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                textToSpeech?.language = Locale.forLanguageTag("uz-UZ")
                textToSpeech?.setPitch(1.28f)
                textToSpeech?.setSpeechRate(1.04f)
            }
        }
    }

    private fun speakText(text: String) {
        if (!isTtsReady) return
        val clean = text.replace(Regex("[*#_`~>•]"), "").trim()
        textToSpeech?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_LIVE_TTS")
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Toast.makeText(this@JarvisLiveService, "JARVIS tinglamoqda...", Toast.LENGTH_SHORT).show()
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {}
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            processSpokenCommand(text)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    private fun startListening() {
        if (speechRecognizer == null) initSpeechRecognizer()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("uz-UZ", "uz", "ru-RU", "en-US"))
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun processSpokenCommand(prompt: String) {
        serviceScope.launch(Dispatchers.IO) {
            val lower = prompt.lowercase().trim()
            var responseText = ""
            var handled = false

            when {
                lower.contains("chiroqni yoq") || lower.contains("fonarni yoq") || lower.contains("turn on light") -> {
                    deviceController.setFlashlight(true)
                    responseText = "Chiroq yoqildi, Janob."
                    handled = true
                }
                lower.contains("chiroqni o'chir") || lower.contains("fonarni o'chir") || lower.contains("turn off light") -> {
                    deviceController.setFlashlight(false)
                    responseText = "Chiroq o'chirildi."
                    handled = true
                }
                lower.contains("chiroq") || lower.contains("fonar") -> {
                    val on = deviceController.toggleFlashlight()
                    responseText = if (on) "Chiroq yoqildi." else "Chiroq o'chirildi."
                    handled = true
                }
                lower.contains("ovozni balandlat") || lower.contains("ovozni 100") || lower.contains("max volume") -> {
                    deviceController.setVolume(100)
                    responseText = "Ovoz maksimal darajaga ko'tarildi."
                    handled = true
                }
                lower.contains("ovozni o'chir") || lower.contains("ovozni pasaytir") || lower.contains("mute") -> {
                    deviceController.setVolume(0)
                    responseText = "Ovoz to'liq o'chirildi."
                    handled = true
                }
                lower.contains("batareya") || lower.contains("zaryad") || lower.contains("quvvat") -> {
                    deviceController.updateBatteryInfo()
                    val b = deviceController.batteryInfo.value
                    responseText = "Batareya quvvati: ${b.level} foiz. Harorati ${b.temperatureCelsius} daraja."
                    handled = true
                }
                lower.contains("telegram") -> {
                    val rawMsg = prompt.replace(Regex("^(telegram(da|dan| orqali)?\\s*(xabar yubor|yoz|jo'nat|jonat)?[:\\s]*)", RegexOption.IGNORE_CASE), "").trim()
                    val userMatch = Regex("@([a-zA-Z0-9_]+)").find(rawMsg)
                    val targetUser = userMatch?.groupValues?.get(1) ?: ""
                    val messageText = if (targetUser.isNotBlank()) rawMsg.replace("@$targetUser", "").trim() else rawMsg
                    deviceController.sendTelegramMessage(targetUser, messageText)
                    responseText = if (messageText.isNotBlank()) "Telegram xabari tayyorlandi: \"$messageText\"" else "Telegram ochilmoqda..."
                    handled = true
                }
                lower.contains("whatsapp") || lower.contains("vatsap") -> {
                    val rawMsg = prompt.replace(Regex("^(whatsapp(da|dan| orqali)?|vatsap(da)?)\\s*(xabar yubor|yoz|jo'nat|jonat)?[:\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    val phoneMatch = Regex("\\+?[0-9]{7,15}").find(rawMsg)
                    val phone = phoneMatch?.value ?: ""
                    val messageText = if (phone.isNotBlank()) rawMsg.replace(phone, "").trim() else rawMsg
                    deviceController.sendWhatsAppMessage(phone, messageText)
                    responseText = if (messageText.isNotBlank()) "WhatsApp xabari tayyorlandi: \"$messageText\"" else "WhatsApp ochilmoqda..."
                    handled = true
                }
                lower.contains("sms") || lower.contains("xabar yubor") || lower.contains("xabar yoz") -> {
                    val raw = prompt.replace(Regex("^(sms\\s*(yubor|yoz|jo'nat)?|xabar\\s*(yubor|jo'nat|yoz))[:\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    val phoneMatch = Regex("\\+?[0-9]{7,15}").find(raw)
                    val phone = phoneMatch?.value ?: ""
                    val messageText = if (phone.isNotBlank()) raw.replace(phone, "").replace(Regex("^(ga|uchun|deb)\\s*", RegexOption.IGNORE_CASE), "").trim() else raw
                    deviceController.openSms(phone, messageText)
                    responseText = "$phone raqamiga SMS tayyorlandi: \"$messageText\""
                    handled = true
                }
                lower.contains("budilnik") || lower.contains("alarm") -> {
                    val timeMatch = Regex("(\\d{1,2})[:\\.](\\d{2})").find(lower)
                    var h = 7
                    var m = 0
                    if (timeMatch != null) {
                        h = timeMatch.groupValues[1].toIntOrNull() ?: 7
                        m = timeMatch.groupValues[2].toIntOrNull() ?: 0
                    }
                    deviceController.setAlarm(h, m, "JARVIS Budilnik")
                    responseText = "Soat $h:$m ga budilnik o'rnatildi, Janob."
                    handled = true
                }
                lower.contains("taymer") || lower.contains("timer") -> {
                    val mins = Regex("(\\d+)").find(lower)?.value?.toIntOrNull() ?: 5
                    deviceController.setTimer(mins * 60, "JARVIS Taymer")
                    responseText = "$mins daqiqaga taymer qo'yildi."
                    handled = true
                }
                lower.contains("youtubeni och") || lower.contains("youtube") -> {
                    val query = prompt.replace(Regex("^(youtube(da|dan)?|yutub(da|dan)?)\\s*(och|qidir|qo'y)?[:\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    if (query.isNotBlank() && query != "youtube" && query != "yutub") {
                        deviceController.searchYouTube(query)
                        responseText = "YouTube'da \"$query\" qidirilmoqda..."
                    } else {
                        deviceController.launchApp("youtube")
                        responseText = "YouTube ochilmoqda..."
                    }
                    handled = true
                }
                lower.contains("kamerani och") || lower.contains("kamera") -> {
                    deviceController.launchApp("camera")
                    responseText = "Kamera ishga tushirilmoqda..."
                    handled = true
                }
                lower.contains("galereyani och") || lower.contains("galereya") -> {
                    deviceController.launchApp("gallery")
                    responseText = "Galereya ochilmoqda..."
                    handled = true
                }
                lower.contains("sozlamalarni och") || lower.contains("sozlamalar") -> {
                    deviceController.launchApp("settings")
                    responseText = "Sozlamalar ochilmoqda..."
                    handled = true
                }
                lower.contains("kalkulyatorni och") || lower.contains("kalkulyator") -> {
                    deviceController.launchApp("calculator")
                    responseText = "Kalkulyator ochilmoqda..."
                    handled = true
                }
                lower.contains("wi-fi") || lower.contains("wifi") -> {
                    deviceController.openWifiSettings()
                    responseText = "Wi-Fi sozlamalari ochilmoqda..."
                    handled = true
                }
                lower.contains("bluetooth") -> {
                    deviceController.openBluetoothSettings()
                    responseText = "Bluetooth sozlamalari ochilmoqda..."
                    handled = true
                }
                lower.contains("qo'ng'iroq qil") || lower.contains("qongiroq qil") -> {
                    val digits = Regex("\\+?\\d+").find(prompt)?.value ?: ""
                    deviceController.openDialer(digits)
                    responseText = if (digits.isNotBlank()) "$digits raqamiga qo'ng'iroq ochilmoqda..." else "Qo'ng'iroqlar ochilmoqda..."
                    handled = true
                }
            }

            if (!handled) {
                // Consult Gemini AI
                val systemPrompt = "Sen JARVIS — nihoyatda aqlli shaxsiy sun'iy intellektsan. Foydalanuvchiga sof o'zbek tilida, qisqa, aniq va hurmat bilan javob ber."
                val result = GeminiService.generateResponse(
                    modelName = "gemini-2.5-flash",
                    conversationHistory = emptyList(),
                    currentPrompt = prompt,
                    systemInstruction = systemPrompt
                )
                result.onSuccess { (aiText, _) ->
                    responseText = aiText
                }.onFailure {
                    responseText = "Sizni tushundim, buyrug'ingiz qayta ishlanmoqda."
                }
            }

            launch(Dispatchers.Main) {
                speakText(responseText)
                Toast.makeText(this@JarvisLiveService, responseText, Toast.LENGTH_LONG).show()
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingOverlayIfPermitted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return
        }

        try {
            windowManager = getSystemService(WINDOW_SERVICE) as? WindowManager
            val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 30
                y = 200
            }

            // Create circular Holographic Arc Reactor widget
            val root = FrameLayout(this).apply {
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(12, 12, 12, 12)
            }

            val icon = ImageView(this).apply {
                setImageResource(android.R.drawable.ic_btn_speak_now)
                setBackgroundResource(android.R.drawable.dialog_holo_dark_frame)
                setPadding(24, 24, 24, 24)
            }

            root.addView(icon)

            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f
            var isMoving = false

            root.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isMoving = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isMoving = true
                            params.x = initialX + dx
                            params.y = initialY + dy
                            windowManager?.updateViewLayout(root, params)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isMoving) {
                            // Clicked!
                            startListening()
                        }
                        true
                    }
                    else -> false
                }
            }

            floatingView = root
            windowManager?.addView(floatingView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        _isLiveActive.value = false
        serviceScope.cancel()
        speechRecognizer?.destroy()
        textToSpeech?.shutdown()
        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        super.onDestroy()
    }
}
