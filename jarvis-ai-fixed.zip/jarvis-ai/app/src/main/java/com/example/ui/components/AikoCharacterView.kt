package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.R
import kotlinx.coroutines.delay

/** One horizontal sprite-sheet animation: [frameCount] square frames of [frameSize] px each. */
private data class SpriteSheet(
    val resId: Int,
    val frameCount: Int,
    val frameSize: Int = 128,
    val frameDurationMs: Long = 120
)

private object AikoSprites {
    val idle = SpriteSheet(R.drawable.aiko_idle, frameCount = 9)
    val talking = SpriteSheet(R.drawable.aiko_talking, frameCount = 11, frameDurationMs = 90)
    val excited = SpriteSheet(R.drawable.aiko_excited, frameCount = 8, frameDurationMs = 85) // laughing / happy / proud
    val shy = SpriteSheet(R.drawable.aiko_shy, frameCount = 4, frameDurationMs = 160) // sad / worried / shy / surprised

    fun forState(emotion: String, isSpeaking: Boolean): SpriteSheet {
        if (isSpeaking) return talking
        return when (emotion) {
            "laughing", "excited", "proud", "happy", "love" -> excited
            "sad", "crying", "worried", "shy", "surprised" -> shy
            else -> idle
        }
    }
}

/**
 * AIKO's animated 2D anime-girl character. Replaces a static icon with a small
 * looping pixel-art animation that changes based on her mood ([emotion], driven by
 * EmotionMapper from Gemini's responses) and whether she's currently talking.
 */
@Composable
fun AikoCharacterView(
    emotion: String,
    isSpeaking: Boolean,
    modifier: Modifier = Modifier
) {
    val sheet = AikoSprites.forState(emotion, isSpeaking)
    var frameIndex by remember(sheet) { mutableStateOf(0) }

    LaunchedEffect(sheet) {
        frameIndex = 0
        while (true) {
            delay(sheet.frameDurationMs)
            frameIndex = (frameIndex + 1) % sheet.frameCount
        }
    }

    val bitmap = imageResource(id = sheet.resId)

    Canvas(modifier = modifier) {
        val frame = sheet.frameSize
        drawImage(
            image = bitmap,
            srcOffset = IntOffset(frameIndex * frame, 0),
            srcSize = IntSize(frame, frame),
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.None // keep pixel art crisp, no smoothing blur
        )
    }
}
