package com.example.util

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class SpeechEngine(
    private val context: Context,
    private val scope: CoroutineScope
) {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var mediaPlayer: MediaPlayer? = null

    private var speechRecognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _spokenText = MutableStateFlow("")
    val spokenText: StateFlow<String> = _spokenText.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    var onSpeechRecognized: ((String) -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                
                // Prioritize Uzbek locales (uz_UZ, uz-Latn, etc.)
                val uzbekLocale = Locale.forLanguageTag("uz-UZ")
                val uzbekAlt = Locale.forLanguageTag("uz")
                val turkishLocale = Locale.forLanguageTag("tr-TR")
                
                val langResult = tts?.setLanguage(uzbekLocale)
                var activeLocale = uzbekLocale
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val altResult = tts?.setLanguage(uzbekAlt)
                    activeLocale = uzbekAlt
                    if (altResult == TextToSpeech.LANG_MISSING_DATA || altResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        val trResult = tts?.setLanguage(turkishLocale)
                        activeLocale = turkishLocale
                        if (trResult == TextToSpeech.LANG_MISSING_DATA || trResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts?.language = Locale.getDefault()
                            activeLocale = Locale.getDefault()
                        }
                    }
                }

                // Pick the sweetest available female-sounding voice for the active
                // language so AIKO sounds like a warm anime girl rather than the
                // engine's generic default (often male on many devices).
                selectFemaleVoice(activeLocale)

                // Sweet melodious anime-girl voice tuning (higher pitch, lively pace)
                tts?.setPitch(1.32f)
                tts?.setSpeechRate(1.05f)

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            }
        }
    }

    /**
     * Scans the TTS engine's available voices for [locale] and switches to the
     * best-matching female voice, so AIKO has a warm, girlish anime tone instead
     * of whatever the device's default voice happens to be.
     */
    private fun selectFemaleVoice(locale: Locale) {
        val engine = tts ?: return
        val voices = try {
            engine.voices
        } catch (e: Exception) {
            null
        } ?: return

        val candidates = voices.filter { voice ->
            !voice.isNetworkConnectionRequired &&
                (voice.locale.language == locale.language || voice.locale == locale)
        }
        if (candidates.isEmpty()) return

        // Prefer voices explicitly labelled female; Android's Voice API exposes this
        // either via the "female" feature flag or via naming convention (e.g. "#female").
        val femaleVoice = candidates.firstOrNull { voice ->
            voice.name.contains("female", ignoreCase = true) ||
                voice.features?.any { it.contains("female", ignoreCase = true) } == true
        } ?: candidates.firstOrNull { voice ->
            // Some engines index female variants under a numeric/latin suffix
            // (e.g. "uz-uz-x-uzc-local" female vs male variants); fall back to
            // the first non-male-labelled voice.
            !voice.name.contains("male", ignoreCase = true)
        }

        femaleVoice?.let { engine.voice = it }
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        stopAudio()
        if (isTtsReady) {
            _isSpeaking.value = true
            // Clean markdown syntax, asterisks, bullet points and formatting for clean natural speech
            val cleanText = text
                .replace(Regex("[*#_`~>•]"), "")
                .replace(Regex("\\(https?://[^)]+\\)"), "")
                .replace(Regex("\\[(.*?)\\]"), "$1")
                .replace(Regex("https?://\\S+"), "")
                .replace(Regex("\\s+"), " ")
                .trim()

            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "JARVIS_SPEECH_${System.currentTimeMillis()}")
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, "JARVIS_SPEECH")
        }
    }

    fun playAudioBytes(audioBytes: ByteArray, onComplete: (() -> Unit)? = null) {
        scope.launch(Dispatchers.IO) {
            try {
                stopAudio()
                val tempFile = File.createTempFile("jarvis_tts_", ".mp3", context.cacheDir)
                FileOutputStream(tempFile).use { it.write(audioBytes) }

                withContext(Dispatchers.Main) {
                    mediaPlayer = MediaPlayer().apply {
                        setDataSource(tempFile.absolutePath)
                        prepare()
                        start()
                        _isSpeaking.value = true

                        setOnCompletionListener {
                            _isSpeaking.value = false
                            tempFile.delete()
                            onComplete?.invoke()
                        }
                        setOnErrorListener { _, _, _ ->
                            _isSpeaking.value = false
                            tempFile.delete()
                            false
                        }
                    }
                }
            } catch (e: Exception) {
                _isSpeaking.value = false
            }
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }

        stopAudio()
        stopListening()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                    _spokenText.value = ""
                }

                override fun onBeginningOfSpeech() {
                    _isListening.value = true
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Normalize RMS to 0f..1f for visualizer
                    _amplitude.value = (rmsdB + 2f).coerceIn(0f, 10f) / 10f
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _amplitude.value = 0f
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _amplitude.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull() ?: ""
                    if (text.isNotBlank()) {
                        _spokenText.value = text
                        onSpeechRecognized?.invoke(text)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull() ?: ""
                    if (text.isNotBlank()) {
                        _spokenText.value = text
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Primary language Uzbek
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("uz-UZ", "uz", "ru-RU", "en-US"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        }

        try {
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            _isListening.value = false
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        } finally {
            speechRecognizer = null
            _isListening.value = false
            _amplitude.value = 0f
        }
    }

    fun stopAudio() {
        tts?.stop()
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
        _isSpeaking.value = false
    }

    fun release() {
        stopAudio()
        stopListening()
        tts?.shutdown()
    }
}
