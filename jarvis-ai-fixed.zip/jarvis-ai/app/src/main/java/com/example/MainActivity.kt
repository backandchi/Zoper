package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.JarvisViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class JarvisScreen(val title: String, val icon: ImageVector) {
    HUD("HUD", Icons.Default.Adjust),
    MEMORY("Xotira", Icons.Default.Psychology),
    CHAT("AI Chat", Icons.Default.ChatBubbleOutline),
    STUDIO("Studio", Icons.Default.AutoAwesome),
    FILES("Fayllar", Icons.Default.Folder),
    SYSTEM("Tizim", Icons.Default.Tune)
}

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Permissions handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        checkAndRequestPermissions()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                var currentScreen by remember { mutableStateOf(JarvisScreen.HUD) }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(JarvisDarkBg),
                    containerColor = JarvisDarkBg,
                    bottomBar = {
                        JarvisBottomNavBar(
                            currentScreen = currentScreen,
                            onScreenSelected = { currentScreen = it }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            JarvisScreen.HUD -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToChat = { currentScreen = JarvisScreen.CHAT },
                                onNavigateToMemory = { currentScreen = JarvisScreen.MEMORY }
                            )
                            JarvisScreen.MEMORY -> MemoryScreen(viewModel = viewModel)
                            JarvisScreen.CHAT -> ChatScreen(viewModel = viewModel)
                            JarvisScreen.STUDIO -> StudioScreen(viewModel = viewModel)
                            JarvisScreen.FILES -> FilesScreen(viewModel = viewModel)
                            JarvisScreen.SYSTEM -> SystemScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsList = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissionsList.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val permissionsToRequest = permissionsList.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }
}

@Composable
fun JarvisBottomNavBar(
    currentScreen: JarvisScreen,
    onScreenSelected: (JarvisScreen) -> Unit
) {
    Surface(
        color = ProfessionalSurfaceDark,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder),
        shadowElevation = 12.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            tonalElevation = 0.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            JarvisScreen.values().forEach { screen ->
                val isSelected = currentScreen == screen
                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onScreenSelected(screen) },
                    icon = {
                        Icon(
                            imageVector = screen.icon,
                            contentDescription = screen.title,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = screen.title,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            letterSpacing = 0.3.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ProfessionalBlueLight,
                        selectedTextColor = ProfessionalBlueLight,
                        indicatorColor = ProfessionalBlueLight.copy(alpha = 0.15f),
                        unselectedIconColor = ProfessionalTextMuted,
                        unselectedTextColor = ProfessionalTextMuted
                    ),
                    modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                )
            }
        }
    }
}
