package com.example.data.remote

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.HttpException
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.delay

interface GeminiApiInterface {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiService {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val api: GeminiApiInterface = retrofit.create(GeminiApiInterface::class.java)

    /**
     * General Chat / Reasoning generation with intelligent 429 rate-limit fallback
     */
    suspend fun generateResponse(
        modelName: String,
        conversationHistory: List<Pair<String, String>>, // (role, text)
        currentPrompt: String,
        systemInstruction: String,
        enableSearchGrounding: Boolean = false,
        enableThinkingMode: Boolean = false
    ): Result<Pair<String, List<String>>> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API kaliti topilmadi. Iltimos, Secrets panelida GEMINI_API_KEY ni sozlang."))
        }

        // Limit conversation history to the last 4 messages to conserve quota and avoid 429 rate limit
        val prunedHistory = conversationHistory.takeLast(4)
        val contents = mutableListOf<ContentItem>()

        for ((role, text) in prunedHistory) {
            contents.add(
                ContentItem(
                    role = if (role == "user") "user" else "model",
                    parts = listOf(PartItem(text = text.take(500)))
                )
            )
        }

        contents.add(
            ContentItem(
                role = "user",
                parts = listOf(PartItem(text = currentPrompt))
            )
        )

        val thinkingConfig = if (enableThinkingMode && modelName.contains("pro")) {
            ThinkingConfig(thinkingLevel = "LOW")
        } else null

        val tools = if (enableSearchGrounding) {
            listOf(mapOf("googleSearch" to emptyMap<String, Any>()))
        } else null

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = ContentItem(parts = listOf(PartItem(text = systemInstruction))),
            generationConfig = GenerationConfig(
                temperature = if (enableThinkingMode) null else 0.7f,
                thinkingConfig = thinkingConfig
            ),
            tools = tools
        )

        // Attempt 1: Call with requested model
        var activeModel = modelName
        try {
            val response = api.generateContent(activeModel, apiKey, request)
            val candidate = response.candidates?.firstOrNull()
            val text = candidate?.content?.parts?.mapNotNull { it.text }?.joinToString("\n") ?: "Javob olinmadi."
            val searchQueries = candidate?.groundingMetadata?.webSearchQueries ?: emptyList()
            return@withContext Result.success(Pair(text, searchQueries))
        } catch (e: Exception) {
            val isRateLimit = e.message?.contains("429") == true || e.message?.contains("RESOURCE_EXHAUSTED") == true || e is HttpException && e.code() == 429

            if (isRateLimit && activeModel != "gemini-3.1-flash-lite-preview") {
                // Fallback to fastest, high-quota Flash Lite model
                try {
                    delay(1200)
                    activeModel = "gemini-3.1-flash-lite-preview"
                    val fallbackRequest = request.copy(
                        generationConfig = GenerationConfig(temperature = 0.7f),
                        tools = null // simplify request to save quota
                    )
                    val response = api.generateContent(activeModel, apiKey, fallbackRequest)
                    val candidate = response.candidates?.firstOrNull()
                    val text = candidate?.content?.parts?.mapNotNull { it.text }?.joinToString("\n") ?: "Javob olinmadi."
                    val searchQueries = candidate?.groundingMetadata?.webSearchQueries ?: emptyList()
                    return@withContext Result.success(Pair(text, searchQueries))
                } catch (e2: Exception) {
                    val isStillRateLimit = e2.message?.contains("429") == true || e2 is HttpException && e2.code() == 429
                    if (isStillRateLimit) {
                        return@withContext Result.failure(Exception("⚠️ So'rovlar limiti oshdi (429 Rate Limit). Eng yaxshi va tekin Flash modelidan foydalanilmoqda. Iltimos, 20-30 soniya kutib qayta urinib ko'ring."))
                    }
                    return@withContext Result.failure(e2)
                }
            } else if (isRateLimit) {
                return@withContext Result.failure(Exception("⚠️ So'rovlar limiti oshdi (429 Rate Limit). Iltimos, 20-30 soniya kutib qayta urinib ko'ring."))
            }

            return@withContext Result.failure(e)
        }
    }

    /**
     * Transcribe Audio using gemini-3.5-flash
     */
    suspend fun transcribeAudio(audioBytes: ByteArray, mimeType: String = "audio/mp3"): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(Exception("Gemini API key is required"))
            }

            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            val request = GenerateContentRequest(
                contents = listOf(
                    ContentItem(
                        role = "user",
                        parts = listOf(
                            PartItem(text = "Ushbu audio yozuvni aniq va to'liq transkripsiya qilib matnga aylantirib ber. Agar o'zbek yoki boshqa tilda bo'lsa, o'sha tilda aniq yoz:"),
                            PartItem(inlineData = InlineBlob(mimeType = mimeType, data = base64Audio))
                        )
                    )
                )
            )

            val response = api.generateContent("gemini-3.5-flash", apiKey, request)
            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Transkripsiya amalga oshmadi."
            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Generate High-Quality Image using gemini-2.5-flash-image / gemini-3.1-flash-image-preview
     */
    suspend fun generateImage(
        prompt: String,
        aspectRatio: String = "1:1",
        imageSize: String = "1K"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(Exception("Gemini API key is required"))
            }

            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("TEXT")
                        put("IMAGE")
                    })
                    put("imageConfig", JSONObject().apply {
                        put("aspectRatio", aspectRatio)
                        put("imageSize", imageSize)
                    })
                })
            }

            // Use gemini-2.5-flash-image as primary for high throughput and avoiding rate limits
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                if (response.code == 429) {
                    return@withContext Result.failure(Exception("⚠️ Rasm yaratish limiti oshdi (429). Iltimos, 30 soniya kutib qayta urinib ko'ring."))
                }
                return@withContext Result.failure(Exception("Image generation failed: ${response.code} $responseBody"))
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            var imageBase64: String? = null
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        imageBase64 = inlineData.optString("data")
                        break
                    }
                }
            }

            if (imageBase64 != null) {
                Result.success(imageBase64)
            } else {
                Result.failure(Exception("Rasm ma'lumoti olinmadi: $responseBody"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Generate Speech (TTS) using gemini-3.1-flash-tts-preview or gemini-2.5-flash-preview-tts
     */
    suspend fun generateSpeechAudio(
        text: String,
        voiceName: String = "Kore"
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(Exception("Gemini API key is required"))
            }

            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", text) })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("AUDIO")
                    })
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("TTS audio generation failed: ${response.code} $responseBody"))
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            var audioBase64: String? = null
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        audioBase64 = inlineData.optString("data")
                        break
                    }
                }
            }

            if (audioBase64 != null) {
                val audioBytes = Base64.decode(audioBase64, Base64.DEFAULT)
                Result.success(audioBytes)
            } else {
                Result.failure(Exception("Ovoz ma'lumoti topilmadi"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Generate Music track / clip with lyria-3-clip-preview
     */
    suspend fun generateMusic(
        prompt: String
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(Exception("Gemini API key is required"))
            }

            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("AUDIO")
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/lyria-3-clip-preview:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Music generation failed: ${response.code} $responseBody"))
            }

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val audioBase64 = parts?.optJSONObject(0)?.optJSONObject("inlineData")?.optString("data")

            if (!audioBase64.isNullOrEmpty()) {
                val bytes = Base64.decode(audioBase64, Base64.DEFAULT)
                Result.success(bytes)
            } else {
                Result.failure(Exception("Musiqa generatsiyasi yakunlanmadi."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Veo Video generation request affordance with veo-3.1-fast-generate-preview
     */
    suspend fun generateVideo(
        prompt: String,
        aspectRatio: String = "16:9" // "16:9" or "9:16"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(Exception("Gemini API key is required"))
            }

            val jsonBody = JSONObject().apply {
                put("prompt", prompt)
                put("config", JSONObject().apply {
                    put("numberOfVideos", 1)
                    put("resolution", "720p")
                    put("aspectRatio", aspectRatio)
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-fast-generate-preview:generateVideos?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Veo video generation: ${response.code} $responseBody"))
            }

            Result.success("Video generatsiya jarayoni yuborildi: $responseBody")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
