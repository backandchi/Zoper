package com.example.data.remote

import android.content.Context
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.ApiKeyStore
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface GeminiApiInterface {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

/**
 * Thrown internally to signal "this key is out of quota, try the next one."
 * Never escapes [GeminiService] — callers only ever see [Result].
 */
private class RateLimitedException(message: String) : Exception(message)

object GeminiService {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val api: GeminiApiInterface = retrofit.create(GeminiApiInterface::class.java)

    /**
     * Runs [block] once per available Gemini API key, starting from whichever key
     * last succeeded. Keys come from the user's Settings screen (unlimited amount
     * supported); if none were added, falls back to the key baked in at build time.
     *
     * If a key hits its rate limit (HTTP 429 / RESOURCE_EXHAUSTED / 403 quota errors),
     * the next key is tried automatically. Any other kind of error is returned
     * immediately without wasting the remaining keys. Only after every key has been
     * tried and all are rate-limited does this return a failure.
     */
    private suspend fun <T> withKeyRotation(
        context: Context,
        block: suspend (apiKey: String) -> T
    ): Result<T> {
        val userKeys = ApiKeyStore.getKeys(context)
        val builtInKey = BuildConfig.GEMINI_API_KEY
        val keys = when {
            userKeys.isNotEmpty() -> userKeys
            builtInKey.isNotBlank() && builtInKey != "MY_GEMINI_API_KEY" -> listOf(builtInKey)
            else -> emptyList()
        }

        if (keys.isEmpty()) {
            return Result.failure(
                Exception("Gemini API kaliti topilmadi. Sozlamalar bo'limida kamida bitta API kalit qo'shing.")
            )
        }

        val storedIndex = ApiKeyStore.getCurrentIndex(context)
        val startIndex = if (storedIndex in keys.indices) storedIndex else 0

        for (attempt in keys.indices) {
            val idx = (startIndex + attempt) % keys.size
            val key = keys[idx]
            try {
                val result = block(key)
                if (idx != storedIndex) ApiKeyStore.setCurrentIndex(context, idx)
                return Result.success(result)
            } catch (e: Exception) {
                if (!isRateLimitError(e)) {
                    return Result.failure(e)
                }
                if (attempt < keys.size - 1) delay(400)
            }
        }

        val keyWord = if (keys.size == 1) "kalit" else "${keys.size} ta kalit"
        return Result.failure(
            Exception("⚠️ Qo'shilgan barcha $keyWord uchun so'rovlar limiti (429) tugadi. Birozdan so'ng qayta urinib ko'ring yoki Sozlamalarda yana bitta API kalit qo'shing.")
        )
    }

    private fun isRateLimitError(e: Exception): Boolean {
        if (e is RateLimitedException) return true
        if (e is HttpException && (e.code() == 429 || e.code() == 403)) return true
        val msg = e.message ?: return false
        return msg.contains("429") || msg.contains("RESOURCE_EXHAUSTED") || msg.contains("quota", ignoreCase = true)
    }

    /**
     * General Chat / Reasoning generation with automatic multi-key rotation on rate limits.
     */
    suspend fun generateResponse(
        context: Context,
        modelName: String,
        conversationHistory: List<Pair<String, String>>, // (role, text)
        currentPrompt: String,
        systemInstruction: String,
        enableSearchGrounding: Boolean = false,
        enableThinkingMode: Boolean = false
    ): Result<Pair<String, List<String>>> = withContext(Dispatchers.IO) {
        // Limit conversation history to the last 4 messages to conserve quota
        val prunedHistory = conversationHistory.takeLast(4)
        val contents = mutableListOf<ContentItem>()

        for ((role, text) in prunedHistory) {
            contents.add(
                ContentItem(
                    role = if (role == "user") "user" else "model",
                    parts = listOf(PartItem(text = text.take(500)))
                )
            )
        }

        contents.add(
            ContentItem(
                role = "user",
                parts = listOf(PartItem(text = currentPrompt))
            )
        )

        val thinkingConfig = if (enableThinkingMode && modelName.contains("pro")) {
            ThinkingConfig(thinkingLevel = "LOW")
        } else null

        val tools = if (enableSearchGrounding) {
            listOf(mapOf("googleSearch" to emptyMap<String, Any>()))
        } else null

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = ContentItem(parts = listOf(PartItem(text = systemInstruction))),
            generationConfig = GenerationConfig(
                temperature = if (enableThinkingMode) null else 0.7f,
                thinkingConfig = thinkingConfig
            ),
            tools = tools
        )

        withKeyRotation(context) { apiKey ->
            val response = api.generateContent(modelName, apiKey, request)
            val candidate = response.candidates?.firstOrNull()
            val text = candidate?.content?.parts?.mapNotNull { it.text }?.joinToString("\n") ?: "Javob olinmadi."
            val searchQueries = candidate?.groundingMetadata?.webSearchQueries ?: emptyList()
            Pair(text, searchQueries)
        }
    }

    /**
     * Transcribe Audio using gemini-3.1-flash-lite-preview (cheapest / free-tier)
     */
    suspend fun transcribeAudio(
        context: Context,
        audioBytes: ByteArray,
        mimeType: String = "audio/mp3"
    ): Result<String> = withContext(Dispatchers.IO) {
        val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
        val request = GenerateContentRequest(
            contents = listOf(
                ContentItem(
                    role = "user",
                    parts = listOf(
                        PartItem(text = "Ushbu audio yozuvni aniq va to'liq transkripsiya qilib matnga aylantirib ber. Agar o'zbek yoki boshqa tilda bo'lsa, o'sha tilda aniq yoz:"),
                        PartItem(inlineData = InlineBlob(mimeType = mimeType, data = base64Audio))
                    )
                )
            )
        )

        withKeyRotation(context) { apiKey ->
            val response = api.generateContent("gemini-3.1-flash-lite-preview", apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Transkripsiya amalga oshmadi."
        }
    }

    /**
     * Generate High-Quality Image using gemini-2.5-flash-image
     */
    suspend fun generateImage(
        context: Context,
        prompt: String,
        aspectRatio: String = "1:1",
        imageSize: String = "1K"
    ): Result<String> = withContext(Dispatchers.IO) {
        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().apply {
                    put("TEXT")
                    put("IMAGE")
                })
                put("imageConfig", JSONObject().apply {
                    put("aspectRatio", aspectRatio)
                    put("imageSize", imageSize)
                })
            })
        }

        withKeyRotation(context) { apiKey ->
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                if (response.code == 429) {
                    throw RateLimitedException("Rasm yaratish limiti oshdi (429).")
                }
                throw Exception("Image generation failed: ${response.code} $responseBody")
            }

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")
                ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

            var imageBase64: String? = null
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inlineData = parts.getJSONObject(i).optJSONObject("inlineData")
                    if (inlineData != null) {
                        imageBase64 = inlineData.optString("data")
                        break
                    }
                }
            }

            imageBase64 ?: throw Exception("Rasm ma'lumoti olinmadi: $responseBody")
        }
    }

    /**
     * Generate Speech (TTS) using gemini-3.1-flash-tts-preview
     */
    suspend fun generateSpeechAudio(
        context: Context,
        text: String,
        voiceName: String = "Leda"
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", text) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().apply { put("AUDIO") })
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }

        withKeyRotation(context) { apiKey ->
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                if (response.code == 429) {
                    throw RateLimitedException("TTS limiti oshdi (429).")
                }
                throw Exception("TTS audio generation failed: ${response.code} $responseBody")
            }

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")
                ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

            var audioBase64: String? = null
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inlineData = parts.getJSONObject(i).optJSONObject("inlineData")
                    if (inlineData != null) {
                        audioBase64 = inlineData.optString("data")
                        break
                    }
                }
            }

            if (audioBase64 != null) {
                Base64.decode(audioBase64, Base64.DEFAULT)
            } else {
                throw Exception("Ovoz ma'lumoti topilmadi")
            }
        }
    }

    /**
     * Generate Music track / clip with lyria-3-clip-preview
     */
    suspend fun generateMusic(
        context: Context,
        prompt: String
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().apply { put("AUDIO") })
            })
        }

        withKeyRotation(context) { apiKey ->
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/lyria-3-clip-preview:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                if (response.code == 429) {
                    throw RateLimitedException("Musiqa generatsiya limiti oshdi (429).")
                }
                throw Exception("Music generation failed: ${response.code} $responseBody")
            }

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val audioBase64 = parts?.optJSONObject(0)?.optJSONObject("inlineData")?.optString("data")

            if (!audioBase64.isNullOrEmpty()) {
                Base64.decode(audioBase64, Base64.DEFAULT)
            } else {
                throw Exception("Musiqa generatsiyasi yakunlanmadi.")
            }
        }
    }

    /**
     * Veo Video generation request with veo-3.1-fast-generate-preview
     */
    suspend fun generateVideo(
        context: Context,
        prompt: String,
        aspectRatio: String = "16:9" // "16:9" or "9:16"
    ): Result<String> = withContext(Dispatchers.IO) {
        val jsonBody = JSONObject().apply {
            put("prompt", prompt)
            put("config", JSONObject().apply {
                put("numberOfVideos", 1)
                put("resolution", "720p")
                put("aspectRatio", aspectRatio)
            })
        }

        withKeyRotation(context) { apiKey ->
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-fast-generate-preview:generateVideos?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                if (response.code == 429) {
                    throw RateLimitedException("Video generatsiya limiti oshdi (429).")
                }
                throw Exception("Veo video generation: ${response.code} $responseBody")
            }

            "Video generatsiya jarayoni yuborildi: $responseBody"
        }
    }
}
