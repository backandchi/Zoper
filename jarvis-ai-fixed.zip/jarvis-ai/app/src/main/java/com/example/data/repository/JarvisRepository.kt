package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow

class JarvisRepository(private val dao: JarvisDao) {

    // Memories
    val allMemories: Flow<List<MemoryEntity>> = dao.getAllMemories()

    suspend fun getRecentMemories(): List<MemoryEntity> = dao.getRecentMemoriesList()

    suspend fun searchMemories(query: String): List<MemoryEntity> = dao.searchMemories(query)

    suspend fun addMemory(category: String, title: String, content: String, isPinned: Boolean = false): Long {
        return dao.insertMemory(
            MemoryEntity(
                category = category,
                title = title,
                content = content,
                isPinned = isPinned
            )
        )
    }

    suspend fun updateMemory(memory: MemoryEntity) = dao.updateMemory(memory)

    suspend fun deleteMemory(memory: MemoryEntity) = dao.deleteMemory(memory)

    suspend fun deleteMemoryById(id: Long) = dao.deleteMemoryById(id)

    // Tasks
    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()

    suspend fun getActiveTasks(): List<TaskEntity> = dao.getActiveTasksList()

    suspend fun addTask(title: String, details: String = "", priority: String = "Normal", dueTime: String = ""): Long {
        return dao.insertTask(
            TaskEntity(
                title = title,
                details = details,
                priority = priority,
                dueTime = dueTime
            )
        )
    }

    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)

    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task)

    suspend fun deleteTaskById(id: Long) = dao.deleteTaskById(id)

    // Protocols
    val allProtocols: Flow<List<ProtocolEntity>> = dao.getAllProtocols()

    suspend fun getEnabledProtocols(): List<ProtocolEntity> = dao.getEnabledProtocols()

    suspend fun addProtocol(protocol: ProtocolEntity): Long = dao.insertProtocol(protocol)

    suspend fun updateProtocol(protocol: ProtocolEntity) = dao.updateProtocol(protocol)

    suspend fun deleteProtocol(protocol: ProtocolEntity) = dao.deleteProtocol(protocol)

    // Chat
    val allMessages: Flow<List<ChatMessageEntity>> = dao.getAllMessages()

    suspend fun getRecentMessages(limit: Int = 10): List<ChatMessageEntity> = dao.getRecentMessages(limit)

    suspend fun saveMessage(role: String, message: String, modelName: String = "gemini-3.5-flash", isVoice: Boolean = false, actionExecuted: String? = null): Long {
        return dao.insertMessage(
            ChatMessageEntity(
                role = role,
                message = message,
                modelName = modelName,
                isVoice = isVoice,
                actionExecuted = actionExecuted
            )
        )
    }

    suspend fun clearChat() = dao.clearChatHistory()
}
