package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JarvisViewModel
import com.example.ui.components.ArcReactorView
import com.example.ui.components.AikoCharacterView
import com.example.ui.components.HolographicCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.EmotionMapper

@Composable
fun HomeScreen(
    viewModel: JarvisViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToMemory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isListening by viewModel.speechEngine.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.speechEngine.isSpeaking.collectAsStateWithLifecycle()
    val spokenText by viewModel.speechEngine.spokenText.collectAsStateWithLifecycle()
    val amplitude by viewModel.speechEngine.amplitude.collectAsStateWithLifecycle()
    val batteryInfo by viewModel.deviceController.batteryInfo.collectAsStateWithLifecycle()
    val networkInfo by viewModel.deviceController.networkInfo.collectAsStateWithLifecycle()
    val isFlashlightOn by viewModel.deviceController.isFlashlightOn.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val protocols by viewModel.protocols.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    val lastJarvisMessage = remember(chatMessages) {
        chatMessages.lastOrNull { it.role == "jarvis" }?.message ?: "Tizimlar to'liq faol. Buyruqlaringizni qabul qilishga tayyorman."
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ProfessionalDarkBg)
            .padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // 1. Header (Professional Polish Design)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isListening || isSpeaking) ProfessionalGold else ProfessionalEmerald)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isListening) "SYSTEM ACTIVE • LISTENING" else "SYSTEM ONLINE",
                            color = ProfessionalBlueLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "A.R.K.A.S Assistant",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Light,
                        letterSpacing = 0.5.sp
                    )
                }

                // Battery / Diagnostic circular badge
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(ProfessionalBlueLight.copy(alpha = 0.1f))
                        .border(1.dp, ProfessionalBlueLight.copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (batteryInfo.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.Settings,
                        contentDescription = "System Status",
                        tint = ProfessionalBlueLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 2. AIKO Character — animated 2D anime girl (replaces the old sphere/orb visual)
        item {
            val currentEmotion by viewModel.currentEmotion.collectAsStateWithLifecycle()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                val ringColor = when {
                    isListening -> ProfessionalEmerald
                    isSpeaking -> ProfessionalGold
                    else -> ProfessionalCardBorder
                }
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .clip(CircleShape)
                        .background(ProfessionalSurfaceDark)
                        .border(2.dp, ringColor, CircleShape)
                        .clickable {
                            if (isListening) {
                                viewModel.stopListening()
                            } else if (isSpeaking) {
                                viewModel.stopSpeaking()
                            } else {
                                viewModel.startListening()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AikoCharacterView(
                        emotion = currentEmotion,
                        isSpeaking = isSpeaking,
                        modifier = Modifier.size(140.dp)
                    )
                }
                Text(
                    text = if (isListening) "TINGLAMOQDA..." else if (isSpeaking) "GAPIRMOQDA..." else "AIKO",
                    color = ringColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
                // AIKO's mood sticker — a quick-glance emoji version of her current mood
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 12.dp, top = 4.dp)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(ProfessionalSurfaceDark)
                        .border(1.dp, ProfessionalCardBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = EmotionMapper.emojiFor(currentEmotion), fontSize = 20.sp)
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 3. Audio Activity Level Bar Indicator
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .width(130.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(ProfessionalBluePrimary.copy(alpha = 0.25f))
                ) {
                    val activeFraction = if (isListening || isSpeaking) (0.3f + amplitude * 0.7f).coerceIn(0.2f, 1f) else 0.45f
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(activeFraction)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(ProfessionalBlueAccent, ProfessionalBlueLight)
                                )
                            )
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 4. Live Speech Bubble (if speaking/listening)
        item {
            AnimatedVisibility(visible = isListening || spokenText.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalBlueLight.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ProfessionalBlueLight.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = null,
                                tint = ProfessionalBlueLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (spokenText.isBlank()) "Sizni tinglayapman, buyruq bering..." else "\"$spokenText\"",
                            color = ProfessionalTextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 5. Active Memory Bank Card (Matching Design HTML)
        item {
            val latestMemory = memories.firstOrNull()?.content 
                ?: "Foydalanuvchi afzalliklari va shaxsiy eslatmalari faol xotirada saqlanadi."

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToMemory() },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = ProfessionalBlueLight,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ACTIVE MEMORY BANK",
                                color = ProfessionalTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        StatusBadge(
                            text = "${memories.size} Saved",
                            color = ProfessionalBlueLight
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "\"$latestMemory\"",
                        color = Color(0xFFE2E2E6),
                        fontSize = 13.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        lineHeight = 19.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 5.5 JARVIS Live Mode & Phone Floating HUD Card
        item {
            val context = androidx.compose.ui.platform.LocalContext.current
            val isLiveActive by com.example.service.JarvisLiveService.isLiveActive.collectAsStateWithLifecycle()

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isLiveActive) ProfessionalBlueLight.copy(alpha = 0.12f) else ProfessionalCardBg
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isLiveActive) ProfessionalEmerald else ProfessionalBlueLight.copy(alpha = 0.3f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(if (isLiveActive) ProfessionalEmerald.copy(alpha = 0.2f) else ProfessionalBlueLight.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isLiveActive) Icons.Default.Sensors else Icons.Default.SensorsOff,
                                contentDescription = "Live Mode",
                                tint = if (isLiveActive) ProfessionalEmerald else ProfessionalBlueLight,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AIKO LIVE (FON REJIMI)",
                                color = if (isLiveActive) ProfessionalEmerald else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (isLiveActive) "Ilovadan chiqqanda ham gaplashish faol" else "Ilovadan chiqqanda ovozli boshqaruv",
                                color = ProfessionalTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = isLiveActive,
                        onCheckedChange = { enable ->
                            if (enable) {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(context)) {
                                    val intent = android.content.Intent(
                                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        android.net.Uri.parse("package:${context.packageName}")
                                    ).apply {
                                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                }
                                com.example.service.JarvisLiveService.start(context)
                            } else {
                                com.example.service.JarvisLiveService.stop(context)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ProfessionalEmerald,
                            uncheckedThumbColor = ProfessionalTextSecondary,
                            uncheckedTrackColor = ProfessionalSurfaceDark
                        )
                    )
                }
            }
        }

        // 6. Response Output Card
        item {
            HolographicCard(
                title = "AIKO Dialogue Response",
                subtitle = if (isSpeaking) "Ovozli talaffuz etilmoqda..." else "So'nggi tizim xabari",
                icon = Icons.Default.AutoAwesome,
                accentColor = ProfessionalBlueLight,
                trailingContent = {
                    if (isSpeaking) {
                        IconButton(onClick = { viewModel.stopSpeaking() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Stop, contentDescription = "To'xtatish", tint = ProfessionalGold)
                        }
                    } else {
                        IconButton(onClick = { viewModel.speakWithBestVoice(lastJarvisMessage) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Qayta o'qish", tint = ProfessionalBlueLight)
                        }
                    }
                }
            ) {
                Text(
                    text = if (isProcessing) "AIKO buyruqni tahlil qilmoqda..." else lastJarvisMessage,
                    color = ProfessionalTextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 7. Quick System & Hardware Grid (2x2 Grid)
        item {
            Text(
                text = "SYSTEM NODES & QUICK CONTROLS",
                color = ProfessionalTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Flashlight Node
                SystemNodeCard(
                    title = if (isFlashlightOn) "Chiroq: Yoqilgan" else "Chiroq: O'chiq",
                    status = if (isFlashlightOn) "Torch Active" else "Ready",
                    icon = Icons.Default.FlashlightOn,
                    isActive = isFlashlightOn,
                    color = if (isFlashlightOn) ProfessionalGold else ProfessionalBlueLight,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.processCommand(if (isFlashlightOn) "chiroqni o'chir" else "chiroqni yoq")
                    }
                )

                // Battery / Power Diagnostics Node
                SystemNodeCard(
                    title = "Smart Power",
                    status = "${batteryInfo.level}% • ${if (batteryInfo.isCharging) "Charging" else "Optimal"}",
                    icon = if (batteryInfo.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                    isActive = batteryInfo.isCharging,
                    color = if (batteryInfo.level < 20) ProfessionalCrimson else ProfessionalEmerald,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.processCommand("quvvat qancha")
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Task Nodes
                SystemNodeCard(
                    title = "Rejalarim",
                    status = "${tasks.count { !it.isCompleted }} Active Nodes",
                    icon = Icons.Default.TaskAlt,
                    isActive = tasks.any { !it.isCompleted },
                    color = ProfessionalEmerald,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.processCommand("rejam nima")
                    }
                )

                // Night Mode Protocol
                SystemNodeCard(
                    title = "Tungi Rejim",
                    status = "Standby Ready",
                    icon = Icons.Default.NightlightRound,
                    isActive = false,
                    color = Color(0xFF818CF8),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.processCommand("tungi rejim")
                    }
                )
            }

            Spacer(modifier = Modifier.height(18.dp))
        }

        // 8. Large Professional Mic Button & Voice Trigger
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    onClick = {
                        if (isListening) viewModel.stopListening() else viewModel.startListening()
                    },
                    shape = CircleShape,
                    color = if (isListening) ProfessionalCrimson else ProfessionalBluePrimary,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .size(76.dp)
                        .testTag("mic_button")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Ovozli buyruq",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isListening) "TINGLANMOQDA • TO'XTATISH UCHUN BOSING" else "TAP TO SPEAK OR COMMAND",
                    color = ProfessionalTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Quick Suggestion Actions Scroll Row
        item {
            val quickPrompts = listOf(
                "💬 Telegramdan yozish" to "telegramda @username ga Salom deb yoz",
                "📩 SMS yuborish" to "SMS yubor 901234567 ga: Salom",
                "📞 Qo'ng'iroq" to "+998901234567 ga qo'ng'iroq qil",
                "⏰ Budilnik" to "Ertalab soat 07:00 ga budilnik qo'y",
                "⏱️ Taymer" to "5 daqiqaga taymer qo'y",
                "🔦 Chiroq" to "Chiroqni yoq"
            )

            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickPrompts.size) { idx ->
                    val (label, promptText) = quickPrompts[idx]
                    Surface(
                        onClick = {
                            textInput = promptText
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = ProfessionalCardBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalBlueLight.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = label,
                            color = ProfessionalBlueLight,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // 9. Command Terminal Text Input
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("command_terminal_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("command_input"),
                        placeholder = {
                            Text(
                                text = "Buyruq kiriting (masalan: 'Chiroqni yoq')...",
                                color = ProfessionalTextMuted,
                                fontSize = 13.sp
                            )
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = ProfessionalTextPrimary,
                            unfocusedTextColor = ProfessionalTextPrimary
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textInput.isNotBlank()) {
                                    viewModel.processCommand(textInput, isVoiceInput = false)
                                    textInput = ""
                                    focusManager.clearFocus()
                                }
                            }
                        ),
                        singleLine = true
                    )

                    // Send Button
                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.processCommand(textInput, isVoiceInput = false)
                                textInput = ""
                                focusManager.clearFocus()
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("send_button"),
                        enabled = textInput.isNotBlank() || isProcessing
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = ProfessionalBlueLight,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Yuborish",
                                tint = if (textInput.isNotBlank()) ProfessionalBlueLight else ProfessionalTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SystemNodeCard(
    title: String,
    status: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("action_chip_${title.replace(" ", "_")}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) color.copy(alpha = 0.12f) else ProfessionalCardBg
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isActive) color.copy(alpha = 0.4f) else ProfessionalCardBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isActive) color else ProfessionalBlueLight,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = ProfessionalTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = status,
                color = ProfessionalTextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
