package com.example.util

/**
 * AIKO's replies come back with a leading [EMOTION:xxx] tag (see the system prompt in
 * JarvisViewModel) so the UI can show how she "feels" about what she's saying — the
 * way an anime character's expression changes — instead of a flat, static face.
 */
object EmotionMapper {

    private val emojiByEmotion = mapOf(
        "happy" to "😊",
        "excited" to "✨",
        "laughing" to "😄",
        "love" to "🥰",
        "thinking" to "🤔",
        "sad" to "😢",
        "crying" to "😭",
        "surprised" to "😲",
        "sleepy" to "😴",
        "shy" to "☺️",
        "proud" to "😌",
        "worried" to "😟",
        "neutral" to "🙂"
    )

    private val tagRegex = Regex("^\\s*\\[EMOTION:([a-zA-Z]+)\\]\\s*", RegexOption.IGNORE_CASE)

    /** Extracts the leading emotion tag (if present) and returns (emotion, cleanedText). */
    fun extract(rawText: String): Pair<String, String> {
        val match = tagRegex.find(rawText)
        val emotion = match?.groupValues?.get(1)?.lowercase() ?: "neutral"
        val cleaned = if (match != null) rawText.removeRange(match.range).trimStart() else rawText
        val normalized = if (emojiByEmotion.containsKey(emotion)) emotion else "neutral"
        return normalized to cleaned
    }

    fun emojiFor(emotion: String): String = emojiByEmotion[emotion] ?: emojiByEmotion.getValue("neutral")

    val allEmotions: Set<String> get() = emojiByEmotion.keys
}
