package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorView(
    isListening: Boolean,
    isSpeaking: Boolean,
    amplitude: Float,
    statusText: String = "AIKO ONLINE",
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")

    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 4000 else if (isSpeaking) 6000 else 18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rotation"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 3000 else 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 500 else 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val primaryColor = when {
        isListening -> JarvisCyan
        isSpeaking -> JarvisGold
        else -> JarvisCyan
    }

    Box(
        modifier = modifier
            .size(240.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f * 0.95f

            // Dynamic amplitude boost
            val dynamicScale = if (isListening) (pulseScale + amplitude * 0.2f) else pulseScale

            // 1. Ambient Background Radial Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = glowAlpha * 0.4f),
                        ProfessionalBluePrimary.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius * dynamicScale
                ),
                radius = maxRadius * dynamicScale,
                center = center
            )

            // 2. Outermost Segmented Ring (Rotating Clockwise)
            rotate(outerRotation, pivot = center) {
                val outerRadius = maxRadius * 0.88f
                val strokeWidth = 2.dp.toPx()

                // Arc segments with smooth gradient feel
                for (i in 0 until 4) {
                    val startAngle = i * 90f + 10f
                    drawArc(
                        color = primaryColor.copy(alpha = 0.5f),
                        startAngle = startAngle,
                        sweepAngle = 70f,
                        useCenter = false,
                        topLeft = Offset(center.x - outerRadius, center.y - outerRadius),
                        size = androidx.compose.ui.geometry.Size(outerRadius * 2, outerRadius * 2),
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                // Precision telemetry tick marks
                val tickCount = 24
                for (i in 0 until tickCount) {
                    val angle = Math.toRadians((i * (360.0 / tickCount)))
                    val r1 = outerRadius + 2.dp.toPx()
                    val r2 = outerRadius + if (i % 6 == 0) 8.dp.toPx() else 4.dp.toPx()
                    val p1 = Offset((center.x + r1 * cos(angle)).toFloat(), (center.y + r1 * sin(angle)).toFloat())
                    val p2 = Offset((center.x + r2 * cos(angle)).toFloat(), (center.y + r2 * sin(angle)).toFloat())
                    drawLine(
                        color = primaryColor.copy(alpha = if (i % 6 == 0) 0.85f else 0.35f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 6 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 3. Middle Ring (Rotating Counter-Clockwise)
            rotate(innerRotation, pivot = center) {
                val midRadius = maxRadius * 0.64f
                val strokeWidth = 1.5.dp.toPx()

                for (i in 0 until 6) {
                    val startAngle = i * 60f + 8f
                    drawArc(
                        color = (if (isSpeaking) JarvisGold else ProfessionalBlueLight).copy(alpha = 0.7f),
                        startAngle = startAngle,
                        sweepAngle = 44f,
                        useCenter = false,
                        topLeft = Offset(center.x - midRadius, center.y - midRadius),
                        size = androidx.compose.ui.geometry.Size(midRadius * 2, midRadius * 2),
                        style = Stroke(width = strokeWidth)
                    )
                }

                // Small triangle node markers
                for (i in 0 until 3) {
                    val angle = Math.toRadians((i * 120.0))
                    val r = midRadius
                    val p = Offset((center.x + r * cos(angle)).toFloat(), (center.y + r * sin(angle)).toFloat())
                    drawCircle(
                        color = primaryColor,
                        radius = 2.5.dp.toPx(),
                        center = p
                    )
                }
            }

            // 4. Inner Cyber Reactor Core iris
            val innerRadius = maxRadius * 0.44f * dynamicScale

            drawCircle(
                color = ProfessionalSurfaceDark,
                radius = innerRadius,
                center = center
            )

            drawCircle(
                color = primaryColor.copy(alpha = 0.4f),
                radius = innerRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Multi-gradient glowing inner sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = if (isSpeaking) {
                        listOf(
                            Color.White.copy(alpha = 0.95f),
                            JarvisGold,
                            Color(0xFFB45309),
                            Color.Transparent
                        )
                    } else {
                        listOf(
                            Color.White.copy(alpha = 0.95f),
                            ProfessionalCyan,
                            ProfessionalBluePrimary,
                            ProfessionalIndigo.copy(alpha = 0.7f),
                            Color.Transparent
                        )
                    },
                    center = center,
                    radius = innerRadius * 0.85f
                ),
                radius = innerRadius * 0.85f,
                center = center
            )

            // Inner refined thin white boundary
            drawCircle(
                color = Color.White.copy(alpha = 0.35f),
                radius = innerRadius * 0.45f,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Glowing Beacon Indicator dot (Top-Right of circle)
            val beaconAngle = Math.toRadians(-45.0)
            val beaconRadius = maxRadius * 0.90f
            val beaconPos = Offset(
                (center.x + beaconRadius * cos(beaconAngle)).toFloat(),
                (center.y + beaconRadius * sin(beaconAngle)).toFloat()
            )
            drawCircle(
                color = ProfessionalBlueLight.copy(alpha = 0.3f),
                radius = 6.dp.toPx(),
                center = beaconPos
            )
            drawCircle(
                color = ProfessionalBlueLight,
                radius = 3.dp.toPx(),
                center = beaconPos
            )

            // Dynamic Voice Audio Wave Ripple
            if (isListening || isSpeaking) {
                val rippleRadius = innerRadius + (amplitude * 35.dp.toPx())
                drawCircle(
                    color = primaryColor.copy(alpha = (1f - amplitude * 0.5f).coerceIn(0.2f, 0.8f)),
                    radius = rippleRadius,
                    center = center,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Center HUD Status / Pulse Label
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (isListening) "TINGLAMOQDA..." else if (isSpeaking) "GAPIRMOQDA" else "AIKO",
                color = primaryColor,
                fontSize = if (isListening || isSpeaking) 11.sp else 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
            if (!isListening && !isSpeaking) {
                Text(
                    text = "AI CORE",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
