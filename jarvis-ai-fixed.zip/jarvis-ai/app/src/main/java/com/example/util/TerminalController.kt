package com.example.util

import android.content.Context
import android.content.Intent

/**
 * Lets AIKO run real shell commands and scripts through Termux — Android's most
 * popular terminal emulator. This does NOT require root: Termux exposes a
 * `RUN_COMMAND` intent (part of its "external app" API) that any app can call once
 * the user grants it, and the result/output appears right inside the Termux app.
 *
 * Requirements on the user's side (one-time setup):
 * 1. Install Termux (F-Droid build recommended — the Play Store build is outdated
 *    and does not support RUN_COMMAND).
 * 2. In Termux, run: `termux-setup-storage` then enable
 *    "allow-external-apps" in ~/.termux/termux.properties.
 * 3. Grant AIKO the "Run commands in Termux" permission when first asked
 *    (Android will prompt automatically the first command that's sent).
 */
object TerminalController {

    private const val TERMUX_PACKAGE = "com.termux"
    private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    private const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

    fun isTermuxInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Runs [command] (e.g. "ls", "echo hi > test.txt", "python3 script.py") in Termux. */
    fun runCommand(context: Context, command: String, workingDir: String = "/data/data/com.termux/files/home"): String {
        if (!isTermuxInstalled(context)) {
            return "Termux o'rnatilmagan. Terminal buyruqlarini bajarish uchun Termux (F-Droid versiyasi) ni o'rnating."
        }
        return try {
            val intent = Intent(ACTION_RUN_COMMAND).apply {
                setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
                putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", command))
                putExtra("com.termux.RUN_COMMAND_WORKDIR", workingDir)
                putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
                putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0") // open Termux so the person can see it run
            }
            context.startForegroundService(intent)
            "Buyruq Termux'ga yuborildi: \"$command\" — natijani Termux oynasida ko'rasiz."
        } catch (e: Exception) {
            "Termux orqali buyruq yuborib bo'lmadi: ${e.message}. \"Ruxsat berish\" so'ralganda tasdiqlaganingizga ishonch hosil qiling."
        }
    }

    /** Writes [content] to a file at [fileName] inside Termux's home, via a shell heredoc. */
    fun writeScript(context: Context, fileName: String, content: String): String {
        val command = "cat > $fileName <<'AIKO_EOF'\n$content\nAIKO_EOF\nchmod +x $fileName 2>/dev/null; echo saqlandi"
        return runCommand(context, command)
    }
}
