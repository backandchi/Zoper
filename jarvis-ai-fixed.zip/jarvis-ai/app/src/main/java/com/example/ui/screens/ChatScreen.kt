package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ChatMessageEntity
import com.example.ui.JarvisViewModel
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ChatScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val isListening by viewModel.speechEngine.isListening.collectAsStateWithLifecycle()
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val isThinkingMode by viewModel.isThinkingModeEnabled.collectAsStateWithLifecycle()
    val isSearchGrounding by viewModel.isSearchGroundingEnabled.collectAsStateWithLifecycle()
    val isTtsAutoPlay by viewModel.isTtsAutoPlay.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    // Auto-scroll to bottom on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ProfessionalDarkBg,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ProfessionalSurfaceDark)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "A.R.K.A.S DIALOGUE STREAM",
                            color = ProfessionalBlueLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "AI Conversation",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Light
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // TTS toggle
                        IconButton(
                            onClick = { viewModel.toggleTtsAutoPlay() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isTtsAutoPlay) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                contentDescription = "Ovozli o'qish",
                                tint = if (isTtsAutoPlay) ProfessionalBlueLight else ProfessionalTextMuted
                            )
                        }

                        // Clear chat
                        IconButton(
                            onClick = { viewModel.clearChatHistory() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Tarixni tozalash",
                                tint = ProfessionalTextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Model Selection Chips Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Flash model
                    ModelChip(
                        name = "Flash 3.5",
                        modelId = "gemini-3.5-flash",
                        isSelected = selectedModel == "gemini-3.5-flash" && !isThinkingMode,
                        onClick = {
                            viewModel.setModel("gemini-3.5-flash")
                            if (isThinkingMode) viewModel.toggleThinkingMode()
                        }
                    )

                    // Thinking Pro Model
                    ModelChip(
                        name = "Pro Thinking",
                        modelId = "gemini-3.1-pro-preview",
                        isSelected = isThinkingMode || selectedModel == "gemini-3.1-pro-preview",
                        color = ProfessionalGold,
                        onClick = {
                            viewModel.toggleThinkingMode()
                        }
                    )

                    // Lite Model
                    ModelChip(
                        name = "Flash Lite",
                        modelId = "gemini-3.1-flash-lite-preview",
                        isSelected = selectedModel == "gemini-3.1-flash-lite-preview",
                        onClick = {
                            viewModel.setModel("gemini-3.1-flash-lite-preview")
                            if (isThinkingMode) viewModel.toggleThinkingMode()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Feature toggles: Search Grounding
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { viewModel.toggleSearchGrounding() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.TravelExplore,
                            contentDescription = null,
                            tint = if (isSearchGrounding) ProfessionalBlueLight else ProfessionalTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSearchGrounding) "Google Search Grounding FAOL" else "Search Grounding o'chiq",
                            color = if (isSearchGrounding) ProfessionalBlueLight else ProfessionalTextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (isThinkingMode) {
                        StatusBadge(text = "THINKING: HIGH", color = ProfessionalGold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Message Thread
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(
                        message = message,
                        onSpeak = { viewModel.speechEngine.speak(message.message) }
                    )
                }

                if (isProcessing) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = ProfessionalBlueLight,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isThinkingMode) "AIKO chuqur fikrlamoqda (Thinking High)..." else "AIKO javob yozmoqda...",
                                color = if (isThinkingMode) ProfessionalGold else ProfessionalBlueLight,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Input Bar at Bottom
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .padding(bottom = 68.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = ProfessionalCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (isListening) viewModel.stopListening() else viewModel.startListening()
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (isListening) ProfessionalCrimson else ProfessionalBlueLight.copy(alpha = 0.12f))
                            .testTag("chat_mic_button")
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Ovoz",
                            tint = if (isListening) Color.White else ProfessionalBlueLight
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    TextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_text_input"),
                        placeholder = { Text("Savol yoki buyruq yozing...", color = ProfessionalTextMuted, fontSize = 13.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = ProfessionalTextPrimary,
                            unfocusedTextColor = ProfessionalTextPrimary
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textInput.isNotBlank()) {
                                    viewModel.processCommand(textInput, isVoiceInput = false)
                                    textInput = ""
                                    focusManager.clearFocus()
                                }
                            }
                        ),
                        singleLine = false,
                        maxLines = 4
                    )

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.processCommand(textInput, isVoiceInput = false)
                                textInput = ""
                                focusManager.clearFocus()
                            }
                        },
                        modifier = Modifier.size(42.dp),
                        enabled = textInput.isNotBlank() && !isProcessing
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Yuborish",
                            tint = if (textInput.isNotBlank()) ProfessionalBlueLight else ProfessionalTextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModelChip(
    name: String,
    modelId: String,
    isSelected: Boolean,
    color: Color = ProfessionalBlueLight,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) color.copy(alpha = 0.18f) else ProfessionalSurfaceDark)
            .border(1.dp, if (isSelected) color.copy(alpha = 0.5f) else ProfessionalCardBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = name,
            color = if (isSelected) color else ProfessionalTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun ChatBubble(
    message: ChatMessageEntity,
    onSpeak: () -> Unit
) {
    val isUser = message.role == "user"
    val timeStr = remember(message.timestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chat_bubble_${message.id}"),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(ProfessionalBlueLight.copy(alpha = 0.15f))
                    .border(1.dp, ProfessionalBlueLight.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("J", color = ProfessionalBlueLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Card(
            modifier = Modifier.widthIn(max = 280.dp),
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isUser) 20.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 20.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) ProfessionalBluePrimary.copy(alpha = 0.25f) else ProfessionalCardBg
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isUser) ProfessionalBlueLight.copy(alpha = 0.4f) else ProfessionalCardBorder
            )
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (!isUser && message.actionExecuted != null) {
                    StatusBadge(text = "BUYRUQ: ${message.actionExecuted}", color = ProfessionalGold)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Text(
                    text = message.message,
                    color = ProfessionalTextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = timeStr,
                        color = ProfessionalTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    if (!isUser) {
                        IconButton(onClick = onSpeak, modifier = Modifier.size(22.dp)) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "O'qish", tint = ProfessionalBlueLight, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }
    }
}
