package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.apiKeyDataStore by preferencesDataStore(name = "aiko_gemini_keys")

/**
 * Stores an unlimited list of user-supplied Gemini API keys locally on-device
 * (never bundled into the APK, never sent anywhere except Google's Gemini API).
 *
 * Also remembers which key index last worked, so GeminiService can resume
 * rotation from there instead of always starting at key #1.
 */
object ApiKeyStore {
    private const val DELIMITER = "||"
    private val KEYS_LIST = stringPreferencesKey("gemini_api_keys")
    private val CURRENT_INDEX = intPreferencesKey("gemini_api_key_index")

    fun getKeysFlow(context: Context): Flow<List<String>> =
        context.apiKeyDataStore.data.map { prefs -> parseKeys(prefs[KEYS_LIST]) }

    suspend fun getKeys(context: Context): List<String> = getKeysFlow(context).first()

    suspend fun addKey(context: Context, key: String) {
        val trimmed = key.trim()
        if (trimmed.isBlank()) return
        context.apiKeyDataStore.edit { prefs ->
            val current = parseKeys(prefs[KEYS_LIST]).toMutableList()
            if (!current.contains(trimmed)) {
                current.add(trimmed)
            }
            prefs[KEYS_LIST] = current.joinToString(DELIMITER)
        }
    }

    suspend fun removeKey(context: Context, key: String) {
        context.apiKeyDataStore.edit { prefs ->
            val current = parseKeys(prefs[KEYS_LIST]).toMutableList()
            current.remove(key)
            prefs[KEYS_LIST] = current.joinToString(DELIMITER)
        }
    }

    suspend fun getCurrentIndex(context: Context): Int =
        context.apiKeyDataStore.data.map { it[CURRENT_INDEX] ?: 0 }.first()

    suspend fun setCurrentIndex(context: Context, index: Int) {
        context.apiKeyDataStore.edit { prefs -> prefs[CURRENT_INDEX] = index }
    }

    private fun parseKeys(raw: String?): List<String> =
        raw?.split(DELIMITER)?.map { it.trim() }?.filter { it.isNotBlank() } ?: emptyList()
}
