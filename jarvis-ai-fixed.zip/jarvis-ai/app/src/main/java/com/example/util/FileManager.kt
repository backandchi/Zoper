package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

data class WorkspaceFile(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long
)

/**
 * A small "developer environment" for AIKO: create, read, edit, rename, delete, and
 * share files. Works out of the box in AIKO's private workspace folder (no
 * permission dialog needed), and can optionally be pointed at any folder the user
 * picks via the system folder picker (Storage Access Framework) for full access
 * outside the app's sandbox — e.g. a Downloads or project folder.
 */
class FileManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("aiko_file_manager", Context.MODE_PRIVATE)

    private val _workspaceTreeUri = MutableStateFlow(prefs.getString(KEY_TREE_URI, null)?.let { Uri.parse(it) })
    val workspaceTreeUri: StateFlow<Uri?> = _workspaceTreeUri.asStateFlow()

    /** Always-available private workspace — no permissions or user setup needed. */
    val privateWorkspaceDir: File by lazy {
        File(context.getExternalFilesDir(null), "AIKO_Workspace").apply { mkdirs() }
    }

    fun setWorkspaceTree(uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        prefs.edit().putString(KEY_TREE_URI, uri.toString()).apply()
        _workspaceTreeUri.value = uri
    }

    fun clearWorkspaceTree() {
        prefs.edit().remove(KEY_TREE_URI).apply()
        _workspaceTreeUri.value = null
    }

    private fun rootDocument(): DocumentFile? {
        val treeUri = _workspaceTreeUri.value ?: return null
        return DocumentFile.fromTreeUri(context, treeUri)
    }

    suspend fun listFiles(): List<WorkspaceFile> = withContext(Dispatchers.IO) {
        val tree = rootDocument()
        if (tree != null) {
            tree.listFiles().map {
                WorkspaceFile(
                    name = it.name ?: "(noma'lum)",
                    uri = it.uri,
                    isDirectory = it.isDirectory,
                    sizeBytes = it.length(),
                    lastModified = it.lastModified()
                )
            }.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        } else {
            privateWorkspaceDir.listFiles()?.map { f ->
                WorkspaceFile(
                    name = f.name,
                    uri = Uri.fromFile(f),
                    isDirectory = f.isDirectory,
                    sizeBytes = f.length(),
                    lastModified = f.lastModified()
                )
            }?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
        }
    }

    suspend fun createFile(fileName: String, content: String = ""): Boolean = withContext(Dispatchers.IO) {
        try {
            val tree = rootDocument()
            if (tree != null) {
                val newFile = tree.createFile("text/plain", fileName) ?: return@withContext false
                context.contentResolver.openOutputStream(newFile.uri)?.use { it.write(content.toByteArray()) }
            } else {
                File(privateWorkspaceDir, fileName).writeText(content)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun readFile(uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            if (uri.scheme == "file") {
                File(uri.path ?: return@withContext "").readText()
            } else {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            }
        } catch (e: Exception) {
            "Faylni o'qib bo'lmadi: ${e.message}"
        }
    }

    suspend fun writeFile(uri: Uri, content: String): Boolean = withContext(Dispatchers.IO) {
        try {
            if (uri.scheme == "file") {
                File(uri.path ?: return@withContext false).writeText(content)
            } else {
                context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(content.toByteArray()) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deleteFile(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            if (uri.scheme == "file") {
                File(uri.path ?: return@withContext false).delete()
            } else {
                DocumentFile.fromSingleUri(context, uri)?.delete() ?: false
            }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun renameFile(uri: Uri, newName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            if (uri.scheme == "file") {
                val old = File(uri.path ?: return@withContext false)
                old.renameTo(File(old.parentFile, newName))
            } else {
                DocumentFile.fromSingleUri(context, uri)?.renameTo(newName) ?: false
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Builds a share Intent so a file can be copied/sent to another app (Telegram, Drive, Mail, etc.). */
    fun buildShareIntent(uri: Uri): Intent {
        val shareUri = if (uri.scheme == "file") {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(uri.path!!))
        } else uri
        return Intent(Intent.ACTION_SEND).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_STREAM, shareUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    companion object {
        private const val KEY_TREE_URI = "workspace_tree_uri"
    }
}
