package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * AIKO's "hands and eyes" on the screen.
 *
 * This is a real Android AccessibilityService — the user must turn it on once in
 * Settings > Accessibility (Android requires this manual step for any app that reads
 * screen content and taps on the user's behalf; it cannot be auto-enabled from code).
 *
 * Once it's on, AIKO can inspect what's currently visible (the accessibility node
 * tree) and tap / type / swipe like a person would, which is what makes commands like
 * "Telegram'da Anvarga salom deb yoz" actually open the app, find the chat, type the
 * message and press send — instead of just opening the app and stopping there.
 */
class AikoAccessibilityService : AccessibilityService() {

    companion object {
        private var instance: AikoAccessibilityService? = null
        val isConnected = MutableStateFlow(false)

        fun getInstance(): AikoAccessibilityService? = instance
    }

    val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        isConnected.value = true
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        isConnected.value = false
        serviceScope.cancel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No passive handling needed — screen state is read on-demand (see below),
        // which keeps this service lightweight and battery-friendly.
    }

    override fun onInterrupt() {}

    // ---------- Screen inspection ----------

    /** Lightweight text summary of clickable/editable/text elements currently on screen. */
    fun describeScreen(maxNodes: Int = 60): String {
        val root = rootInActiveWindow ?: return "Ekran o'qib bo'lmadi (root topilmadi)."
        val lines = mutableListOf<String>()
        collectNodeText(root, lines, maxNodes)
        return if (lines.isEmpty()) "Ekranda matn topilmadi." else lines.joinToString("\n")
    }

    private fun collectNodeText(node: AccessibilityNodeInfo, out: MutableList<String>, max: Int) {
        if (out.size >= max) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        val label = if (!text.isNullOrBlank()) text else desc
        if (!label.isNullOrBlank() && (node.isClickable || node.isEditable)) {
            out.add(label)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectNodeText(child, out, max)
            child.recycle()
        }
    }

    /** Finds the nearest clickable node whose text or content-description contains [query]. */
    private fun findNodeByText(query: String, root: AccessibilityNodeInfo? = rootInActiveWindow): AccessibilityNodeInfo? {
        if (root == null) return null
        val matches = root.findAccessibilityNodeInfosByText(query) ?: return null
        for (match in matches) {
            var node: AccessibilityNodeInfo? = match
            var depth = 0
            while (node != null && depth < 6) {
                if (node.isClickable) return node
                node = node.parent
                depth++
            }
        }
        return matches.firstOrNull()
    }

    private fun findFirstEditableNode(root: AccessibilityNodeInfo? = rootInActiveWindow): AccessibilityNodeInfo? {
        if (root == null) return null
        if (root.isEditable) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findFirstEditableNode(child)
            if (found != null) return found
        }
        return null
    }

    // ---------- Actions ----------

    /** Taps whatever on-screen element contains [text]. Returns true if something was tapped. */
    fun tapByText(text: String): Boolean {
        val node = findNodeByText(text) ?: return false
        val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (clicked) return true
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return tapAt(bounds.centerX().toFloat(), bounds.centerY().toFloat())
    }

    /** Types [text] into the currently focused / first editable field on screen. */
    fun typeIntoFocusedField(text: String): Boolean {
        val node = findFirstEditableNode() ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val arguments = Bundle()
        arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    /** Low-level tap gesture at absolute screen coordinates. */
    fun tapAt(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /** Swipes from one point to another — used for scrolling chat/contact lists. */
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    /** Waits for the screen to settle after navigation before the next step runs. */
    suspend fun waitForScreen(delayMs: Long = 900) = delay(delayMs)
}
