package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Design Palette
val ProfessionalDarkBg = Color(0xFF0F1115)
val ProfessionalSurfaceDark = Color(0xFF16181D)
val ProfessionalCardBg = Color(0xFF1B1B1F)
val ProfessionalCardActive = Color(0xFF252529)
val ProfessionalCardBorder = Color(0x1FFFFFFF)
val ProfessionalCardBorderBlue = Color(0x3360A5FA)

val ProfessionalBluePrimary = Color(0xFF2563EB) // blue-600
val ProfessionalBlueLight = Color(0xFF60A5FA) // blue-400
val ProfessionalBlueAccent = Color(0xFF3B82F6) // blue-500
val ProfessionalCyan = Color(0xFF22D3EE) // cyan-400
val ProfessionalIndigo = Color(0xFF4F46E5) // indigo-600

val ProfessionalEmerald = Color(0xFF10B981)
val ProfessionalGold = Color(0xFFF59E0B)
val ProfessionalCrimson = Color(0xFFEF4444)
val ProfessionalPurple = Color(0xFFA855F7)

val ProfessionalTextPrimary = Color(0xFFFFFFFF)
val ProfessionalTextSecondary = Color(0xFF9CA3AF) // gray-400
val ProfessionalTextMuted = Color(0xFF6B7280) // gray-500

// Theme aliases for seamless compatibility
val JarvisCyan = ProfessionalBlueLight
val JarvisCyanDark = ProfessionalBluePrimary
val JarvisCyanGlow = Color(0x5560A5FA)
val JarvisBlue = ProfessionalBluePrimary
val JarvisGold = ProfessionalGold
val JarvisGoldGlow = Color(0x55F59E0B)
val JarvisEmerald = ProfessionalEmerald
val JarvisCrimson = ProfessionalCrimson

val JarvisDarkBg = ProfessionalDarkBg
val JarvisSurfaceDark = ProfessionalSurfaceDark
val JarvisCardBg = ProfessionalCardBg
val JarvisCardBorder = ProfessionalCardBorder
val JarvisTextPrimary = ProfessionalTextPrimary
val JarvisTextSecondary = ProfessionalTextSecondary
val JarvisTextMuted = ProfessionalTextMuted


