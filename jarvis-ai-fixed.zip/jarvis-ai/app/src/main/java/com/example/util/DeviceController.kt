package com.example.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class InstalledAppItem(
    val name: String,
    val packageName: String,
    val isSystemApp: Boolean = false
)

data class BatteryInfo(
    val level: Int = 100,
    val isCharging: Boolean = false,
    val temperatureCelsius: Float = 28.0f,
    val technology: String = "Li-ion"
)

data class NetworkInfo(
    val isConnected: Boolean = true,
    val isWifi: Boolean = true,
    val isCellular: Boolean = false,
    val networkType: String = "Wi-Fi"
)

class DeviceController(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private val _batteryInfo = MutableStateFlow(BatteryInfo())
    val batteryInfo: StateFlow<BatteryInfo> = _batteryInfo.asStateFlow()

    private val _networkInfo = MutableStateFlow(NetworkInfo())
    val networkInfo: StateFlow<NetworkInfo> = _networkInfo.asStateFlow()

    private var cameraId: String? = null

    init {
        initCamera()
        updateBatteryInfo()
        updateNetworkInfo()
    }

    private fun initCamera() {
        try {
            cameraManager?.let { manager ->
                for (id in manager.cameraIdList) {
                    val characteristics = manager.getCameraCharacteristics(id)
                    val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                    if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        cameraId = id
                        break
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleFlashlight(): Boolean {
        return setFlashlight(!_isFlashlightOn.value)
    }

    fun setFlashlight(enable: Boolean): Boolean {
        try {
            val id = cameraId ?: cameraManager?.cameraIdList?.firstOrNull()
            if (id != null && cameraManager != null) {
                cameraManager.setTorchMode(id, enable)
                _isFlashlightOn.value = enable
                triggerHaptic(HapticType.SUCCESS)
                return true
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun updateBatteryInfo() {
        try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)

            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else 85

            val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

            val temp = (batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 280) / 10f
            val tech = batteryStatus?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

            _batteryInfo.value = BatteryInfo(
                level = batteryPct,
                isCharging = isCharging,
                temperatureCelsius = temp,
                technology = tech
            )
        } catch (e: Exception) {
            _batteryInfo.value = BatteryInfo(level = 88, isCharging = false, temperatureCelsius = 30.5f)
        }
    }

    fun updateNetworkInfo() {
        try {
            val network = connectivityManager?.activeNetwork
            val capabilities = connectivityManager?.getNetworkCapabilities(network)

            val isConnected = capabilities != null &&
                    (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                     capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))

            val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val isCellular = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

            val netType = when {
                isWifi -> "Wi-Fi 6 (Ulangan)"
                isCellular -> "Mobil Internet (5G/LTE)"
                isConnected -> "Internet Mavjud"
                else -> "Oflayn"
            }

            _networkInfo.value = NetworkInfo(
                isConnected = isConnected,
                isWifi = isWifi,
                isCellular = isCellular,
                networkType = netType
            )
        } catch (e: Exception) {
            _networkInfo.value = NetworkInfo(isConnected = true, isWifi = true, networkType = "Wi-Fi")
        }
    }

    fun setVolume(percent: Int) {
        try {
            audioManager?.let { am ->
                val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val targetVol = (maxVol * (percent / 100f)).toInt().coerceIn(0, maxVol)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
                triggerHaptic(HapticType.CLICK)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setSilentMode(enable: Boolean) {
        try {
            audioManager?.let { am ->
                if (enable) {
                    am.ringerMode = AudioManager.RINGER_MODE_SILENT
                } else {
                    am.ringerMode = AudioManager.RINGER_MODE_NORMAL
                }
                triggerHaptic(HapticType.SUCCESS)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun createTimer(seconds: Int, message: String = "JARVIS Taymeri"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            triggerHaptic(HapticType.SUCCESS)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Taymer o'rnatildi: $seconds soniya", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun createAlarm(hour: Int, minutes: Int, message: String = "JARVIS Budilnik"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            triggerHaptic(HapticType.SUCCESS)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Budilnik o'rnatildi: $hour:$minutes", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun getInstalledApps(): List<InstalledAppItem> {
        val appList = mutableListOf<InstalledAppItem>()
        try {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolved = pm.queryIntentActivities(mainIntent, 0)
            for (info in resolved) {
                val label = info.loadLabel(pm).toString()
                val pkg = info.activityInfo.packageName
                if (pkg != context.packageName) {
                    val isSys = (info.activityInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                    appList.add(InstalledAppItem(name = label, packageName = pkg, isSystemApp = isSys))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return appList.sortedBy { it.name }
    }

    fun launchByPackageName(packageName: String): Boolean {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return tryStartActivity(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun launchApp(appName: String): Boolean {
        val trimmed = appName.lowercase().trim()
        if (trimmed.isBlank()) return false
        
        // 1. Direct common app and action aliases
        when {
            trimmed.contains("kamera") || trimmed.contains("camera") -> {
                val intent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (tryStartActivity(intent)) return true
            }
            trimmed.contains("galereya") || trimmed.contains("gallery") || trimmed.contains("rasm") || trimmed.contains("photo") -> {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    type = "image/*"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (tryStartActivity(intent)) return true
            }
            trimmed.contains("kalkulyator") || trimmed.contains("calculator") -> {
                val candidates = listOf(
                    "com.google.android.calculator",
                    "com.android.calculator2",
                    "com.sec.android.app.popupcalculator",
                    "com.miui.calculator",
                    "com.coloros.calculator"
                )
                for (pkg in candidates) {
                    if (launchByPackageName(pkg)) return true
                }
            }
            trimmed.contains("youtube") || trimmed.contains("yutub") -> {
                if (launchByPackageName("com.google.android.youtube")) return true
                return openWebUrl("https://www.youtube.com")
            }
            trimmed.contains("telegram") -> {
                if (launchByPackageName("org.telegram.messenger") || 
                    launchByPackageName("org.telegram.plus") || 
                    launchByPackageName("org.thunderdog.challegram")) return true
            }
            trimmed.contains("whatsapp") || trimmed.contains("vatsap") -> {
                if (launchByPackageName("com.whatsapp") || launchByPackageName("com.whatsapp.w4b")) return true
            }
            trimmed.contains("instagram") || trimmed.contains("insta") -> {
                if (launchByPackageName("com.instagram.android")) return true
            }
            trimmed.contains("tiktok") -> {
                if (launchByPackageName("com.zhiliaoapp.musically") || launchByPackageName("com.ss.android.ugc.trill")) return true
            }
            trimmed.contains("chrome") || trimmed.contains("brauzer") || trimmed.contains("browser") || trimmed.contains("internet") -> {
                if (launchByPackageName("com.android.chrome")) return true
                return openWebUrl("https://www.google.com")
            }
            trimmed.contains("sozlama") || trimmed.contains("settings") -> {
                val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(intent)
            }
            trimmed.contains("play market") || trimmed.contains("play store") || trimmed.contains("google play") -> {
                if (launchByPackageName("com.android.vending")) return true
            }
            trimmed.contains("xarita") || trimmed.contains("maps") || trimmed.contains("navigat") -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (tryStartActivity(intent)) return true
            }
            trimmed.contains("telefon") || trimmed.contains("qo'ng'iroq") || trimmed.contains("dialer") -> {
                return openDialer()
            }
            trimmed.contains("sms") || trimmed.contains("xabar") -> {
                return openSms()
            }
            trimmed.contains("kontakt") || trimmed.contains("contacts") -> {
                val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (tryStartActivity(intent)) return true
            }
            trimmed.contains("soat") || trimmed.contains("clock") || trimmed.contains("budilnik") -> {
                val candidates = listOf(
                    "com.google.android.deskclock",
                    "com.android.deskclock",
                    "com.sec.android.app.clockpackage"
                )
                for (pkg in candidates) {
                    if (launchByPackageName(pkg)) return true
                }
            }
            trimmed.contains("fayl") || trimmed.contains("files") || trimmed.contains("проводник") -> {
                val candidates = listOf(
                    "com.google.android.apps.nbu.files",
                    "com.android.documentsui",
                    "com.sec.android.app.myfiles"
                )
                for (pkg in candidates) {
                    if (launchByPackageName(pkg)) return true
                }
            }
        }

        // 2. Comprehensive PackageManager search across ALL installed apps
        try {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolved = pm.queryIntentActivities(mainIntent, 0)
            
            // Exact label match
            val exact = resolved.firstOrNull { 
                it.loadLabel(pm).toString().equals(trimmed, ignoreCase = true) 
            }
            if (exact != null) {
                val intent = pm.getLaunchIntentForPackage(exact.activityInfo.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(intent)
                }
            }

            // Fuzzy / Substring match in app name
            val fuzzy = resolved.firstOrNull { 
                val label = it.loadLabel(pm).toString().lowercase()
                label.contains(trimmed) || trimmed.contains(label) ||
                it.activityInfo.packageName.lowercase().contains(trimmed)
            }
            if (fuzzy != null) {
                val intent = pm.getLaunchIntentForPackage(fuzzy.activityInfo.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(intent)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 3. Fallback: Search on Google
        return openWebUrl("https://www.google.com/search?q=${Uri.encode(appName)}")
    }

    fun openDialer(phoneNumber: String = ""): Boolean {
        val uri = if (phoneNumber.isNotBlank()) Uri.parse("tel:${Uri.encode(phoneNumber.trim())}") else Uri.parse("tel:")
        val intent = Intent(Intent.ACTION_DIAL, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun openSms(phoneNumber: String = "", message: String = ""): Boolean {
        val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "").trim()
        val uri = if (cleanPhone.isNotBlank()) Uri.parse("smsto:$cleanPhone") else Uri.parse("smsto:")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            if (message.isNotBlank()) putExtra("sms_body", message)
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun sendTelegramMessage(target: String = "", message: String = ""): Boolean {
        val cleanTarget = target.replace("@", "").trim()
        return try {
            val uri = when {
                cleanTarget.isNotBlank() && message.isNotBlank() -> 
                    Uri.parse("https://t.me/$cleanTarget?text=${Uri.encode(message)}")
                cleanTarget.isNotBlank() -> 
                    Uri.parse("https://t.me/$cleanTarget")
                message.isNotBlank() -> 
                    Uri.parse("https://t.me/share/url?url=&text=${Uri.encode(message)}")
                else -> 
                    null
            }

            if (uri != null) {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("org.telegram.messenger")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (tryStartActivity(intent)) return true

                // Fallback to web/any browser
                val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(fallbackIntent)
            } else {
                launchApp("telegram")
            }
        } catch (e: Exception) {
            launchApp("telegram")
        }
    }

    fun sendWhatsAppMessage(phoneNumber: String = "", message: String = ""): Boolean {
        val cleanPhone = phoneNumber.replace(Regex("[^0-9]"), "").trim()
        return try {
            val url = if (cleanPhone.isNotBlank()) {
                "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}"
            } else {
                "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (tryStartActivity(intent)) return true

            val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            tryStartActivity(fallbackIntent)
        } catch (e: Exception) {
            launchApp("whatsapp")
        }
    }

    fun setAlarm(hour: Int, minute: Int, message: String = "JARVIS Budilnik"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            tryStartActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun setTimer(seconds: Int, message: String = "JARVIS Taymer"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            tryStartActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun openMapLocation(locationQuery: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(locationQuery)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun openWifiSettings(): Boolean {
        val intent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun openBluetoothSettings(): Boolean {
        val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun searchYouTube(query: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun searchGoogle(query: String): Boolean {
        return openWebUrl("https://www.google.com/search?q=${Uri.encode(query)}")
    }

    fun openWebUrl(url: String): Boolean {
        val safeUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(safeUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    private fun tryStartActivity(intent: Intent): Boolean {
        return try {
            context.startActivity(intent)
            triggerHaptic(HapticType.SUCCESS)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun triggerHaptic(type: HapticType = HapticType.CLICK) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            vibrator?.let { v ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = when (type) {
                        HapticType.CLICK -> VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
                        HapticType.SUCCESS -> VibrationEffect.createWaveform(longArrayOf(0, 40, 50, 60), -1)
                        HapticType.ALERT -> VibrationEffect.createWaveform(longArrayOf(0, 100, 80, 150), -1)
                    }
                    v.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(50)
                }
            }
        } catch (e: Exception) {
            // Silently ignore if not supported
        }
    }

    enum class HapticType {
        CLICK, SUCCESS, ALERT
    }
}
