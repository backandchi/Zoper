package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
  primary = ProfessionalBlueLight,
  onPrimary = Color(0xFF0F172A),
  primaryContainer = Color(0xFF1E3A8A),
  onPrimaryContainer = Color(0xFFDBEAFE),
  secondary = ProfessionalBlueAccent,
  onSecondary = Color(0xFFFFFFFF),
  secondaryContainer = Color(0xFF1E293B),
  onSecondaryContainer = ProfessionalBlueLight,
  tertiary = ProfessionalEmerald,
  onTertiary = Color(0xFFFFFFFF),
  background = ProfessionalDarkBg,
  onBackground = ProfessionalTextPrimary,
  surface = ProfessionalSurfaceDark,
  onSurface = ProfessionalTextPrimary,
  surfaceVariant = ProfessionalCardBg,
  onSurfaceVariant = ProfessionalTextSecondary,
  outline = ProfessionalCardBorder,
  error = ProfessionalCrimson,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = JarvisColorScheme,
    typography = Typography,
    content = content
  )
}

