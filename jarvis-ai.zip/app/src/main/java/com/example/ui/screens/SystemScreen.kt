package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JarvisViewModel
import com.example.ui.components.HolographicCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun SystemScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isLiveActive by com.example.service.JarvisLiveService.isLiveActive.collectAsStateWithLifecycle()
    val batteryInfo by viewModel.deviceController.batteryInfo.collectAsStateWithLifecycle()
    val networkInfo by viewModel.deviceController.networkInfo.collectAsStateWithLifecycle()
    val isFlashlightOn by viewModel.deviceController.isFlashlightOn.collectAsStateWithLifecycle()

    var volumeSliderValue by remember { mutableFloatStateOf(70f) }
    var timerMinutes by remember { mutableIntStateOf(5) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ProfessionalDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "A.R.K.A.S SYSTEM DIAGNOSTICS",
                        color = ProfessionalBlueLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Phone Command Center",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Light
                    )
                }

                StatusBadge(
                    text = if (isLiveActive) "LIVE ACTIVE" else "ONLINE",
                    color = if (isLiveActive) ProfessionalEmerald else ProfessionalBlueLight
                )
            }
        }

        // 1. JARVIS LIVE (Background Service & Floating HUD)
        item {
            HolographicCard(
                title = "JARVIS Live & Floating HUD",
                subtitle = if (isLiveActive) "Fon xizmati ishlamoqda (Ilovadan tashqarida ham faol)" else "Ilovadan chiqqan holda ovozli boshqaruv",
                icon = Icons.Default.Sensors,
                accentColor = if (isLiveActive) ProfessionalEmerald else ProfessionalBlueLight
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isLiveActive) "LIVE FOYDALANUVCHI REJIMI FAOL" else "FON REJIMINI YOQISH",
                            color = if (isLiveActive) ProfessionalEmerald else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Boshqa ilovalarda bo'lsangiz ham ekranda suzuvchi Arc Reactor orqali gaplasha olasiz.",
                            color = ProfessionalTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Switch(
                        checked = isLiveActive,
                        onCheckedChange = { enable ->
                            if (enable) {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(context)) {
                                    val intent = android.content.Intent(
                                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        android.net.Uri.parse("package:${context.packageName}")
                                    ).apply {
                                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                }
                                com.example.service.JarvisLiveService.start(context)
                            } else {
                                com.example.service.JarvisLiveService.stop(context)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ProfessionalEmerald,
                            uncheckedThumbColor = ProfessionalTextSecondary,
                            uncheckedTrackColor = ProfessionalSurfaceDark
                        )
                    )
                }

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(context)) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:${context.packageName}")
                            ).apply {
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalBlueLight.copy(alpha = 0.2f), contentColor = ProfessionalBlueLight),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Ekranda ko'rinish ruxsatini berish (Floating HUD)", fontSize = 12.sp)
                    }
                }
            }
        }

        // 2. Hardware Flashlight Control
        item {
            HolographicCard(
                title = "Hardware Flashlight",
                subtitle = if (isFlashlightOn) "Torch active" else "Torch standby",
                icon = Icons.Default.FlashlightOn,
                accentColor = if (isFlashlightOn) ProfessionalGold else ProfessionalBlueLight
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isFlashlightOn) "FAOL (ON)" else "O'CHIQLIGIDA (OFF)",
                        color = if (isFlashlightOn) ProfessionalGold else ProfessionalTextSecondary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )

                    Switch(
                        checked = isFlashlightOn,
                        onCheckedChange = { viewModel.deviceController.setFlashlight(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ProfessionalGold,
                            uncheckedThumbColor = ProfessionalTextSecondary,
                            uncheckedTrackColor = ProfessionalSurfaceDark
                        ),
                        modifier = Modifier.testTag("flashlight_switch")
                    )
                }
            }
        }

        // 3. Battery & Power Diagnostics
        item {
            HolographicCard(
                title = "Power & Telemetry",
                subtitle = if (batteryInfo.isCharging) "Zaryadlanmoqda" else "Batareyadan ishlamoqda",
                icon = Icons.Default.BatteryChargingFull,
                accentColor = ProfessionalEmerald
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "QUVVAT DARAJASI", color = ProfessionalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "${batteryInfo.level}%", color = ProfessionalTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(text = "HARORAT", color = ProfessionalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "${batteryInfo.temperatureCelsius}°C", color = ProfessionalTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(text = "TEXNOLOGIYA", color = ProfessionalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = batteryInfo.technology, color = ProfessionalTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { batteryInfo.level / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (batteryInfo.level < 20) ProfessionalCrimson else ProfessionalEmerald,
                    trackColor = ProfessionalSurfaceDark
                )
            }
        }

        // 4. Audio & Volume Control
        item {
            HolographicCard(
                title = "Media Audio Matrix",
                subtitle = "Ovoz balandligi: ${volumeSliderValue.toInt()}%",
                icon = Icons.Default.VolumeUp,
                accentColor = ProfessionalBlueLight
            ) {
                Slider(
                    value = volumeSliderValue,
                    onValueChange = {
                        volumeSliderValue = it
                        viewModel.deviceController.setVolume(it.toInt())
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = ProfessionalBlueLight,
                        activeTrackColor = ProfessionalBlueLight,
                        inactiveTrackColor = ProfessionalSurfaceDark
                    ),
                    modifier = Modifier.testTag("volume_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            volumeSliderValue = 0f
                            viewModel.deviceController.setSilentMode(true)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalSurfaceDark, contentColor = ProfessionalTextPrimary),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
                    ) {
                        Text("Tinch Rejim", fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            volumeSliderValue = 100f
                            viewModel.deviceController.setVolume(100)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfessionalSurfaceDark, contentColor = ProfessionalTextPrimary),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
                    ) {
                        Text("100% Balandlik", fontSize = 11.sp)
                    }
                }
            }
        }

        // 5. Quick Timers & Alerts
        item {
            HolographicCard(
                title = "Quick Timers & Alerts",
                subtitle = "Tezkor taymer o'rnatish",
                icon = Icons.Default.Alarm,
                accentColor = ProfessionalGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 5, 15, 30).forEach { mins ->
                        val isSelected = timerMinutes == mins
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) ProfessionalGold.copy(alpha = 0.2f) else ProfessionalSurfaceDark)
                                .border(1.dp, if (isSelected) ProfessionalGold else ProfessionalCardBorder, RoundedCornerShape(10.dp))
                                .clickable { timerMinutes = mins }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$mins daq",
                                color = if (isSelected) ProfessionalGold else ProfessionalTextSecondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.deviceController.createTimer(timerMinutes * 60, "JARVIS $timerMinutes daqiqa") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ProfessionalGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("$timerMinutes daqiqalik Taymerni Ishga Tushurish", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // 6. Complete Phone Tools & App Hub
        item {
            HolographicCard(
                title = "Phone Tools & App Launcher",
                subtitle = "Telefon ilovalari va tizim buyruqlari",
                icon = Icons.Default.Apps,
                accentColor = ProfessionalBlueLight
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Telegram", icon = Icons.Default.Send, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("telegram")
                    }
                    AppLaunchButton(name = "WhatsApp", icon = Icons.Default.Chat, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("whatsapp")
                    }
                    AppLaunchButton(name = "YouTube", icon = Icons.Default.PlayCircle, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("youtube")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Kamera", icon = Icons.Default.CameraAlt, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("camera")
                    }
                    AppLaunchButton(name = "Galereya", icon = Icons.Default.PhotoLibrary, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("galereya")
                    }
                    AppLaunchButton(name = "Kalkulyator", icon = Icons.Default.Calculate, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("kalkulyator")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Telefon", icon = Icons.Default.Call, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.openDialer()
                    }
                    AppLaunchButton(name = "Wi-Fi", icon = Icons.Default.Wifi, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.openWifiSettings()
                    }
                    AppLaunchButton(name = "Bluetooth", icon = Icons.Default.Bluetooth, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.openBluetoothSettings()
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLaunchButton(name = "Xarita", icon = Icons.Default.Map, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("maps")
                    }
                    AppLaunchButton(name = "Sozlamalar", icon = Icons.Default.Settings, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("settings")
                    }
                    AppLaunchButton(name = "Brauzer", icon = Icons.Default.Language, modifier = Modifier.weight(1f)) {
                        viewModel.deviceController.launchApp("chrome")
                    }
                }
            }
        }
    }
}

@Composable
fun AppLaunchButton(
    name: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ProfessionalSurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = ProfessionalBlueLight, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = name, color = ProfessionalTextPrimary, fontSize = 11.sp, maxLines = 1)
        }
    }
}
