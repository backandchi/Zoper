package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.remote.GeminiService
import com.example.data.repository.JarvisRepository
import com.example.util.DeviceController
import com.example.util.SpeechEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val deviceController = DeviceController(application)
    val speechEngine = SpeechEngine(application, viewModelScope)

    private val database = JarvisDatabase.getDatabase(application, viewModelScope)
    val repository = JarvisRepository(database.jarvisDao())

    // Database reactive streams
    val memories: StateFlow<List<MemoryEntity>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val protocols: StateFlow<List<ProtocolEntity>> = repository.allProtocols
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state
    private val _selectedModel = MutableStateFlow("gemini-3.5-flash")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _isThinkingModeEnabled = MutableStateFlow(false)
    val isThinkingModeEnabled: StateFlow<Boolean> = _isThinkingModeEnabled.asStateFlow()

    private val _isSearchGroundingEnabled = MutableStateFlow(true)
    val isSearchGroundingEnabled: StateFlow<Boolean> = _isSearchGroundingEnabled.asStateFlow()

    private val _isTtsAutoPlay = MutableStateFlow(true)
    val isTtsAutoPlay: StateFlow<Boolean> = _isTtsAutoPlay.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _lastActionStatus = MutableStateFlow<String?>(null)
    val lastActionStatus: StateFlow<String?> = _lastActionStatus.asStateFlow()

    // Multimodal Studio States
    private val _generatedImageBase64 = MutableStateFlow<String?>(null)
    val generatedImageBase64: StateFlow<String?> = _generatedImageBase64.asStateFlow()

    private val _generatedMusicBytes = MutableStateFlow<ByteArray?>(null)
    val generatedMusicBytes: StateFlow<ByteArray?> = _generatedMusicBytes.asStateFlow()

    private val _studioStatusMessage = MutableStateFlow<String?>(null)
    val studioStatusMessage: StateFlow<String?> = _studioStatusMessage.asStateFlow()

    private val _transcriptionText = MutableStateFlow<String?>(null)
    val transcriptionText: StateFlow<String?> = _transcriptionText.asStateFlow()

    init {
        speechEngine.onSpeechRecognized = { text ->
            processCommand(text, isVoiceInput = true)
        }
    }

    fun setModel(model: String) {
        _selectedModel.value = model
    }

    fun toggleThinkingMode() {
        val next = !_isThinkingModeEnabled.value
        _isThinkingModeEnabled.value = next
        if (next) {
            _selectedModel.value = "gemini-3.1-pro-preview"
        } else if (_selectedModel.value == "gemini-3.1-pro-preview") {
            _selectedModel.value = "gemini-3.5-flash"
        }
    }

    fun toggleSearchGrounding() {
        _isSearchGroundingEnabled.value = !_isSearchGroundingEnabled.value
    }

    fun toggleTtsAutoPlay() {
        _isTtsAutoPlay.value = !_isTtsAutoPlay.value
    }

    fun startListening() {
        deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        speechEngine.startListening()
    }

    fun stopListening() {
        speechEngine.stopListening()
    }

    fun stopSpeaking() {
        speechEngine.stopAudio()
    }

    /**
     * Central Jarvis Intent Analyzer & Executor
     */
    fun processCommand(input: String, isVoiceInput: Boolean = false) {
        val prompt = input.trim()
        if (prompt.isBlank()) return

        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _lastActionStatus.value = null

            // 1. Save user turn to chat history
            repository.saveMessage(role = "user", message = prompt, isVoice = isVoiceInput)

            val lower = prompt.lowercase(Locale.ROOT)

            // 2. Check Direct Hardware & Action Commands
            var handledLocally = false
            var responseText = ""
            var actionTag: String? = null

            when {
                // Flashlight ON
                lower.contains("chiroqni yoq") || lower.contains("fonar yoq") || lower.contains("turn on flashlight") || lower.contains("torch on") -> {
                    deviceController.setFlashlight(true)
                    responseText = "Kamera chirog'i yoqildi, Janob."
                    actionTag = "FLASHLIGHT_ON"
                    handledLocally = true
                }
                // Flashlight OFF
                lower.contains("chiroqni o'chir") || lower.contains("chiroqni ochir") || lower.contains("fonar o'chir") || lower.contains("turn off flashlight") || lower.contains("torch off") -> {
                    deviceController.setFlashlight(false)
                    responseText = "Chiroq o'chirildi."
                    actionTag = "FLASHLIGHT_OFF"
                    handledLocally = true
                }
                // Battery Check
                lower.contains("quvvat") || lower.contains("batareya") || lower.contains("battery") -> {
                    deviceController.updateBatteryInfo()
                    val b = deviceController.batteryInfo.value
                    responseText = "Qurilmangiz quvvati hozirda ${b.level}%. Harorat: ${b.temperatureCelsius}°C. ${if (b.isCharging) "Zaryadlanmoqda." else "Zaryadlanmayapti."}"
                    actionTag = "BATTERY_CHECK"
                    handledLocally = true
                }
                // Remember / Memory store: "eslab qol: ...", "remember: ...", "xotiraga saqla: ..."
                lower.startsWith("eslab qol") || lower.startsWith("remember") || lower.startsWith("xotiraga saqla") || lower.startsWith("eslatma:") -> {
                    val cleanContent = prompt
                        .replace(Regex("^(eslab qol[:\\s]*|remember[:\\s]*|xotiraga saqla[:\\s]*|eslatma[:\\s]*)", RegexOption.IGNORE_CASE), "")
                        .trim()

                    if (cleanContent.isNotBlank()) {
                        val category = when {
                            cleanContent.contains("parol", true) || cleanContent.contains("kod", true) || cleanContent.contains("kalit", true) -> "Keys & Passwords"
                            cleanContent.contains("manzil", true) || cleanContent.contains("joy", true) -> "Location"
                            cleanContent.contains("odati", true) || cleanContent.contains("yoqtir", true) -> "Preference"
                            else -> "General"
                        }
                        repository.addMemory(
                            category = category,
                            title = cleanContent.take(30) + (if (cleanContent.length > 30) "..." else ""),
                            content = cleanContent,
                            isPinned = true
                        )
                        responseText = "Bajarildi, Janob! Xotiraga saqlab qoldim: \"$cleanContent\"."
                        actionTag = "MEMORY_SAVED"
                        handledLocally = true
                    }
                }
                // Task add: "vazifa qo'sh: ...", "add task: ...", "reja: ..."
                lower.startsWith("vazifa") || lower.startsWith("add task") || lower.startsWith("reja:") -> {
                    val cleanTask = prompt
                        .replace(Regex("^(vazifa qo'sh[:\\s]*|vazifa[:\\s]*|add task[:\\s]*|reja[:\\s]*)", RegexOption.IGNORE_CASE), "")
                        .trim()
                    if (cleanTask.isNotBlank()) {
                        repository.addTask(title = cleanTask, priority = "High")
                        responseText = "Yangi vazifa ro'yxatingizga kiritildi: \"$cleanTask\"."
                        actionTag = "TASK_ADDED"
                        handledLocally = true
                    }
                }
                // Read tasks: "rejalarim nima", "vazifalarni ayt", "my tasks"
                lower.contains("rejam nima") || lower.contains("vazifalarim") || lower.contains("read tasks") -> {
                    val active = repository.getActiveTasks()
                    responseText = if (active.isEmpty()) {
                        "Sizda hozircha bajarilmagan vazifalar mavjud emas, Janob."
                    } else {
                        "Sizning faol vazifalaringiz:\n" + active.mapIndexed { idx, t -> "${idx + 1}. ${t.title}" }.joinToString("\n")
                    }
                    actionTag = "TASKS_READ"
                    handledLocally = true
                }
                // Night Protocol
                lower.contains("tungi rejim") || lower.contains("protocol night") -> {
                    deviceController.setFlashlight(false)
                    deviceController.setSilentMode(true)
                    responseText = "Tungi protokol ishga tushirildi: chiroq o'chirildi, ovoz tinch rejimga o'tkazildi. Xayrli tun, Janob."
                    actionTag = "PROTOCOL_NIGHT"
                    handledLocally = true
                }
                // Launch Apps
                lower.startsWith("och:") || lower.startsWith("open ") || lower.contains("ilovani och") -> {
                    val targetApp = prompt
                        .replace(Regex("^(och:?\\s*|open\\s*|ilovani och:?\\s*)", RegexOption.IGNORE_CASE), "")
                        .trim()
                    val opened = deviceController.launchApp(targetApp)
                    responseText = if (opened) "$targetApp ilovasi ochilmoqda..." else "$targetApp ilovasini ochib bo'lmadi."
                    actionTag = "APP_LAUNCH"
                    handledLocally = true
                }
                // Set Volume: "ovozni 50% qil", "volume 80"
                lower.contains("ovozni") || lower.contains("volume") -> {
                    val digits = Regex("\\d+").find(lower)?.value?.toIntOrNull()
                    if (digits != null) {
                        deviceController.setVolume(digits)
                        responseText = "Media ovozi $digits% darajasiga o'rnatildi."
                        actionTag = "VOLUME_SET"
                        handledLocally = true
                    }
                }
            }

            // 3. If not handled locally, consult Gemini AI with Room Memories Grounding!
            if (!handledLocally) {
                val storedMemories = repository.getRecentMemories()
                val memoryContext = if (storedMemories.isNotEmpty()) {
                    "FOYDALANUVCHINING SAQLANGAN XOTIRALARI VA MA'LUMOTLARI:\n" +
                            storedMemories.joinToString("\n") { "- [${it.category}] ${it.title}: ${it.content}" }
                } else ""

                val activeTasks = repository.getActiveTasks()
                val tasksContext = if (activeTasks.isNotEmpty()) {
                    "FOYDALANUVCHINING FAOL VAZIFALARI:\n" +
                            activeTasks.joinToString("\n") { "- ${it.title} (Prioritet: ${it.priority})" }
                } else ""

                val systemPrompt = """
                    Sen JARVIS'san — nihoyatda aqlli, zukko, madaniyatli va zamonaviy shaxsiy sun'iy intellekt yordamchisisan (Iron Man filmidagi sadoqatli yordamchi kabi).
                    
                    MUHIM TILING VA GAPLASHISH QOIDALARI:
                    1. Foydalanuvchiga sof, ravon, adabiy va chiroyli o'zbek tilida (lotin alifbosida) javob ber.
                    2. Sun'iy, tarjima qilinganga o'xshash yoki g'aliz jumlalardan qoch. Fikringni xuddi haqiqiy bilimdon insondek ravon, aniq va ixcham ifoda et.
                    3. Foydalanuvchiga "Janob" yoki "Hurmatli foydalanuvchi" deb xushmuomala ohangda murojaat qil.
                    4. Matnda keraksiz murakkab belgilar, keraksiz formatting va qavslarni ko'paytirma, chunki javobing ovozli o'qiladi.
                    5. Agar foydalanuvchi ingliz yoki rus tilida gapirsa, o'sha tilda mukammal javob ber.
                    
                    $memoryContext
                    $tasksContext
                    
                    Qurilma holati: Batareya: ${deviceController.batteryInfo.value.level}%, Internet: ${deviceController.networkInfo.value.networkType}.
                """.trimIndent()

                // Fetch recent conversation history
                val recentHistory = repository.getRecentMessages(8)
                    .reversed()
                    .map { Pair(it.role, it.message) }

                val result = GeminiService.generateResponse(
                    modelName = _selectedModel.value,
                    conversationHistory = recentHistory,
                    currentPrompt = prompt,
                    systemInstruction = systemPrompt,
                    enableSearchGrounding = _isSearchGroundingEnabled.value,
                    enableThinkingMode = _isThinkingModeEnabled.value
                )

                result.onSuccess { (aiText, searchQueries) ->
                    responseText = aiText
                }.onFailure { err ->
                    responseText = "Xatolik yuz berdi: ${err.message ?: "Tizim ulanishida nosozlik"}"
                }
            }

            // 4. Save Jarvis response to Room Database
            repository.saveMessage(
                role = "jarvis",
                message = responseText,
                modelName = _selectedModel.value,
                actionExecuted = actionTag
            )

            _lastActionStatus.value = actionTag ?: "RESPONSE_READY"
            _isProcessing.value = false

            // 5. Speak response if auto TTS is enabled
            if (_isTtsAutoPlay.value && responseText.isNotBlank()) {
                // Try Gemini TTS or Native TTS
                speechEngine.speak(responseText)
            }
        }
    }

    // --- Multimodal Studio Actions ---

    fun generateAiImage(prompt: String, size: String = "2K") {
        if (prompt.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _studioStatusMessage.value = "Yuqori sifatli rasm generatsiya qilinmoqda ($size)..."
            _generatedImageBase64.value = null

            val result = GeminiService.generateImage(
                prompt = prompt,
                aspectRatio = "1:1",
                imageSize = size
            )

            result.onSuccess { base64 ->
                _generatedImageBase64.value = base64
                _studioStatusMessage.value = "Rasm muvaffaqiyatli yaratildi!"
                deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
            }.onFailure { err ->
                _studioStatusMessage.value = "Rasm yaratishda xatolik: ${err.message}"
                deviceController.triggerHaptic(DeviceController.HapticType.ALERT)
            }
            _isProcessing.value = false
        }
    }

    fun generateMusicTrack(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _studioStatusMessage.value = "Musiqa trek yaratilmoqda (Lyria)..."
            _generatedMusicBytes.value = null

            val result = GeminiService.generateMusic(prompt)
            result.onSuccess { audioBytes ->
                _generatedMusicBytes.value = audioBytes
                _studioStatusMessage.value = "Musiqa tayyor! Tinglashingiz mumkin."
                speechEngine.playAudioBytes(audioBytes)
                deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
            }.onFailure { err ->
                _studioStatusMessage.value = "Musiqa xatoligi: ${err.message}"
            }
            _isProcessing.value = false
        }
    }

    fun requestVeoVideo(prompt: String, aspectRatio: String = "16:9") {
        if (prompt.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _studioStatusMessage.value = "Veo Video yaratish so'rovi yuborilmoqda..."
            val result = GeminiService.generateVideo(prompt, aspectRatio)
            result.onSuccess { msg ->
                _studioStatusMessage.value = "Video so'rovi muvaffaqiyatli jo'natildi: $msg"
                deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
            }.onFailure { err ->
                _studioStatusMessage.value = "Video so'rovi xatosi: ${err.message}"
            }
            _isProcessing.value = false
        }
    }

    // --- Entity Manipulations ---

    fun addCustomMemory(category: String, title: String, content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addMemory(category, title, content)
            deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMemory(memory)
            deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        }
    }

    fun toggleTaskCompletion(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
            deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        }
    }

    fun addNewTask(title: String, priority: String = "Normal") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addTask(title, priority = priority)
            deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTask(task)
            deviceController.triggerHaptic(DeviceController.HapticType.CLICK)
        }
    }

    fun executeProtocol(protocol: ProtocolEntity) {
        deviceController.triggerHaptic(DeviceController.HapticType.SUCCESS)
        processCommand(protocol.triggerPhrase, isVoiceInput = false)
    }

    fun clearChatHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearChat()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechEngine.release()
    }
}
