package com.example.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BatteryInfo(
    val level: Int = 100,
    val isCharging: Boolean = false,
    val temperatureCelsius: Float = 28.0f,
    val technology: String = "Li-ion"
)

data class NetworkInfo(
    val isConnected: Boolean = true,
    val isWifi: Boolean = true,
    val isCellular: Boolean = false,
    val networkType: String = "Wi-Fi"
)

class DeviceController(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private val _batteryInfo = MutableStateFlow(BatteryInfo())
    val batteryInfo: StateFlow<BatteryInfo> = _batteryInfo.asStateFlow()

    private val _networkInfo = MutableStateFlow(NetworkInfo())
    val networkInfo: StateFlow<NetworkInfo> = _networkInfo.asStateFlow()

    private var cameraId: String? = null

    init {
        initCamera()
        updateBatteryInfo()
        updateNetworkInfo()
    }

    private fun initCamera() {
        try {
            cameraManager?.let { manager ->
                for (id in manager.cameraIdList) {
                    val characteristics = manager.getCameraCharacteristics(id)
                    val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                    if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        cameraId = id
                        break
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleFlashlight(): Boolean {
        return setFlashlight(!_isFlashlightOn.value)
    }

    fun setFlashlight(enable: Boolean): Boolean {
        try {
            val id = cameraId ?: cameraManager?.cameraIdList?.firstOrNull()
            if (id != null && cameraManager != null) {
                cameraManager.setTorchMode(id, enable)
                _isFlashlightOn.value = enable
                triggerHaptic(HapticType.SUCCESS)
                return true
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun updateBatteryInfo() {
        try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)

            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else 85

            val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

            val temp = (batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 280) / 10f
            val tech = batteryStatus?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

            _batteryInfo.value = BatteryInfo(
                level = batteryPct,
                isCharging = isCharging,
                temperatureCelsius = temp,
                technology = tech
            )
        } catch (e: Exception) {
            _batteryInfo.value = BatteryInfo(level = 88, isCharging = false, temperatureCelsius = 30.5f)
        }
    }

    fun updateNetworkInfo() {
        try {
            val network = connectivityManager?.activeNetwork
            val capabilities = connectivityManager?.getNetworkCapabilities(network)

            val isConnected = capabilities != null &&
                    (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                     capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))

            val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val isCellular = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

            val netType = when {
                isWifi -> "Wi-Fi 6 (Ulangan)"
                isCellular -> "Mobil Internet (5G/LTE)"
                isConnected -> "Internet Mavjud"
                else -> "Oflayn"
            }

            _networkInfo.value = NetworkInfo(
                isConnected = isConnected,
                isWifi = isWifi,
                isCellular = isCellular,
                networkType = netType
            )
        } catch (e: Exception) {
            _networkInfo.value = NetworkInfo(isConnected = true, isWifi = true, networkType = "Wi-Fi")
        }
    }

    fun setVolume(percent: Int) {
        try {
            audioManager?.let { am ->
                val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val targetVol = (maxVol * (percent / 100f)).toInt().coerceIn(0, maxVol)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
                triggerHaptic(HapticType.CLICK)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setSilentMode(enable: Boolean) {
        try {
            audioManager?.let { am ->
                if (enable) {
                    am.ringerMode = AudioManager.RINGER_MODE_SILENT
                } else {
                    am.ringerMode = AudioManager.RINGER_MODE_NORMAL
                }
                triggerHaptic(HapticType.SUCCESS)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun createTimer(seconds: Int, message: String = "JARVIS Taymeri"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            triggerHaptic(HapticType.SUCCESS)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Taymer o'rnatildi: $seconds soniya", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun createAlarm(hour: Int, minutes: Int, message: String = "JARVIS Budilnik"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            triggerHaptic(HapticType.SUCCESS)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Budilnik o'rnatildi: $hour:$minutes", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun launchApp(appName: String): Boolean {
        val trimmed = appName.lowercase().trim()
        
        // Direct common app aliases
        when {
            trimmed.contains("kamera") || trimmed.contains("camera") -> {
                val intent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(intent)
            }
            trimmed.contains("galereya") || trimmed.contains("gallery") || trimmed.contains("rasmlar") || trimmed.contains("photos") -> {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    type = "image/*"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(intent)
            }
            trimmed.contains("kalkulyator") || trimmed.contains("calculator") -> {
                val candidates = listOf(
                    "com.google.android.calculator",
                    "com.android.calculator2",
                    "com.sec.android.app.popupcalculator",
                    "com.miui.calculator"
                )
                for (pkg in candidates) {
                    val intent = context.packageManager.getLaunchIntentForPackage(pkg)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        return tryStartActivity(intent)
                    }
                }
            }
            trimmed.contains("youtube") || trimmed.contains("yutub") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
                return openWebUrl("https://www.youtube.com")
            }
            trimmed.contains("telegram") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("org.telegram.messenger")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
            }
            trimmed.contains("whatsapp") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
            }
            trimmed.contains("instagram") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
            }
            trimmed.contains("tiktok") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
            }
            trimmed.contains("chrome") || trimmed.contains("brauzer") || trimmed.contains("browser") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.android.chrome")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
                return openWebUrl("https://www.google.com")
            }
            trimmed.contains("sozlama") || trimmed.contains("settings") -> {
                val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(intent)
            }
            trimmed.contains("play market") || trimmed.contains("play store") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.android.vending")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    return tryStartActivity(launchIntent)
                }
            }
            trimmed.contains("xarita") || trimmed.contains("maps") -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(intent)
            }
            trimmed.contains("telefon") || trimmed.contains("qo'ng'iroq") || trimmed.contains("dialer") -> {
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return tryStartActivity(intent)
            }
        }

        // Generic app search in PackageManager
        try {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(0)
            for (app in packages) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label.contains(trimmed) || trimmed.contains(label)) {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        return tryStartActivity(intent)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Fallback web search
        return openWebUrl("https://www.google.com/search?q=$appName")
    }

    fun openDialer(phoneNumber: String = ""): Boolean {
        val uri = if (phoneNumber.isNotBlank()) Uri.parse("tel:${Uri.encode(phoneNumber.trim())}") else Uri.parse("tel:")
        val intent = Intent(Intent.ACTION_DIAL, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun openSms(phoneNumber: String = "", message: String = ""): Boolean {
        val uri = if (phoneNumber.isNotBlank()) Uri.parse("smsto:${Uri.encode(phoneNumber.trim())}") else Uri.parse("smsto:")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            if (message.isNotBlank()) putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun openWifiSettings(): Boolean {
        val intent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun openBluetoothSettings(): Boolean {
        val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun searchYouTube(query: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    fun searchGoogle(query: String): Boolean {
        return openWebUrl("https://www.google.com/search?q=${Uri.encode(query)}")
    }

    fun openWebUrl(url: String): Boolean {
        val safeUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(safeUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return tryStartActivity(intent)
    }

    private fun tryStartActivity(intent: Intent): Boolean {
        return try {
            context.startActivity(intent)
            triggerHaptic(HapticType.SUCCESS)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun triggerHaptic(type: HapticType = HapticType.CLICK) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            vibrator?.let { v ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = when (type) {
                        HapticType.CLICK -> VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
                        HapticType.SUCCESS -> VibrationEffect.createWaveform(longArrayOf(0, 40, 50, 60), -1)
                        HapticType.ALERT -> VibrationEffect.createWaveform(longArrayOf(0, 100, 80, 150), -1)
                    }
                    v.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(50)
                }
            }
        } catch (e: Exception) {
            // Silently ignore if not supported
        }
    }

    enum class HapticType {
        CLICK, SUCCESS, ALERT
    }
}
